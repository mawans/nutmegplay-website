<?php
// Top navigation bar for dashboard pages
$pageHeading = $pageHeading ?? $pageTitle ?? 'Dashboard';
$pageDescription = $pageDescription ?? '';

// Load notification count for the bell badge
$_topnavUnreadCount = 0;
$_topnavLatest = [];
if (\App\Core\Auth::check()) {
    try {
        $_topnavNs = new \App\Services\NotificationService();
        $_topnavUnreadCount = $_topnavNs->countUnread(\App\Core\Auth::uid());
        $_topnavLatest = $_topnavNs->listUnread(\App\Core\Auth::uid(), 5);
    } catch (\Throwable $e) { /* table may not exist yet */ }
}
?>
<!-- Top Navigation Bar -->
<header id="topnav" class="sticky top-0 z-40 h-16 ml-0 md:ml-64 border-b border-slate-200 dark:border-[#264531] flex items-center justify-between px-4 md:px-6 shrink-0 bg-white dark:bg-background-dark backdrop-blur-sm transition-all duration-300 relative">
    <div class="flex items-center gap-4">
        <button class="text-slate-700 dark:text-white hover:text-primary transition-colors" id="mobile-menu-toggle" onclick="toggleMobileMenu()">
            <span class="material-symbols-outlined">menu</span>
        </button>
        <div>
            <h2 class="text-lg md:text-xl font-bold tracking-tight"><?= htmlspecialchars($pageHeading) ?></h2>
            <?php if ($pageDescription): ?>
            <p class="text-xs md:text-sm text-slate-500 dark:text-text-muted hidden md:block"><?= htmlspecialchars($pageDescription) ?></p>
            <?php endif; ?>
        </div>
    </div>
    <div class="flex items-center gap-3">
        <!-- Notifications Dropdown -->
        <div class="relative" id="notif-dropdown-container">
            <button onclick="toggleNotifDropdown()" class="relative p-2 text-slate-600 dark:text-text-muted hover:text-slate-900 dark:hover:text-white transition-colors" id="notif-bell-btn">
                <span class="material-symbols-outlined">notifications</span>
                <?php if ($_topnavUnreadCount > 0): ?>
                <span id="notif-badge" class="absolute top-1 right-1 min-w-[18px] h-[18px] flex items-center justify-center bg-accent-danger text-white text-[10px] font-bold rounded-full px-1 border-2 border-white dark:border-background-dark"><?= $_topnavUnreadCount > 99 ? '99+' : $_topnavUnreadCount ?></span>
                <?php else: ?>
                <span id="notif-badge" class="absolute top-1 right-1 min-w-[18px] h-[18px] flex items-center justify-center bg-accent-danger text-white text-[10px] font-bold rounded-full px-1 border-2 border-white dark:border-background-dark hidden">0</span>
                <?php endif; ?>
            </button>
            <!-- Dropdown panel -->
            <div id="notif-dropdown" class="hidden absolute right-0 top-full mt-2 w-80 md:w-96 bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-xl shadow-2xl overflow-hidden z-50">
                <div class="px-4 py-3 border-b border-slate-200 dark:border-[#264531] flex items-center justify-between">
                    <h4 class="text-sm font-bold">Notifications</h4>
                    <a href="/notifications" class="text-xs font-medium text-primary hover:text-green-600 transition-colors">View all →</a>
                </div>
                <div id="notif-dropdown-list" class="max-h-80 overflow-y-auto">
                    <?php if (!empty($_topnavLatest)): ?>
                    <?php foreach ($_topnavLatest as $n):
                        $nIcon = $n['icon'] ?? 'notifications';
                        $nTime = '';
                        if (!empty($n['created_at'])) {
                            $d = time() - strtotime($n['created_at']);
                            if ($d < 60) $nTime = 'now';
                            elseif ($d < 3600) $nTime = floor($d/60) . 'm';
                            elseif ($d < 86400) $nTime = floor($d/3600) . 'h';
                            else $nTime = floor($d/86400) . 'd';
                        }
                    ?>
                    <a href="<?= htmlspecialchars($n['link'] ?? '/notifications') ?>" class="flex items-start gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-[#1f3629] transition-colors border-b border-slate-100 dark:border-[#264531]/50 last:border-0">
                        <div class="shrink-0 size-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <span class="material-symbols-outlined text-primary text-base"><?= htmlspecialchars($nIcon) ?></span>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-semibold truncate"><?= htmlspecialchars($n['title'] ?? '') ?></p>
                            <p class="text-xs text-muted truncate"><?= htmlspecialchars($n['message'] ?? '') ?></p>
                        </div>
                        <span class="text-[10px] text-muted shrink-0 mt-0.5"><?= $nTime ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <div class="px-4 py-8 text-center text-muted">
                        <span class="material-symbols-outlined text-2xl mb-1 block">notifications_off</span>
                        <p class="text-xs">No new notifications</p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if ($_topnavUnreadCount > 0): ?>
                <div class="px-4 py-2 border-t border-slate-200 dark:border-[#264531]">
                    <form method="POST" action="/notifications/read-all" hx-boost="false">
                        <button type="submit" class="text-xs font-medium text-primary hover:text-green-600 transition-colors w-full text-center">Mark all as read</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- User Menu (Optional - can expand later) -->
        <a href="/profile" class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-[#1a2c22] border border-slate-200 dark:border-[#264531] hover:border-primary/30 transition-colors">
            <div class="size-2 rounded-full bg-primary pulse-dot"></div>
            <span class="text-xs font-medium text-primary">Active</span>
        </a>
    </div>
</header>

<!-- Notification sound (base64-encoded short beep) -->
<audio id="notif-sound" preload="auto">
    <source src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgkKu0markup+2BXIIhwjozI6+zs5+Pq7OHRUR0VZZ6ru7yxn5SnqrG+zcbDoKqtoZ6jp2V0fHR5i5G0xcHExsnJy73EurGqnZualpSQjomFhYmRm6u0u8TByM7QzMvGvrqzqJ+cmZuYlpaTj4qKkJqdpaq3vcHFycrMysfBu7SsoZ6Zm5eUk5CQjI2RlZyiqrK4vcHFx8jHxcG9uLKroJ2ZmZaSk5KSkpWYn6WstrvAw8bHyMbFwby4sq6ppJ+cmpiWlZWVl5qdpKq0u8DCxMbHxsbEwr67t7Svq6ein5yclZSVl5iepa2zucDDxMXGxcXDwL69uraxrKijoJ6cnJqYmZ2hpq2yub3Bw8XFxcXDwb++vLm2sq6rp6SinpycnZ+iqq+0ur7Bw8TFxcTDwcC+vbu5trOvrKmmpKKgoKKlqa60ur7Bw8TFxcTE" type="audio/wav">
</audio>

<script>
// Notification dropdown toggle
function toggleNotifDropdown() {
    const dd = document.getElementById('notif-dropdown');
    dd.classList.toggle('hidden');
}
// Close dropdown on outside click
document.addEventListener('click', function(e) {
    const container = document.getElementById('notif-dropdown-container');
    if (container && !container.contains(e.target)) {
        document.getElementById('notif-dropdown')?.classList.add('hidden');
    }
});

// Notification polling & sound
(function() {
    let lastCount = <?= $_topnavUnreadCount ?>;
    const sound = document.getElementById('notif-sound');

    function playNotifSound() {
        try {
            if (sound) { sound.currentTime = 0; sound.play().catch(()=>{}); }
        } catch(e) {}
    }

    async function pollNotifications() {
        try {
            const resp = await fetch('/notifications/api', { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            if (!resp.ok) return;
            const data = await resp.json();
            const badge = document.getElementById('notif-badge');
            if (data.count > 0) {
                badge.textContent = data.count > 99 ? '99+' : data.count;
                badge.classList.remove('hidden');
                if (data.count > lastCount) {
                    playNotifSound();
                }
            } else {
                badge.classList.add('hidden');
            }
            lastCount = data.count;

            // Update dropdown list
            const list = document.getElementById('notif-dropdown-list');
            if (list && data.notifications && data.notifications.length > 0) {
                let html = '';
                data.notifications.forEach(function(n) {
                    const icon = n.icon || 'notifications';
                    let timeStr = '';
                    if (n.created_at) {
                        const d = Math.floor((Date.now() - new Date(n.created_at).getTime()) / 1000);
                        if (d < 60) timeStr = 'now';
                        else if (d < 3600) timeStr = Math.floor(d/60) + 'm';
                        else if (d < 86400) timeStr = Math.floor(d/3600) + 'h';
                        else timeStr = Math.floor(d/86400) + 'd';
                    }
                    const link = n.link || '/notifications';
                    html += '<a href="' + link + '" class="flex items-start gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-[#1f3629] transition-colors border-b border-slate-100 dark:border-[#264531]/50 last:border-0">' +
                        '<div class="shrink-0 size-8 rounded-full bg-primary/10 flex items-center justify-center"><span class="material-symbols-outlined text-primary text-base">' + icon + '</span></div>' +
                        '<div class="flex-1 min-w-0"><p class="text-sm font-semibold truncate">' + (n.title||'') + '</p><p class="text-xs text-muted truncate">' + (n.message||'') + '</p></div>' +
                        '<span class="text-[10px] text-muted shrink-0 mt-0.5">' + timeStr + '</span></a>';
                });
                list.innerHTML = html;
            } else if (list && (!data.notifications || data.notifications.length === 0)) {
                list.innerHTML = '<div class="px-4 py-8 text-center text-muted"><span class="material-symbols-outlined text-2xl mb-1 block">notifications_off</span><p class="text-xs">No new notifications</p></div>';
            }
        } catch(e) {}
    }

    // Poll every 30 seconds
    setInterval(pollNotifications, 30000);
})();
</script>
