<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Core\SupabaseClient;
use App\Services\AccountService;
use App\Services\PlayerProgressService;

class AuthController extends Controller
{
    public function login(): void
    {
        if (Auth::check()) {
            header('Location: /dashboard');
            exit;
        }
        $error = Auth::getFlash('error');
        $success = Auth::getFlash('success');
        $this->renderRaw(BASE_PATH . '/app/views/auth/login.php', compact('error', 'success'));
    }

    public function loginAlt(): void
    {
        if (Auth::check()) {
            header('Location: /dashboard');
            exit;
        }
        $error = Auth::getFlash('error');
        $success = Auth::getFlash('success');
        $this->renderRaw(BASE_PATH . '/app/views/auth/login-alt.php', compact('error', 'success'));
    }

    public function register(): void
    {
        if (Auth::check()) {
            header('Location: /dashboard');
            exit;
        }
        $error = Auth::getFlash('error');
        $this->renderRaw(BASE_PATH . '/app/views/auth/login.php', [
            'error' => $error,
            'isRegister' => true,
        ]);
    }

    /** POST /login */
    public function handleLogin(): void
    {
        if (!Auth::verifyCsrf($_POST['_csrf'] ?? null)) {
            Auth::flash('error', 'Invalid request. Please refresh and try again.');
            header('Location: /login');
            exit;
        }

        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            Auth::flash('error', 'Email and password are required.');
            header('Location: /login');
            exit;
        }

        try {
            $sb = SupabaseClient::getInstance();
            $authResult = $sb->authSignIn($email, $password);
        } catch (\Throwable $e) {
            Auth::flash('error', 'Authentication service is not configured. Check app/Config/supabase.php.');
            header('Location: /login');
            exit;
        }

        if (!$authResult || !empty($authResult['error'])) {
            $msg = $authResult['message'] ?? 'Invalid email or password.';
            $msgLower = strtolower((string)$msg);
            if (str_contains($msgLower, 'email not confirmed')) {
                $msg = 'Your email is not confirmed yet. Check your inbox (or ask admin to create your user via admin panel).';
            } elseif (str_contains($msgLower, 'rate limit')) {
                $msg = 'Too many login attempts. Please wait a minute and try again.';
            }
            Auth::flash('error', $msg);
            header('Location: /login');
            exit;
        }

        // Fetch account row from accounts table
        $accounts = new AccountService();
        $account = $accounts->getByEmail($email);

        if (!$account) {
            // Maybe first login – create placeholder account row
            $uid = $authResult['user']['id'] ?? '';
            $account = $accounts->create([
                'email'    => $email,
                'uid'      => $uid,
                'fname'    => explode('@', $email)[0],
                'level'    => 1,
            ]);
        }

        Auth::login($authResult, $account ?? []);

        header('Location: /dashboard');
        exit;
    }

    /** POST /register */
    public function handleRegister(): void
    {
        if (!Auth::verifyCsrf($_POST['_csrf'] ?? null)) {
            Auth::flash('error', 'Invalid request. Please refresh and try again.');
            header('Location: /register');
            exit;
        }

        $fname    = trim($_POST['fname'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $country  = trim($_POST['country'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $role     = strtolower(trim($_POST['role'] ?? 'player'));
        if (!in_array($role, ['player', 'instructor', 'admin'], true)) {
            $role = 'player';
        }

        if (!$email || !$password || !$fname) {
            Auth::flash('error', 'Name, email, and password are required.');
            header('Location: /register');
            exit;
        }

        try {
            $sb = SupabaseClient::getInstance();
            $authResult = $sb->authSignUp($email, $password, ['fname' => $fname]);
        } catch (\Throwable $e) {
            Auth::flash('error', 'Authentication service is not configured. Check app/Config/supabase.php.');
            header('Location: /register');
            exit;
        }

        if (!$authResult || !empty($authResult['error'])) {
            $msg = $authResult['message'] ?? 'Registration failed. Try a different email.';
            if (str_contains(strtolower($msg), 'rate limit')) {
                $msg = 'Too many signup attempts were made. Please wait a minute before trying again.';
            }
            Auth::flash('error', $msg);
            header('Location: /register');
            exit;
        }

        $uid = $authResult['user']['id'] ?? ($authResult['id'] ?? '');

        // Create accounts row
        $accounts = new AccountService();
        $account = $accounts->create([
            'fname'    => $fname,
            'email'    => $email,
            'uid'      => $uid,
            'country'  => $country,
            'position' => $position,
            'role'     => $role,
            'level'    => 1,
        ]);

        // Create initial player progress
        if ($uid) {
            $progress = new PlayerProgressService();
            $progress->create($uid, 50, 0);
        }

        // If Supabase email confirmation is off, log in immediately
        if (!empty($authResult['access_token'])) {
            Auth::login($authResult, $account ?? []);
            header('Location: /dashboard');
        } else {
            Auth::flash('success', 'Account created! Please check your email to confirm, then log in.');
            header('Location: /login');
        }
        exit;
    }

    /** GET /logout */
    public function logoutRedirect(): void
    {
        header('Location: ' . (Auth::check() ? '/dashboard' : '/login'));
        exit;
    }

    /** POST /logout */
    public function logout(): void
    {
        if (!Auth::verifyCsrf($_POST['_csrf'] ?? null)) {
            Auth::flash('error', 'Invalid request. Please refresh and try again.');
            header('Location: /dashboard');
            exit;
        }

        Auth::logout();
        header('Location: /login');
        exit;
    }

    /** POST /profile */
    public function updateProfile(): void
    {
        Auth::requireAuth();

        if (!Auth::verifyCsrf($_POST['_csrf'] ?? null)) {
            Auth::flash('error', 'Invalid request. Please refresh and try again.');
            header('Location: /dashboard');
            exit;
        }

        $account = Auth::account();
        $id = (int)($account['id'] ?? 0);

        $data = array_filter([
            'fname'    => trim($_POST['fname'] ?? ''),
            'country'  => trim($_POST['country'] ?? ''),
            'position' => trim($_POST['position'] ?? ''),
        ]);

        if ($id && $data) {
            $accounts = new AccountService();
            $updated = $accounts->update($id, $data);
            if ($updated) {
                Auth::refreshAccount($updated);
            }
        }

        header('Location: /dashboard');
        exit;
    }
}
