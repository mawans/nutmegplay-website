<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Services\MatchService;
use App\Services\NotificationService;

class VideoController extends Controller
{
    private const ALLOWED_TYPES = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm', 'video/x-matroska'];
    private const MAX_SIZE = 500 * 1024 * 1024; // 500 MB

    /** GET /video-upload */
    public function upload(): void
    {
        Auth::requireAuth();

        $matches = new MatchService();
        $uid = Auth::uid();

        $userMatches = $matches->listByUser($uid, 20);
        $account = Auth::account();
        $error   = Auth::getFlash('error');
        $success = Auth::getFlash('success');

        $this->renderRaw(BASE_PATH . '/app/views/dashboards/video-upload.php', [
            'account'     => $account,
            'userMatches' => $userMatches,
            'error'       => $error,
            'success'     => $success,
        ]);
    }

    /** POST /video-upload – upload video file to local directory */
    public function handleUpload(): void
    {
        Auth::requireAuth();
        if (!Auth::verifyCsrf($_POST['_csrf'] ?? null)) {
            Auth::flash('error', 'Invalid request. Please refresh and try again.');
            header('Location: /video-upload');
            exit;
        }

        $matchId = (int)($_POST['match_id'] ?? 0);
        $uid = Auth::uid();
        $matches = new MatchService();

        if (!$matchId) {
            Auth::flash('error', 'Please select a match.');
            header('Location: /video-upload');
            exit;
        }

        $match = $matches->getById($matchId);
        $isOwner = $match && (
            (string)($match['challenger_id'] ?? '') === $uid ||
            (string)($match['opponent_id'] ?? '') === $uid
        );
        if (!$isOwner) {
            Auth::flash('error', 'You are not allowed to upload video for this match.');
            header('Location: /video-upload');
            exit;
        }

        // Check if a file was uploaded
        if (!isset($_FILES['video_file']) || $_FILES['video_file']['error'] === UPLOAD_ERR_NO_FILE) {
            // Fall back to URL mode
            $videoUrl = trim($_POST['video_url'] ?? '');
            if ($videoUrl) {
                $parts = parse_url($videoUrl);
                $scheme = strtolower((string)($parts['scheme'] ?? ''));
                if (!filter_var($videoUrl, FILTER_VALIDATE_URL) || !in_array($scheme, ['http', 'https'], true)) {
                    Auth::flash('error', 'Please provide a valid http(s) video URL.');
                    header('Location: /video-upload');
                    exit;
                }
                $matches->update($matchId, [
                    'video_url'    => $videoUrl,
                    'video_status' => 'uploaded',
                ]);
                // Notify match participants about video URL
                try {
                    $m = $matches->getById($matchId);
                    $ns = new NotificationService();
                    foreach (array_filter([(string)($m['challenger_id'] ?? ''), (string)($m['opponent_id'] ?? '')]) as $pid) {
                        $ns->send($pid, NotificationService::TYPE_VIDEO_UPLOADED, 'Video Link Added', 'A video link has been added to your match.', 'videocam', '/video-upload');
                    }
                } catch (\Throwable $e) { /* ignore */ }
                Auth::flash('success', 'Video URL attached successfully.');
                header('Location: /video-upload');
                exit;
            }
            Auth::flash('error', 'Please upload a video file or provide a URL.');
            header('Location: /video-upload');
            exit;
        }

        $file = $_FILES['video_file'];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errorMessages = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds server maximum upload size.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds form maximum size.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'No temporary directory configured.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload blocked by a PHP extension.',
            ];
            $msg = $errorMessages[$file['error']] ?? 'Unknown upload error.';
            Auth::flash('error', $msg);
            header('Location: /video-upload');
            exit;
        }

        // Validate file type
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        if (!in_array($mimeType, self::ALLOWED_TYPES, true)) {
            Auth::flash('error', 'Invalid file type. Allowed: MP4, MOV, AVI, WebM, MKV.');
            header('Location: /video-upload');
            exit;
        }

        // Validate file size
        if ($file['size'] > self::MAX_SIZE) {
            Auth::flash('error', 'File too large. Maximum size is 500MB.');
            header('Location: /video-upload');
            exit;
        }

        // Generate unique filename
        $ext = match($mimeType) {
            'video/mp4'          => 'mp4',
            'video/quicktime'    => 'mov',
            'video/x-msvideo'    => 'avi',
            'video/webm'         => 'webm',
            'video/x-matroska'   => 'mkv',
            default              => pathinfo($file['name'], PATHINFO_EXTENSION),
        };
        $filename = 'match_' . $matchId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $destDir  = BASE_PATH . '/public/videos';
        $destPath = $destDir . '/' . $filename;

        // Ensure directory exists
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }

        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            Auth::flash('error', 'Failed to save uploaded file.');
            header('Location: /video-upload');
            exit;
        }

        // Store the relative URL in the database
        $videoUrl = '/videos/' . $filename;
        $matches->update($matchId, [
            'video_url'    => $videoUrl,
            'video_status' => 'uploaded',
        ]);

        // Notify match participants about video upload
        try {
            $m = $matches->getById($matchId);
            $ns = new NotificationService();
            foreach (array_filter([(string)($m['challenger_id'] ?? ''), (string)($m['opponent_id'] ?? '')]) as $pid) {
                $ns->send($pid, NotificationService::TYPE_VIDEO_UPLOADED, 'Video Uploaded', 'A match video has been uploaded. Watch it now!', 'videocam', '/video-upload');
            }
        } catch (\Throwable $e) { /* ignore */ }

        Auth::flash('success', 'Video uploaded successfully!');
        header('Location: /video-upload');
        exit;
    }
}
