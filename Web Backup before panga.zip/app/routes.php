<?php
use App\Core\Router;
use App\Controllers\{
    LandingController,
    HomeController,
    EventsController,
    FixturesController,
    ChallengesController,
    InstructorController,
    MatchHistoryController,
    PlayersController,
    TeamController,
    VideoController,
    AuthController,
    AdminController,
    NotificationController,
    ProfileController
};

$router = new Router();

// ─── Auth routes ──────────────────────────────────────────
$router->get('/login', [AuthController::class, 'login']);
$router->get('/login-alt', [AuthController::class, 'loginAlt']);
$router->get('/register', [AuthController::class, 'register']);
$router->post('/login', [AuthController::class, 'handleLogin']);
$router->post('/register', [AuthController::class, 'handleRegister']);
$router->get('/logout', [AuthController::class, 'logoutRedirect']);
$router->post('/logout', [AuthController::class, 'logout']);

// ─── Landing page (public) ────────────────────────────────
$router->get('/', [LandingController::class, 'index']);
$router->get('/landing', [LandingController::class, 'index']);

// ─── Dashboard routes (GET) ──────────────────────────────
$router->get('/dashboard', [HomeController::class, 'dashboard']);
$router->get('/matchmaking', [EventsController::class, 'matchmaking']);
$router->get('/fixtures', [FixturesController::class, 'upcoming']);
$router->get('/challenges', [ChallengesController::class, 'index']);
$router->get('/instructor', [InstructorController::class, 'index']);
$router->get('/match-history', [MatchHistoryController::class, 'index']);
$router->get('/players', [PlayersController::class, 'index']);
$router->get('/teams', [TeamController::class, 'index']);
$router->get('/video/upload', [VideoController::class, 'upload']);
$router->get('/video-upload', [VideoController::class, 'upload']);

// ─── API / POST actions ──────────────────────────────────
$router->post('/matchmaking', [EventsController::class, 'createMatch']);
$router->post('/challenges', [ChallengesController::class, 'respond']);
$router->post('/teams', [TeamController::class, 'createClub']);
$router->post('/teams/member/remove', [TeamController::class, 'removeMember']);
$router->post('/teams/member/move', [TeamController::class, 'moveMember']);
$router->post('/players', [PlayersController::class, 'invite']);
$router->post('/video-upload', [VideoController::class, 'handleUpload']);
$router->post('/profile', [ProfileController::class, 'update']);

// ─── Profile routes ───────────────────────────────────────
$router->get('/profile', [ProfileController::class, 'index']);

// ─── Notification routes ──────────────────────────────────
$router->get('/notifications', [NotificationController::class, 'index']);
$router->get('/notifications/api', [NotificationController::class, 'apiLatest']);
$router->post('/notifications/read', [NotificationController::class, 'markRead']);
$router->post('/notifications/read-all', [NotificationController::class, 'markAllRead']);
$router->post('/notifications/delete', [NotificationController::class, 'deleteNotification']);

// ─── Admin routes ─────────────────────────────────────────
$router->get('/admin', [AdminController::class, 'index']);
$router->post('/admin/user/create', [AdminController::class, 'createUser']);
$router->post('/admin/user/role', [AdminController::class, 'updateUserRole']);
$router->post('/admin/user/delete', [AdminController::class, 'deleteUser']);
$router->post('/admin/match/approve', [AdminController::class, 'approveMatch']);
$router->post('/admin/match/location', [AdminController::class, 'assignLocation']);
$router->post('/admin/match/video', [AdminController::class, 'assignVideo']);
$router->post('/admin/announcement', [AdminController::class, 'createAnnouncement']);
$router->post('/admin/challenge/create', [AdminController::class, 'createChallenge']);
$router->post('/admin/challenge/delete', [AdminController::class, 'deleteChallenge']);
$router->post('/admin/challenge/toggle', [AdminController::class, 'toggleChallenge']);

return $router;
