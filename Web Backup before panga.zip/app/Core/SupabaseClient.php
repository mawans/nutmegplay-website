<?php
namespace App\Core;

/**
 * Lightweight HTTP client for the Supabase PostgREST API.
 *
 * Usage:
 *   $sb = SupabaseClient::getInstance();
 *   $rows = $sb->from('accounts')->select('*')->execute();
 *   $sb->from('accounts')->insert(['fname' => 'Ali']);
 */
class SupabaseClient
{
    private static ?self $instance = null;

    private string $url;
    private string $apiKey;
    private ?string $serviceRoleKey = null;
    private string $table = '';
    private string $query = '';
    private array $headers = [];
    private array $baseHeaders = [];
    private bool $expectSingle = false;

    private function __construct()
    {
        [$url, $key, $serviceRoleKey] = $this->resolveCredentials();

        if (!$url || !$key) {
            throw new \RuntimeException(
                'Supabase configuration missing. Set url/key in app/Config/supabase.php.'
            );
        }

        $this->url = rtrim($url, '/');
        $this->apiKey = $key;
        $this->serviceRoleKey = $serviceRoleKey;
        $this->baseHeaders = [
            'apikey: ' . $this->apiKey,
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Prefer: return=representation',
        ];
        $this->headers = $this->baseHeaders;
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        // reset per-query state
        self::$instance->table = '';
        self::$instance->query = '';
        self::$instance->headers = self::$instance->baseHeaders;
        self::$instance->expectSingle = false;
        return self::$instance;
    }

    /* ------------------------------------------------------------------ */
    /*  Query builder                                                      */
    /* ------------------------------------------------------------------ */

    public function from(string $table): self
    {
        $this->table = $table;
        $this->query = '';
        $this->expectSingle = false;
        return $this;
    }

    public function select(string $columns = '*'): self
    {
        $this->query .= '&select=' . urlencode($columns);
        return $this;
    }

    /** PostgREST filter:  eq, neq, gt, gte, lt, lte, like, ilike, is, in */
    public function filter(string $column, string $operator, string $value): self
    {
        $this->query .= '&' . urlencode($column) . '=' . $operator . '.' . urlencode($value);
        return $this;
    }

    public function eq(string $column, string $value): self
    {
        return $this->filter($column, 'eq', $value);
    }

    public function neq(string $column, string $value): self
    {
        return $this->filter($column, 'neq', $value);
    }

    public function ilike(string $column, string $value): self
    {
        return $this->filter($column, 'ilike', $value);
    }

    /**
     * PostgREST OR filter: e.g. or=(col1.eq.val1,col2.eq.val2)
     * Pass raw PostgREST or-syntax string.
     */
    public function orFilter(string $conditions): self
    {
        $this->query .= '&or=(' . $conditions . ')';
        return $this;
    }

    public function order(string $column, bool $ascending = true): self
    {
        $dir = $ascending ? 'asc' : 'desc';
        $this->query .= '&order=' . urlencode($column) . '.' . $dir;
        return $this;
    }

    public function limit(int $count): self
    {
        $this->query .= '&limit=' . $count;
        return $this;
    }

    public function single(): self
    {
        $this->expectSingle = true;
        $this->query .= '&limit=1';
        return $this;
    }

    /* ------------------------------------------------------------------ */
    /*  CRUD operations                                                    */
    /* ------------------------------------------------------------------ */

    /** GET – fetch rows */
    public function execute(): array|null
    {
        $url = $this->buildUrl();
        return $this->request('GET', $url);
    }

    /** POST – insert row(s) */
    public function insert(array $data): array|null
    {
        $url = $this->buildUrl();
        return $this->request('POST', $url, $data);
    }

    /** PATCH – update rows matching current filters */
    public function update(array $data): array|null
    {
        $url = $this->buildUrl();
        return $this->request('PATCH', $url, $data);
    }

    /** DELETE – delete rows matching current filters */
    public function delete(): array|null
    {
        $url = $this->buildUrl();
        return $this->request('DELETE', $url);
    }

    /* ------------------------------------------------------------------ */
    /*  Supabase Auth (GoTrue)                                             */
    /* ------------------------------------------------------------------ */

    /** Sign up with email + password via GoTrue */
    public function authSignUp(string $email, string $password, array $metadata = []): array|null
    {
        $url = $this->url . '/auth/v1/signup';
        $body = ['email' => $email, 'password' => $password];
        if ($metadata) {
            $body['data'] = $metadata;
        }
        return $this->request('POST', $url, $body);
    }

    /** Create auth user via Admin API (service role), without sending confirmation email. */
    public function authAdminCreateUser(string $email, string $password, array $metadata = [], bool $emailConfirm = true): array|null
    {
        if (!$this->serviceRoleKey) {
            return ['error' => true, 'status' => 500, 'message' => 'Service role key is not configured.'];
        }

        $url = $this->url . '/auth/v1/admin/users';
        $body = [
            'email' => $email,
            'password' => $password,
            'email_confirm' => $emailConfirm,
        ];
        if ($metadata) {
            $body['user_metadata'] = $metadata;
        }

        $headers = [
            'apikey: ' . $this->serviceRoleKey,
            'Authorization: Bearer ' . $this->serviceRoleKey,
            'Content-Type: application/json',
        ];

        return $this->request('POST', $url, $body, $headers);
    }

    public function hasServiceRoleKey(): bool
    {
        return !empty($this->serviceRoleKey);
    }

    /** Sign in with email + password via GoTrue */
    public function authSignIn(string $email, string $password): array|null
    {
        $url = $this->url . '/auth/v1/token?grant_type=password';
        return $this->request('POST', $url, [
            'email'    => $email,
            'password' => $password,
        ]);
    }

    /** Get user profile from access token */
    public function authGetUser(string $accessToken): array|null
    {
        $url = $this->url . '/auth/v1/user';
        $headers = [
            'apikey: ' . $this->apiKey,
            'Authorization: Bearer ' . $accessToken,
        ];
        return $this->request('GET', $url, null, $headers);
    }

    /** Make an authenticated API call with user's JWT */
    public function withAuth(string $accessToken): self
    {
        // Replace the default anon Bearer with user's token
        foreach ($this->headers as $i => $h) {
            if (str_starts_with($h, 'Authorization:')) {
                $this->headers[$i] = 'Authorization: Bearer ' . $accessToken;
                break;
            }
        }
        return $this;
    }

    /* ------------------------------------------------------------------ */
    /*  Internals                                                          */
    /* ------------------------------------------------------------------ */

    private function buildUrl(): string
    {
        $url = $this->url . '/rest/v1/' . $this->table;
        if ($this->query) {
            $url .= '?' . ltrim($this->query, '&');
        }
        return $url;
    }

    /**
     * @param array|null $overrideHeaders  Use custom headers (e.g. for auth endpoints)
     */
    private function request(string $method, string $url, ?array $body = null, ?array $overrideHeaders = null): array|null
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $overrideHeaders ?? $this->headers,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CUSTOMREQUEST  => $method,
        ]);

        if ($body !== null) {
            $encoded = json_encode($body);
            if ($encoded === false) {
                $this->headers = $this->baseHeaders;
                $this->expectSingle = false;
                return ['error' => true, 'status' => 500, 'message' => 'Failed to encode request body'];
            }
            curl_setopt($ch, CURLOPT_POSTFIELDS, $encoded);
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        $expectSingle = $this->expectSingle;

        // Reset accept header if single() was used
        $this->headers = $this->baseHeaders;
        $this->expectSingle = false;

        if ($error) {
            error_log("Supabase cURL error: $error");
            return null;
        }

        $decoded = json_decode($response, true);

        if ($httpCode >= 400) {
            $msg = $decoded['message'] ?? $decoded['error_description'] ?? $decoded['msg'] ?? $response;
            error_log("Supabase HTTP $httpCode: $msg");
            return ['error' => true, 'status' => $httpCode, 'message' => $msg];
        }

        if ($expectSingle) {
            if (is_array($decoded) && array_is_list($decoded)) {
                return $decoded[0] ?? null;
            }
            return is_array($decoded) ? $decoded : null;
        }

        return $decoded;
    }

    /**
     * Resolve credentials from app/Config/supabase.php only.
     *
     * @return array{0:?string,1:?string,2:?string}
     */
    private function resolveCredentials(): array
    {
        $config = $this->loadSupabaseConfig();

        return [
            $this->valueOrNull($config['url'] ?? null),
            $this->valueOrNull($config['key'] ?? null),
            $this->valueOrNull($config['service_role_key'] ?? null),
        ];
    }

    /** @return array<string,mixed> */
    private function loadSupabaseConfig(): array
    {
        $configPath = defined('BASE_PATH')
            ? BASE_PATH . '/app/Config/supabase.php'
            : dirname(__DIR__) . '/Config/supabase.php';

        if (!is_file($configPath) || !is_readable($configPath)) {
            return [];
        }

        $config = require $configPath;
        return is_array($config) ? $config : [];
    }

    private function valueOrNull(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $value = trim($value);
        return $value === '' ? null : $value;
    }
}
