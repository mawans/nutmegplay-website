<?php
namespace App\Core;

class Controller
{
    /**
     * Render a view file. Changes the working directory so relative includes
     * inside views continue to resolve correctly.
     *
     * Each view handles its own HTMX-aware conditional rendering (header/footer
     * inclusion) via HtmxHelper::isHtmxRequest().
     */
    protected function renderRaw(string $absolutePath, array $data = []): void
    {
        if (!is_file($absolutePath)) {
            http_response_code(404);
            echo 'View not found';
            return;
        }

        $originalCwd = getcwd();
        extract($data, EXTR_SKIP);
        chdir(dirname($absolutePath));
        include $absolutePath;
        chdir($originalCwd);
    }
}

