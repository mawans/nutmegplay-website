<?php
namespace App\Core;

class Router
{
    /** @var array<string, array<string, array|callable>> */
    private array $routes = [];

    public function get(string $path, array|callable $handler): void
    {
        $normalized = $this->normalize($path);
        $this->routes['GET'][$normalized] = $handler;
    }

    public function post(string $path, array|callable $handler): void
    {
        $normalized = $this->normalize($path);
        $this->routes['POST'][$normalized] = $handler;
    }

    public function dispatch(string $path, string $method = 'GET'): void
    {
        $normalized = $this->normalize($path);
        $method = strtoupper($method);
        $handler = $this->routes[$method][$normalized] ?? null;

        if ($handler === null) {
            http_response_code(404);
            echo '404 - Page not found';
            return;
        }

        $this->invoke($handler);
    }

    private function invoke(array|callable $handler): void
    {
        if (is_array($handler)) {
            [$controllerClass, $method] = $handler;
            $controller = new $controllerClass();
            $controller->$method();
            return;
        }

        $handler();
    }

    private function normalize(string $path): string
    {
        $trimmed = '/' . trim($path, '/');
        return $trimmed === '//' ? '/' : $trimmed;
    }
}
