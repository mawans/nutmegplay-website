<?php
$pageTitle = 'Video Upload';
$pageHeading = 'Video Upload';
$pageDescription = 'Upload and manage your match highlights';
$currentPage = 'video-upload';
$userMatches = $userMatches ?? [];
$account = $account ?? [];
$error = $error ?? '';
$success = $success ?? '';
$csrfToken = \App\Core\Auth::csrfToken();

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">

<!-- Flash Messages -->
<?php if ($error): ?>
<div class="bg-accent-danger/10 border border-accent-danger/30 text-accent-danger rounded-xl p-4 mb-6 flex items-center gap-3">
    <span class="material-symbols-outlined">error</span>
    <p class="text-sm font-medium"><?= htmlspecialchars($error) ?></p>
</div>
<?php endif; ?>
<?php if ($success): ?>
<div class="bg-primary/10 border border-primary/30 text-primary rounded-xl p-4 mb-6 flex items-center gap-3">
    <span class="material-symbols-outlined">check_circle</span>
    <p class="text-sm font-medium"><?= htmlspecialchars($success) ?></p>
</div>
<?php endif; ?>

<!-- Video File Upload Form -->
<div class="bg-white dark:bg-card-dark rounded-xl p-6 shadow-sm border border-slate-200 dark:border-[#264531] mb-6">
<h3 class="text-lg font-bold mb-4 flex items-center gap-2"><span class="material-symbols-outlined text-primary">cloud_upload</span> Upload Match Video</h3>
<?php if (!empty($userMatches)): ?>
<form method="POST" action="/video-upload" enctype="multipart/form-data" class="flex flex-col gap-4" hx-boost="false">
    <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-muted mb-2">Select Match</label>
            <select name="match_id" required class="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#264531] bg-white dark:bg-background-dark focus:border-primary outline-none text-sm">
                <option value="">Choose a match</option>
                <?php foreach ($userMatches as $m): ?>
                <option value="<?= (int)($m['id'] ?? 0) ?>">
                    <?= htmlspecialchars(($m['challanger'] ?? '') . ' vs ' . ($m['opponent'] ?? '')) ?> (<?= htmlspecialchars($m['date'] ?? '') ?>)
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-muted mb-2">Or Paste Video URL</label>
            <input type="url" name="video_url" class="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#264531] bg-white dark:bg-background-dark focus:border-primary outline-none text-sm" placeholder="https://youtube.com/watch?v=...">
        </div>
    </div>

    <!-- Drag & Drop Upload Area -->
    <div id="drop-zone" class="flex flex-col items-center gap-4 rounded-xl border-2 border-dashed border-[#366346] bg-[#1a2e22]/50 px-6 py-10 transition-all duration-300 hover:border-primary/70 hover:bg-[#1a2e22]/70 cursor-pointer relative">
        <input type="file" name="video_file" id="video-file-input" accept="video/mp4,video/quicktime,video/webm,video/x-msvideo,video/x-matroska,.mp4,.mov,.webm,.avi,.mkv" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
        <div class="bg-[#264531] p-3 rounded-full transition-all duration-300">
            <span class="material-symbols-outlined text-white text-3xl">cloud_upload</span>
        </div>
        <div class="flex flex-col items-center gap-1 text-center">
            <p class="text-white text-base font-bold" id="file-label">Upload Video File</p>
            <p class="text-muted text-xs max-w-[300px]">Drag and drop MP4, MOV, WebM, AVI, MKV files or click to browse. Max 500MB.</p>
        </div>
        <div id="file-preview" class="hidden text-sm text-primary font-medium mt-2 flex items-center gap-2">
            <span class="material-symbols-outlined text-sm">videocam</span>
            <span id="file-name"></span>
            <span id="file-size" class="text-muted text-xs"></span>
        </div>
    </div>

    <button type="submit" class="w-full md:w-auto self-end px-8 py-3 bg-primary hover:bg-green-600 text-white font-bold rounded-lg transition-colors text-sm flex items-center justify-center gap-2">
        <span class="material-symbols-outlined text-sm">upload</span> Upload Video
    </button>
</form>
<script>
(function() {
    const input = document.getElementById('video-file-input');
    const label = document.getElementById('file-label');
    const preview = document.getElementById('file-preview');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const dropZone = document.getElementById('drop-zone');

    input.addEventListener('change', function() {
        if (this.files.length > 0) {
            const f = this.files[0];
            label.textContent = 'File selected:';
            fileName.textContent = f.name;
            const mb = (f.size / (1024 * 1024)).toFixed(1);
            fileSize.textContent = '(' + mb + ' MB)';
            preview.classList.remove('hidden');
        } else {
            label.textContent = 'Upload Video File';
            preview.classList.add('hidden');
        }
    });

    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, function(e) {
            e.preventDefault();
            dropZone.classList.add('border-primary', 'bg-[#1a2e22]');
        });
    });
    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, function(e) {
            e.preventDefault();
            dropZone.classList.remove('border-primary', 'bg-[#1a2e22]');
        });
    });
    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        if (e.dataTransfer.files.length > 0) {
            input.files = e.dataTransfer.files;
            input.dispatchEvent(new Event('change'));
        }
    });
})();
</script>
<?php else: ?>
<p class="text-muted text-sm">No matches found. <a href="/matchmaking" class="text-primary hover:underline">Create a match</a> first.</p>
<?php endif; ?>
</div>

<!-- Uploaded Videos List -->
<?php
$matchesWithVideo = array_filter($userMatches, fn($m) => !empty($m['video_url']));
if (!empty($matchesWithVideo)):
?>
<div class="bg-white dark:bg-card-dark rounded-xl p-6 shadow-sm border border-slate-200 dark:border-[#264531] mb-6">
<h3 class="text-lg font-bold mb-4 flex items-center gap-2"><span class="material-symbols-outlined text-primary">video_library</span> Match Videos</h3>
<div class="space-y-4">
<?php foreach ($matchesWithVideo as $m):
    $vUrl = $m['video_url'] ?? '';
    $isLocal = str_starts_with($vUrl, '/videos/');
    $urlParts = $vUrl !== '' ? parse_url($vUrl) : [];
    $urlScheme = strtolower((string)($urlParts['scheme'] ?? ''));
    $isSafeExternal = in_array($urlScheme, ['http', 'https'], true);
?>
<div class="p-4 rounded-lg bg-slate-50 dark:bg-[#16261d] border border-slate-100 dark:border-[#264531]">
    <div class="flex items-center justify-between mb-3">
        <div>
            <p class="font-bold text-sm"><?= htmlspecialchars(($m['challanger'] ?? '') . ' vs ' . ($m['opponent'] ?? '')) ?></p>
            <p class="text-xs text-muted"><?= htmlspecialchars($m['date'] ?? '') ?> · <span class="text-primary"><?= htmlspecialchars($m['video_status'] ?? 'uploaded') ?></span></p>
        </div>
        <?php if (!$isLocal && $isSafeExternal): ?>
        <a href="<?= htmlspecialchars($vUrl) ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-1.5 bg-primary/10 text-primary text-xs font-bold rounded-lg hover:bg-primary hover:text-white transition-colors flex items-center gap-1">
            <span class="material-symbols-outlined text-sm">open_in_new</span> Watch
        </a>
        <?php endif; ?>
    </div>
    <?php if ($isLocal): ?>
    <video controls class="w-full rounded-lg max-h-[400px] bg-black" preload="metadata">
        <source src="<?= htmlspecialchars($vUrl) ?>" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <?php endif; ?>
</div>
<?php endforeach; ?>
</div>
</div>
<?php endif; ?>

<!-- Tips -->
<div class="bg-white dark:bg-card-dark rounded-xl p-6 border border-slate-200 dark:border-[#264531]">
    <h3 class="text-lg font-bold mb-3 flex items-center gap-2"><span class="material-symbols-outlined text-primary">tips_and_updates</span> Upload Tips</h3>
    <ul class="space-y-2 text-sm text-muted">
        <li class="flex items-start gap-2"><span class="material-symbols-outlined text-primary text-sm mt-0.5">check_circle</span> Supported formats: MP4, MOV, WebM, AVI, MKV (max 500MB)</li>
        <li class="flex items-start gap-2"><span class="material-symbols-outlined text-primary text-sm mt-0.5">check_circle</span> You can also paste a YouTube or external video URL</li>
        <li class="flex items-start gap-2"><span class="material-symbols-outlined text-primary text-sm mt-0.5">check_circle</span> Videos are linked to matches for easy review in Match History</li>
        <li class="flex items-start gap-2"><span class="material-symbols-outlined text-primary text-sm mt-0.5">check_circle</span> Create a match first in <a href="/matchmaking" class="text-primary hover:underline">Matchmaking</a> before uploading</li>
    </ul>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
