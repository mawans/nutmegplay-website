<?php
/**
 * Supabase Configuration
 * 
 * Replace these values with your actual Supabase project credentials.
 * Find them at: https://supabase.com/dashboard/project/YOUR_PROJECT/settings/api
 */
return [
    'url'  => getenv('SUPABASE_URL')
        ?: 'https://strddrjneurylxoolimj.supabase.co',
    'key'  => getenv('SUPABASE_KEY')
        ?: getenv('SUPABASE_ANON_KEY')
        ?: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0cmRkcmpuZXVyeWx4b29saW1qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2OTAwMTUsImV4cCI6MjA3OTI2NjAxNX0.Ydo4Ib7fT2IpPePuYUVxWiwm0fC_OpFSBCA7AOb-xcc',
    'service_role_key' => getenv('SUPABASE_SERVICE_ROLE_KEY')
        ?: '',
];
