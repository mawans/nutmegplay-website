# Local Supabase (Nutmeg)

## Start

```bash
docker compose up -d
```

API gateway URL: `http://127.0.0.1:54321`

## Stop

```bash
docker compose down
```

## Reset database (destructive)

```bash
docker compose down -v
docker compose up -d
```

## App credentials

The app reads Supabase credentials from `app/Config/supabase.php` only.
