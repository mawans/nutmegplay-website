<?php
declare(strict_types=1);

if (PHP_SAPI === 'cli-server') {
    $requestUri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($requestUri, PHP_URL_PATH) ?: '/';

    $directFile = realpath(__DIR__ . $path);
    if ($directFile !== false && is_file($directFile) && str_starts_with($directFile, __DIR__)) {
        return false;
    }

    $publicFile = realpath(__DIR__ . '/public' . $path);
    $publicRoot = realpath(__DIR__ . '/public');
    if (
        $publicFile !== false
        && $publicRoot !== false
        && str_starts_with($publicFile, $publicRoot)
        && is_file($publicFile)
    ) {
        $mimeType = function_exists('mime_content_type')
            ? mime_content_type($publicFile)
            : 'application/octet-stream';
        header('Content-Type: ' . ($mimeType ?: 'application/octet-stream'));
        header('Content-Length: ' . (string) filesize($publicFile));
        readfile($publicFile);
        return true;
    }
}

require_once __DIR__ . '/app/bootstrap.php';

$router = require __DIR__ . '/app/routes.php';

$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($requestUri, PHP_URL_PATH) ?? '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$router->dispatch($path, $method);
