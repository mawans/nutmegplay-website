import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";

const BG_DARK = "#0F0F0F";
const ORANGE = "#FF8C3A";
const GREY = "#999";
const LINE = "#444";
const WHITE = "#FFF";
const PRIMARY = "#1DB954";

export default function DivisionProgressBar({
  currentPoints = 3,
  relegation = 10,
  promotion = 16,
  title = 19,
  maxPoints = 19, // total scale
}) {
  const progressPercent = (currentPoints / maxPoints) * 200;
  const relPercent = (relegation / maxPoints) * 30;
  const promPercent = (promotion / maxPoints) * 60;
  const titlePercent = (title / maxPoints) * 90;

  return (
    <View style={styles.container}>
      {/* Full Bar */}
      <View style={styles.barContainer}>
        {/* Background Line */}
        <View style={styles.line} />

        {/* Current Progress Circle */}
        <View style={[styles.currentMarker, { left: `${progressPercent}%` }]}>
          <View style={styles.currentCircle}>
            <Text style={styles.currentText}>{currentPoints}</Text>
          </View>
        </View>

        {/* Relegation */}
        <View style={[styles.smallMarker, { left: `${relPercent}%` }]}>
          <Text style={styles.smallLabel}>10</Text>
          <View style={styles.smallDot} />
          <Text style={styles.smallText}>Relégation</Text>
        </View>

        {/* Promotion */}
        <View style={[styles.mediumMarker, { left: `${promPercent}%` }]}>
          <Text style={styles.smallLabel}>{promotion}</Text>
          <View style={styles.mediumDot} />
          <Text style={styles.smallText}>Montée</Text>
        </View>

        {/* Title */}
        <View style={[styles.titleMarker, { left: `${titlePercent}%` }]}>
          <Text style={[styles.smallLabel, { color: PRIMARY }]}>{title}</Text>
          <MaterialIcons
            name="emoji-events"
            size={20}
            color={PRIMARY}
            style={{ marginBottom: 4 }}
          />
          <Text style={[styles.smallText, { color: PRIMARY }]}>Titre</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    paddingVertical: 20,
    backgroundColor: BG_DARK,
  },

  barContainer: {
    width: "100%",
    height: 80,
    justifyContent: "center",
  },

  line: {
    position: "absolute",
    height: 6,
    width: "100%",
    backgroundColor: LINE,
    borderRadius: 10,
  },

  /* CURRENT PROGRESS */
  currentMarker: {
    position: "absolute",
    alignItems: "center",
    transform: [{ translateX: -15 }],
  },

  currentCircle: {
    width: 35,
    height: 35,
    borderRadius: 20,
    backgroundColor: ORANGE,
    justifyContent: "center",
    alignItems: "center",
  },

  currentText: {
    color: WHITE,
    fontWeight: "700",
    fontSize: 16,
  },

  /* RELEGATION */
  smallMarker: {
    position: "absolute",
    alignItems: "center",
    transform: [{ translateX: -10 }],
    top: 15,
  },
  smallDot: {
    width: 10,
    height: 10,
    backgroundColor: GREY,
    borderRadius: 10,
    marginVertical: 4,
  },
  smallLabel: {
    color: WHITE,
    fontWeight: "600",
    fontSize: 14,
  },
  smallText: {
    color: GREY,
    fontSize: 11,
    marginTop: 2,
  },

  /* PROMOTION */
  mediumMarker: {
    position: "absolute",
    alignItems: "center",
    transform: [{ translateX: -10 }],
    top: 15,
  },
  mediumDot: {
    width: 12,
    height: 12,
    backgroundColor: WHITE,
    borderRadius: 10,
    marginVertical: 4,
  },

  /* TITLE */
  titleMarker: {
    position: "absolute",
    alignItems: "center",
    transform: [{ translateX: -10 }],
    top: 13,
  },
});
