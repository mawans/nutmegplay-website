import React, { useEffect, useState, useCallback } from "react";
import {
  Dimensions,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
} from "react-native";
import * as Contacts from "expo-contacts";
import { FontAwesome } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";

const MOCK_FRIENDS = [
  {
    id: 1,
    name: "Leo Messi",
    username: "@leomessi",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCr5V76G7l4bocrAJfGx4LWGMhIDQYl7l_aoGMmoXRm4Phk0Ev6XD6Z6KDTZXG1Z3Pheqf5fFWIXeAvyDvEOory14KA2jzfWRFsoiLHiZ0BfnIGnPmO5RXkX8S91NdQGyrCApjhalCyMsbTydWhwZgUzx7FvLVeWMzBFiXsI1SBmEQyluW4BdRxsu_OO-AigUPsn54yo4WFWeARS-NsUsWtKGWUWx-FZptfn2vZk_RXruDN3P6v98OseHrIrzTP9gHdNDY2OSahXlPC",
  },
  {
    id: 2,
    name: "Cristiano Ronaldo",
    username: "@cristiano",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCLquxQPOmvlZfYP2gbVvJW2898nAu7Oth7bkZA4rTAMZwyLjXUtNA0rOFEJrl7CpPgiCERe2YMxHVKbSNULNGqHk1CKlB5-w5k2pJPpDDP88f9KAZ7_mf_wx_a2DbPRW_f1PibSfK6BcqBlkTjj8K3nw24dou5qxhkMlvLOi8-UtsQfZ4k9xsQUvjDYouQ-jkLMbWg3xS8nR0hUX1dfFtI6jP50duOlbQ9Cg6xPM7zZW_OZCyXWvEzdd3VT9QtGVWSaS086bFKRr7f",
  },
  {
    id: 3,
    name: "Neymar Jr",
    username: "@neymarjr",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAXUmpVhlxWfdyi_BU-mJZs7MKDZw7h_sDdpxYeFRuCOPCpMzc65bwzgCgpAgcbzpdxQ3UlLbXjFJVLKMAXOamm_rOXZfNampsmHXVXyKjGewrzDbmuX3Lgq34SqaK3P79iIvXpFw_j0gZnhxiOJoapxmoVmU1fZw5gYo5djVe2dMqYFpF26iPR34L4Q17aMT8h26RcwZgZ-pKb8IUMkc4MQiw71KwhoHzta2VYlYJ1xcWG7kTCXzU6Y-saNfX9eGOEjm1F51kTwBW0",
  },
  {
    id: 4,
    name: "Kylian Mbappé",
    username: "@k.mbappe",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDcAqerJKNWtkfZMhNxxNgoT5SFsynNIQJhbyaRmBl1wQhCSoyYU6wdnfahYVyrvqnJt_kCm6UbpiLOLHU4nSjR1qqfpSYUrDuH6kxOJihi_vUmklmxYho1gDB0KuxioyXbfyRArS9mMHUh8Ew9Q7S1ZEoQbDn-eY7bLcfWtb7lxlZHujqZWxeLU-A3Q8lpfr7_VHtE16h4gM_qXehOW4poIdkfKazb5isfs6EMy8ZfmW2CuYR8-nvQmbzBm7Osd4lVMLq-bA75spdn",
  },
];

export default function Invites({ setAddPlayer }) {
  const [toggle, setToggle] = useState(false); // false = Suggested, true = Contacts
  const [friends, setFriends] = useState(MOCK_FRIENDS);
  const [selectedIds, setSelectedIds] = useState([]);
  const [contacts, setContacts] = useState([]);

  const navigation = useNavigation();

  // ✅ Fetch Contacts
  useEffect(() => {
    (async () => {
      const { status } = await Contacts.requestPermissionsAsync();
      if (status !== "granted") return;
      const { data } = await Contacts.getContactsAsync({
        fields: [Contacts.Fields.Emails],
      });
      const formatted = data
        .filter((c) => c.name)
        .map((c, index) => ({
          id: index + 1000,
          name: c.name,
          username: c.emails?.[0]?.email || "",
          image: null,
        }));
      setContacts(formatted);
    })();
  }, []);

  // ✅ Toggle selection for suggested friends
  const toggleSelect = useCallback((id) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }, []);

  // ✅ Render a friend/contact row
  const renderItem = useCallback(
    (item) => {
      const isSelected = selectedIds.includes(item.id);
      return (
        <TouchableOpacity
          key={item.id}
          style={styles.friendItem}
          onPress={() => toggleSelect(item.id)}
          activeOpacity={0.7}
        >
          <View style={styles.friendInfo}>
            {item.image ? (
              <Image source={{ uri: item.image }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatar, { backgroundColor: "#444" }]}>
                <Text style={{ color: "#fff" }}>
                  {item.name.charAt(0).toUpperCase()}
                </Text>
              </View>
            )}
            <View>
              <Text style={styles.friendName}>{item.name}</Text>
              {item.username ? (
                <Text style={styles.friendUsername}>{item.username}</Text>
              ) : null}
            </View>
          </View>
          <View
            style={[
              styles.checkbox,
              isSelected && {
                backgroundColor: "#00C26D",
                borderColor: "#00C26D",
              },
            ]}
          />
        </TouchableOpacity>
      );
    },
    [selectedIds]
  );

  const listData = toggle ? contacts : friends;
  const invitedCount = selectedIds.length;

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}
    >
      {/* Header */}
      <View style={[styles.topBar, { marginTop: 70 }]}>
        <TouchableOpacity onPress={() => setAddPlayer(false)}>
          <FontAwesome name="arrow-left" color="#fff" size={25} />
        </TouchableOpacity>
        <Text style={styles.title}>Invite New Player</Text>
        <TouchableOpacity onPress={() => navigation.navigate("JoinMatch")}>
          <FontAwesome name="bell-o" color="#fff" size={25} />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.topBar}>
        <TextInput
          style={styles.textInput}
          placeholder="Search by username or email"
          placeholderTextColor="#cfcfcf"
        />
      </View>

      {/* Toggle */}
      <View style={styles.toggleContainer}>
        {["Suggested", "Contacts"].map((label, index) => {
          const active = toggle === (index === 1);
          return (
            <TouchableOpacity
              key={label}
              style={[styles.toggleButton, active && styles.toggleActive]}
              onPress={() => setToggle(index === 1)}
            >
              <Text style={[styles.toggleText, active && { color: "#00C26D" }]}>
                {label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* List */}
      <Text style={styles.sectionTitle}>
        {toggle ? "Your Contacts" : "Suggested Friends"}
      </Text>
      <ScrollView>
        {listData.length === 0 ? (
          <Text
            style={{
              color: "#888",
              textAlign: "center",
              marginTop: 50,
              fontSize: 16,
            }}
          >
            {toggle ? "No contacts found." : "No suggestions."}
          </Text>
        ) : (
          listData.map(renderItem)
        )}
      </ScrollView>

      {/* Floating Button */}
      {invitedCount > 0 && (
        <TouchableOpacity
          style={styles.fab}
          onPress={() =>
            Alert.alert(
              "Invitations Sent",
              `${invitedCount} player(s) invited successfully!`
            )
          }
        >
          <Text style={styles.fabText}>
            Send {invitedCount} Invitation{invitedCount > 1 ? "s" : ""}
          </Text>
        </TouchableOpacity>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: Dimensions.get("screen").width,
    height: Dimensions.get("screen").height,
    position: "absolute",
    zIndex: 9999,
    elevation: 9999,
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    height: 70,
  },
  title: { color: "#fff", fontSize: 22, fontWeight: "bold" },
  textInput: {
    flex: 1,
    height: 50,
    borderWidth: 1,
    borderColor: "#cfcfcf",
    borderRadius: 10,
    paddingHorizontal: 10,
    color: "#fff",
    fontSize: 16,
    backgroundColor: "#08090bff",
  },
  toggleContainer: {
    flexDirection: "row",
    height: 50,
  },
  toggleButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderBottomWidth: 1,
    borderBottomColor: "transparent",
  },
  toggleActive: {
    borderBottomColor: "#00C26D",
  },
  toggleText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  sectionTitle: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 18,
    fontWeight: "bold",
    color: "#fff",
  },
  friendItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    minHeight: 72,
  },
  friendInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  friendName: { fontSize: 16, fontWeight: "600", color: "#fff" },
  friendUsername: { fontSize: 13, color: "#aaa" },
  checkbox: {
    width: 28,
    height: 28,
    borderWidth: 2,
    borderColor: "#888",
    borderRadius: 14,
  },
  fab: {
    position: "absolute",
    bottom: 95,
    left: 16,
    right: 16,
    backgroundColor: "#00C26D",
    borderRadius: 32,
    height: 56,
    alignItems: "center",
    justifyContent: "center",
    elevation: 5,
  },
  fabText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});
