import React, { useEffect, useState } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { supabase } from "../screens/api/supabase";
import Toast from "react-native-toast-message";

export default function Clubbar({ club, onJoin }) {
  const [inviteId, setInviteId] = useState(null); // store invite row id

  useEffect(() => {
    checkInviteStatus();
  }, []);

  const checkInviteStatus = async () => {
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) return;

    const userId = user.id;

    const { data, error } = await supabase
      .from("invites")
      .select("id, club")
      .eq("sent_by", userId);

    if (error) return;

    const existingInvite = data?.find((item) => item.club?.id === club.id);

    if (existingInvite) {
      setInviteId(existingInvite.id);
    }
  };

  const sendInvite = async () => {
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      Toast.show({
        type: "error",
        text1: "Error",
        text2: "You must be logged in to send invites.",
      });
      return;
    }

    const userId = user.id;

    const { data, error } = await supabase
      .from("invites")
      .insert({
        club: {
          id: club.id,
          name: club.name,
          image: club.logo,
        },
        sent_by: userId,
        sent_to: club.owner,
        status: "pending",
        payment: "",
      })
      .select();

    if (error) {
      Toast.show({
        type: "error",
        text1: "Invite not sent",
        text2: error.message,
      });
      return;
    }

    Toast.show({
      type: "success",
      text1: "Invite Sent",
      text2: `You invited ${club.name}`,
    });

    console.log("Invite Sent →", data);

    // Store invite id for cancellation
    setInviteId(data[0].id);
  };

  const cancelInvite = async () => {
    if (!inviteId) return;

    const { error } = await supabase
      .from("invites")
      .delete()
      .eq("id", inviteId);

    if (error) {
      Toast.show({
        type: "error",
        text1: "Cancel Failed",
        text2: error.message,
      });
      return;
    }

    Toast.show({
      type: "success",
      text1: "Invite Cancelled",
      text2: `Your invite to ${club.name} was removed`,
    });

    setInviteId(null);
  };
  const handlePress = () => {
    if (inviteId) {
      cancelInvite();
    } else {
      sendInvite();
      onJoin?.(club);
    }
  };

  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <Image source={{ uri: club.logo }} style={styles.clubLogo} />

        <View style={styles.clubInfo}>
          <Text style={styles.clubName}>{club.name}</Text>
          <Text style={styles.clubPlayers}>{club.players}</Text>
        </View>
      </View>

      {inviteId ? (
        <TouchableOpacity
          style={[styles.requestSentBtn, { backgroundColor: "#8A1E1E" }]}
          onPress={handlePress}
        >
          <MaterialIcons name="close" size={20} color="#FFF" />
          <Text style={styles.requestSentText}>Cancel Request</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={[styles.joinBtn]} onPress={handlePress}>
          <Text style={styles.joinBtnText}>Send Join Request</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#1C1C1E",
    padding: 16,
    borderRadius: 14,
    marginBottom: 16,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  clubLogo: {
    width: 48,
    height: 48,
    borderRadius: 48,
  },

  clubInfo: {
    marginLeft: 12,
    flex: 1,
  },

  clubName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },

  clubPlayers: {
    fontSize: 14,
    color: "#9dabb9",
    marginTop: 2,
  },

  joinBtn: {
    backgroundColor: "#00A86B",
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },

  joinBtnText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "500",
  },

  requestSentBtn: {
    backgroundColor: "#4B5563",
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },

  requestSentText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginLeft: 6,
  },
});
