import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { supabase } from "./api/supabase";

export default function CreateAnnouncement() {
  const navigation = useNavigation();
  const route = useRoute();

  const [center, setCenter] = useState("");
  const [message, setMessage] = useState("");
  const [date, setDate] = useState(new Date());
  const [time, setTime] = useState(new Date());
  const [dateModalOpen, setDateModalOpen] = useState(false);
  const [timeModalOpen, setTimeModalOpen] = useState(false);

  // UI formats
  const formattedDate = date.toLocaleDateString();
  const formattedTime = time.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  const days = [...Array(31)].map((_, i) => i + 1);
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const years = [...Array(6)].map((_, i) => 2024 + i);

  const hours = [...Array(12)].map((_, i) => i + 1);
  const minutes = [...Array(60)].map((_, i) => i);
  const ampm = ["AM", "PM"];

  const createAnnouncement = async () => {
    try {
      // 1) auth
      const { data: userData, error: authError } =
        await supabase.auth.getUser();
      if (authError) {
        console.log("AUTH ERROR:", authError);
        alert("Authentication error. Please login again.");
        return;
      }

      const user = userData?.user;
      if (!user) {
        alert("You must be logged in.");
        return;
      }

      // 2) basic field checks
      if (!route.params || !route.params.club) {
        console.log("ROUTE PARAMS:", route.params);
        alert("Club information is missing.");
        return;
      }

      if (!center.trim() || !message.trim()) {
        alert("Please fill Center and Message.");
        return;
      }

      // 3) format date & time for DB (TEXT columns)
      const dbDate = date.toISOString().split("T")[0];
      const dbTime = time.toTimeString().slice(0, 5);

      const payload = {
        location: center.trim(),
        date: dbDate,
        time: dbTime,
        message: message.trim(),
        response: "",
        club: route.params.club.name,
        user_id: user.id,
      };

      console.log("INSERTING ANNOUNCEMENT PAYLOAD:", payload);

      // 4) insert into Supabase
      const { data, error } = await supabase
        .from("announcement")
        .insert(payload)
        .select()
        .single();

      if (error) {
        console.log("INSERT ERROR:", error);
        alert(error.message || "Could not save announcement.");
        return;
      }

      console.log("ANNOUNCEMENT INSERTED:", data);
      navigation.goBack();
    } catch (err) {
      console.log("UNEXPECTED ERROR:", err);
      alert("Unexpected error. Check console for details.");
    }
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1, paddingTop: 30 }}
    >
      <SafeAreaProvider style={styles.root}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="close" size={26} color="#F5F5F5" />
          </TouchableOpacity>

          <Text style={styles.headerTitle}>Create Announcement</Text>

          <View style={{ width: 48 }} />
        </View>

        {/* Content */}
        <ScrollView contentContainerStyle={styles.content}>
          {/* Center */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Center</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                value={center}
                onChangeText={setCenter}
                placeholder="e.g., Urban Five Paris"
                placeholderTextColor="#9DABB9"
                style={styles.input}
              />
              <View style={styles.iconRight}>
                <MaterialIcons name="location-on" size={22} color="#9DABB9" />
              </View>
            </View>
          </View>

          {/* DATE + TIME */}
          <View style={styles.row}>
            {/* Date */}
            <View style={styles.fieldGroupRow}>
              <Text style={styles.label}>Date</Text>

              <TouchableOpacity
                style={styles.inputWrapper}
                onPress={() => setDateModalOpen(true)}
              >
                <Text style={[styles.input, { paddingVertical: 15 }]}>
                  {formattedDate}
                </Text>
                <View style={styles.iconRight}>
                  <MaterialIcons
                    name="calendar-month"
                    size={22}
                    color="#9DABB9"
                  />
                </View>
              </TouchableOpacity>
            </View>

            {/* Time */}
            <View style={styles.fieldGroupRow}>
              <Text style={styles.label}>Time</Text>

              <TouchableOpacity
                style={styles.inputWrapper}
                onPress={() => setTimeModalOpen(true)}
              >
                <Text style={[styles.input, { paddingVertical: 15 }]}>
                  {formattedTime}
                </Text>
                <View style={styles.iconRight}>
                  <MaterialIcons name="schedule" size={22} color="#9DABB9" />
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {/* Message */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Message</Text>
            <TextInput
              placeholder="Need 1 player for a 5v5..."
              placeholderTextColor="#9DABB9"
              multiline
              style={styles.textArea}
              value={message}
              onChangeText={setMessage}
            />
          </View>
        </ScrollView>

        {/* Footer */}
        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.ctaButton}
            onPress={createAnnouncement}
          >
            <Text style={styles.ctaText}>Broadcast Announcement</Text>
          </TouchableOpacity>
        </View>

        {/* DATE MODAL */}
        {dateModalOpen && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <Text style={styles.modalTitle}>Select Date</Text>

              <View style={styles.selectorRow}>
                {/* Day */}
                <ScrollView style={styles.selector}>
                  {days.map((d) => (
                    <Text
                      key={d}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newDate = new Date(date);
                        newDate.setDate(d);
                        setDate(newDate);
                      }}
                    >
                      {d}
                    </Text>
                  ))}
                </ScrollView>

                {/* Month */}
                <ScrollView style={styles.selector}>
                  {months.map((m, idx) => (
                    <Text
                      key={m}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newDate = new Date(date);
                        newDate.setMonth(idx);
                        setDate(newDate);
                      }}
                    >
                      {m}
                    </Text>
                  ))}
                </ScrollView>

                {/* Year */}
                <ScrollView style={styles.selector}>
                  {years.map((y) => (
                    <Text
                      key={y}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newDate = new Date(date);
                        newDate.setFullYear(y);
                        setDate(newDate);
                      }}
                    >
                      {y}
                    </Text>
                  ))}
                </ScrollView>
              </View>

              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => setDateModalOpen(false)}
              >
                <Text style={{ color: "#fff", fontSize: 16 }}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* TIME MODAL */}
        {timeModalOpen && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <Text style={styles.modalTitle}>Select Time</Text>

              <View style={styles.selectorRow}>
                {/* Hour */}
                <ScrollView style={styles.selector}>
                  {hours.map((h) => (
                    <Text
                      key={h}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newTime = new Date(time);
                        let hour24 = newTime.getHours();
                        const currentPeriod = hour24 >= 12 ? "PM" : "AM";

                        // convert clicked `h` (1–12) to 24h based on current AM/PM
                        if (currentPeriod === "PM") {
                          hour24 = h === 12 ? 12 : h + 12;
                        } else {
                          hour24 = h === 12 ? 0 : h;
                        }

                        newTime.setHours(hour24);
                        setTime(newTime);
                      }}
                    >
                      {h}
                    </Text>
                  ))}
                </ScrollView>

                {/* Minutes */}
                <ScrollView style={styles.selector}>
                  {minutes.map((m) => (
                    <Text
                      key={m}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newTime = new Date(time);
                        newTime.setMinutes(m);
                        setTime(newTime);
                      }}
                    >
                      {m < 10 ? `0${m}` : m}
                    </Text>
                  ))}
                </ScrollView>

                {/* AM / PM */}
                <ScrollView style={styles.selector}>
                  {ampm.map((period) => (
                    <Text
                      key={period}
                      style={styles.selectorItem}
                      onPress={() => {
                        const newTime = new Date(time);
                        let hour = newTime.getHours();

                        if (period === "PM" && hour < 12) hour += 12;
                        if (period === "AM" && hour >= 12) hour -= 12;

                        newTime.setHours(hour);
                        setTime(newTime);
                      }}
                    >
                      {period}
                    </Text>
                  ))}
                </ScrollView>
              </View>

              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => setTimeModalOpen(false)}
              >
                <Text style={{ color: "#fff", fontSize: 16 }}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </SafeAreaProvider>
    </LinearGradient>
  );
}

/* ===========================================================
   STYLES
=========================================================== */

const BG = "#111418";
const TEXT = "#F5F5F5";
const BORDER = "#3b4754";
const INPUT_BG = "#1c2127";
const PRIMARY = "#2ECC71";

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    paddingTop: 12,
    flexDirection: "row",
    alignItems: "center",
  },
  iconButton: {
    height: 48,
    width: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1,
  },
  headerTitle: {
    flex: 1,
    textAlign: "center",
    color: TEXT,
    fontSize: 18,
    fontWeight: "700",
    marginLeft: -48,
  },

  content: {
    paddingHorizontal: 16,
    paddingBottom: 40,
    paddingTop: 12,
  },
  fieldGroup: { marginBottom: 22 },
  fieldGroupRow: { flex: 1, marginBottom: 22 },

  label: {
    color: TEXT,
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
  },

  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: INPUT_BG,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: BORDER,
    paddingVertical: 4,
  },
  input: {
    flex: 1,
    paddingHorizontal: 16,
    fontSize: 16,
    color: TEXT,
    paddingVertical: 12,
    height: 50,
  },
  iconRight: {
    paddingHorizontal: 14,
    borderLeftWidth: 1,
    borderColor: BORDER,
  },

  textArea: {
    backgroundColor: INPUT_BG,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: BORDER,
    paddingHorizontal: 16,
    paddingVertical: 16,
    height: 140,
    color: TEXT,
    fontSize: 16,
    textAlignVertical: "top",
  },

  row: { flexDirection: "row", gap: 12 },

  footer: {
    padding: 16,
    backgroundColor: BG,
    borderTopWidth: 1,
    borderColor: BORDER,
  },
  ctaButton: {
    backgroundColor: PRIMARY,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  ctaText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },

  modalOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 999,
  },
  modalContainer: {
    width: "85%",
    backgroundColor: INPUT_BG,
    padding: 20,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: BORDER,
  },
  modalTitle: {
    color: TEXT,
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 15,
  },
  selectorRow: { flexDirection: "row", justifyContent: "space-between" },
  selector: {
    height: 150,
    width: "30%",
  },
  selectorItem: {
    color: TEXT,
    fontSize: 18,
    paddingVertical: 8,
    textAlign: "center",
  },
  modalButton: {
    marginTop: 20,
    backgroundColor: PRIMARY,
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
});
