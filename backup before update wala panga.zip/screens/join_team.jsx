import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { supabase } from "./api/supabase";
import Toast from "react-native-toast-message";
import Clubbar from "../components/clubbar";

export default function Jointeam() {
  const [clubs, setClubs] = useState([]);
  const [search, setSearch] = useState("");
  const [filtered, setFiltered] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchClubs = async () => {
      const { data, error } = await supabase.from("clubs").select("*");

      if (error) {
        Toast.show({ type: "error", text1: "Error", text2: error.message });
        return;
      }

      //   console.log("Fetched clubs:", data);

      const mapped = data.map((club) => ({
        id: club.id,
        name: club.name,
        logo: club.logo,
        players: `${club.number_player ?? 1} / 5 Players`,
        requested: false,
        owner: club.owner,
      }));

      setClubs(mapped);
    };

    fetchClubs();
  }, []);

  const handleSearch = (text) => {
    setSearch(text);

    if (text.trim().length === 0) {
      setFiltered([]);
      return;
    }

    const results = clubs.filter((club) =>
      club.name.toLowerCase().includes(text.toLowerCase())
    );

    setFiltered(results);
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}
    >
      <SafeAreaView>
        {/* Top Bar */}
        <View style={styles.topBar}>
          <MaterialIcons
            name="arrow-back-ios"
            size={22}
            color="#FFFFFF"
            onPress={() => navigation.goBack()}
          />
          <Text style={styles.title}>Browse Clubs</Text>
          <View style={{ width: 30 }} />
        </View>

        {/* Search Bar */}
        <View style={styles.searchWrapper}>
          <View style={styles.searchBar}>
            <MaterialIcons name="search" size={20} color="#9dabb9" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search for a club..."
              placeholderTextColor="#9dabb9"
              value={search}
              onChangeText={handleSearch}
            />
          </View>

          {filtered.length > 0 && (
            <View style={styles.dropdown}>
              {filtered.map((club) => (
                <TouchableOpacity
                  key={club.id}
                  style={styles.dropdownItem}
                  onPress={() => {
                    setSearch(club.name);
                    setFiltered([]);
                  }}
                >
                  <Image
                    source={{ uri: club.logo }}
                    style={styles.dropdownLogo}
                  />
                  <Text style={styles.dropdownText}>{club.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <ScrollView contentContainerStyle={styles.listContainer}>
          {clubs
            .filter((club) =>
              search.length === 0
                ? true
                : club.name.toLowerCase().includes(search.toLowerCase())
            )
            .map((club) => (
              <Clubbar
                key={club.id}
                club={club}
                onJoin={(selectedClub) => {
                  console.log("User wants to join:", selectedClub);
                }}
              />
            ))}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#101922",
  },

  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },

  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FFFFFF",
  },

  searchWrapper: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    zIndex: 50,
  },

  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#283039",
    paddingHorizontal: 12,
    height: 44,
    borderRadius: 10,
  },

  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: "#FFFFFF",
    fontSize: 16,
  },

  dropdown: {
    backgroundColor: "#1C1C1E",
    marginTop: 8,
    borderRadius: 10,
    paddingVertical: 6,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 5,
  },

  dropdownItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 12,
  },

  dropdownLogo: {
    width: 30,
    height: 30,
    borderRadius: 30,
    marginRight: 10,
  },

  dropdownText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "500",
  },

  listContainer: {
    paddingHorizontal: 16,
    paddingBottom: 100,
  },

  card: {
    backgroundColor: "#1C1C1E",
    padding: 16,
    borderRadius: 14,
    marginBottom: 16,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  clubLogo: {
    width: 48,
    height: 48,
    borderRadius: 48,
  },

  clubInfo: {
    marginLeft: 12,
    flex: 1,
  },

  clubName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },

  clubPlayers: {
    fontSize: 14,
    color: "#9dabb9",
    marginTop: 2,
  },

  joinBtn: {
    backgroundColor: "#00A86B",
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },

  joinBtnText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "500",
  },

  requestSentBtn: {
    backgroundColor: "#4B5563",
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },

  requestSentText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginLeft: 6,
  },
});
