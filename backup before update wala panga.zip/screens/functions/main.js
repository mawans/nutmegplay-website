export function ApplyXpProgress(currentOvr, currentXp, gainedXp) {
  let ovr = currentOvr;
  let xp = currentXp + gainedXp;

  while (true) {
    const xpRequired = GetXpRequiredForNextOvr(ovr);
    if (xpRequired === null || xp < xpRequired) break;

    xp -= xpRequired;
    ovr += 1;
  }

  return {
    newOvr: ovr,
    remainingXp: xp,
  };
}

export function CalculateMatchXp(stats, context) {
  let xp = 0;
  xp += 30;

  xp += Math.min(Math.floor(stats.distanceMeters / 500), 10);
  xp += Math.min(Math.floor(stats.sprints / 3), 10);

  xp += Math.min(Math.floor(stats.successfulPasses / 5), 10);
  xp += Math.min(stats.successfulDribbles * 3, 9);
  xp += Math.min((stats.interceptions + stats.duelsWon) * 2, 10);
  xp += Math.min(stats.goals * 15, 30);

  if (context.result === "win") xp += 35;
  else if (context.result === "draw") xp += 20;
  else xp += 10;

  if (stats.goals >= 3) xp += 20;
  else if (stats.goals === 2) xp += 10;

  if (context.matchWinningGoal && stats.goals >= 1) xp += 30;

  if (stats.assists >= 2) xp += 10;

  if (stats.successfulDribbles >= 8) xp += 30;
  else if (stats.successfulDribbles >= 5) xp += 10;

  if (stats.interceptions + stats.duelsWon >= 5) xp += 15;

  if (context.cleanSheet) xp += 25;

  if (stats.sprints >= 20 || stats.distanceMeters >= 7000) xp += 15;

  if (context.teamWinStreak >= 3) xp += 10;

  return xp;
}

export function GetXpRequiredForNextOvr(currentOvr) {
  if (currentOvr >= 99) return null;

  if (currentOvr < 50) return 200;

  const baseXpAt50 = 300;
  const incrementPerLevel = 20;

  return baseXpAt50 + (currentOvr - 50) * incrementPerLevel;
}

// export { ApplyXpProgress, CalculateMatchXp, GetXpRequiredForNextOvr };
