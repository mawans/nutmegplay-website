import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  Image,
  Alert,
} from "react-native";

import * as Linking from "expo-linking";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { supabase } from "../api/supabase";

export default function Login() {
  const navigation = useNavigation();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [loading, setLoading] = useState(false);

  const login_ = async () => {
    if (!validateEmail(email)) {
      Alert.alert("Invalid Email", "Please enter a valid email address.");
      return;
    }
    if (!password) {
      Alert.alert("Missing Password", "Please enter your password.");
      return;
    }

    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);

    if (error) {
      Alert.alert("Login Failed", error.message);
      return;
    }

    setEmail("");
    setPassword("");
  };

  const validateEmail = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    return emailRegex.test(email);
  };

  useEffect(() => {
    const handleDeepLink = async ({ url }) => {
      console.log("DEEPLINK URL:", url);

      const { data, error } = await supabase.auth.getSession();

      if (data?.session) {
        // navigation.replace("Home");
      }

      if (error) {
        console.log("Session error:", error.message);
      }
    };

    const sub = Linking.addEventListener("url", handleDeepLink);
    return () => sub.remove();
  }, []);

  useEffect(() => {
    const sub = Linking.addEventListener("url", ({ url }) => {
      console.log("DEEPLINK URL:", url);
    });

    return () => sub.remove();
  }, []);

  const loginWithGoogle = async () => {
    const redirectUrl = Linking.createURL("login");

    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: redirectUrl,
      },
    });

    if (error) {
      console.log("OAuth error:", error.message);
    }
  };

  return (
    <ImageBackground
      source={require("../../assets/field-bg.jpg")}
      style={styles.background}
    >
      <View style={styles.overlay}>
        <LinearGradient
          colors={["rgba(30,60,30,.9)", "rgba(20,40,20,0.9)"]}
          style={styles.card}
        >
          {/* Logo and Title */}
          <View style={styles.logoContainer}>
            <View style={styles.logoCircle}>
              <Image
                source={require("../../assets/logotp.png")}
                style={{
                  width: 30,
                  height: 30,
                }}
              />
              {/* <Ionicons name="ellipse-outline" size={24} color="#00C26D" /> */}
            </View>
            <Text style={styles.logoText}>NUTMEG PLAY</Text>
          </View>

          <Text style={styles.welcome}>Welcome Back!</Text>
          <Text style={styles.subtitle}>Sign in to continue your journey.</Text>

          {/* Email */}
          <View style={styles.inputContainer}>
            <Ionicons name="person-outline" size={20} color="#A5B4A8" />
            <TextInput
              placeholder="Email or Username"
              placeholderTextColor="#A5B4A8"
              style={styles.input}
              value={email}
              onChangeText={(val) => setEmail(val)}
            />
          </View>

          {/* Password */}
          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color="#A5B4A8" />
            <TextInput
              placeholder="Password"
              placeholderTextColor="#A5B4A8"
              secureTextEntry
              style={styles.input}
              value={password}
              onChangeText={(val) => setPassword(val)}
            />
          </View>

          {/* Forgot Password */}
          <TouchableOpacity
            style={styles.forgotBtn}
            onPress={() => navigation.navigate("ForgotPassword")}
          >
            <Text style={styles.forgotText}>Forgot Password?</Text>
          </TouchableOpacity>

          {/* Login Button */}
          <TouchableOpacity
            style={[styles.loginBtn, loading && { opacity: 0.6 }]}
            onPress={() => login_()}
            disabled={loading}
          >
            <Text style={styles.loginText}>
              {loading ? "Signing in..." : "Login"}
            </Text>
          </TouchableOpacity>

          {/* OR Line */}
          <View style={styles.dividerContainer}>
            <View style={styles.line} />
            <Text style={styles.orText}>Or continue with</Text>
            <View style={styles.line} />
          </View>

          {/* Social Buttons */}
          <View style={styles.socialRow}>
            <TouchableOpacity
              style={styles.socialBtn}
              onPress={loginWithGoogle}
            >
              <FontAwesome name="google" size={24} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialBtn}>
              <FontAwesome name="facebook" size={24} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialBtn}>
              <FontAwesome name="apple" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          {/* Sign Up */}
          <TouchableOpacity onPress={() => navigation.navigate("Signup")}>
            <Text style={styles.signupText}>
              Don’t have an account?{" "}
              <Text style={styles.signupLink}>Sign Up</Text>
            </Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  card: {
    width: "85%",
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  logoCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#083d1b",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  logoText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 22,
  },
  welcome: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 20,
    marginTop: 8,
  },
  subtitle: {
    color: "#C9D4C8",
    textAlign: "center",
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  input: {
    color: "#fff",
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
  },
  forgotBtn: {
    alignSelf: "flex-end",
    marginTop: 4,
  },
  forgotText: {
    color: "#00C26D",
    fontWeight: "600",
  },
  loginBtn: {
    backgroundColor: "#00C26D",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    width: "100%",
    marginVertical: 16,
  },
  loginText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  dividerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 12,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: "#9BAA9B",
  },
  orText: {
    color: "#C9D4C8",
    marginHorizontal: 8,
  },
  socialRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    marginVertical: 10,
  },
  socialBtn: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
    width: 60,
  },
  signupText: {
    color: "#C9D4C8",
    marginTop: 12,
  },
  signupLink: {
    color: "#00C26D",
    fontWeight: "bold",
  },
});
