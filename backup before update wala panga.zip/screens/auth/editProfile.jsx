import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  Image,
  Platform,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import * as ImagePicker from "expo-image-picker";
import { Dropdown } from "react-native-element-dropdown";
import { supabase } from "../api/supabase";

// ⚽ Local positions
const positions = [
  { label: "Goalkeeper (GK)", value: "GK" },
  { label: "Defender (DF)", value: "DF" },
  { label: "Midfielder (MF)", value: "MF" },
  { label: "Attacker (ATT)", value: "ATT" },
];

// Fetch countries (same as your signup)
const fetchCountries = async () => {
  try {
    const res = await fetch(
      "https://restcountries.com/v3.1/all?fields=name,cca2"
    );
    const data = await res.json();

    return data
      .map((c) => ({ label: c.name.common, value: c.cca2 }))
      .sort((a, b) => a.label.localeCompare(b.label));
  } catch (err) {
    return [
      { label: "France", value: "FR" },
      { label: "Pakistan", value: "PK" },
      { label: "United States", value: "US" },
      { label: "United Kingdom", value: "UK" },
      { label: "Canada", value: "CA" },
    ];
  }
};

export default function EditProfile() {
  const navigation = useNavigation();

  const [loadingPage, setLoadingPage] = useState(true);
  const [loadingCountries, setLoadingCountries] = useState(true);

  const [countries, setCountries] = useState([]);

  const [name, setName] = useState("");
  const [email, setEmail] = useState(""); // READ ONLY
  const [photo, setPhoto] = useState(null);
  const [nationality, setNationality] = useState(null);
  const [position, setPosition] = useState(null);
  const [password, setPassword] = useState(""); // optional update

  useEffect(() => {
    loadProfile();
    loadCountries();

    if (Platform.OS !== "web") {
      ImagePicker.requestMediaLibraryPermissionsAsync();
    }
  }, []);

  // Load countries
  const loadCountries = async () => {
    const data = await fetchCountries();
    setCountries(data);
    setLoadingCountries(false);
  };

  // Load user profile
  const loadProfile = async () => {
    const { data: userData } = await supabase.auth.getUser();
    const uid = userData?.user?.id;
    if (!uid) return;

    const { data, error } = await supabase
      .from("accounts")
      .select("*")
      .eq("uid", uid)
      .single();

    if (data) {
      setName(data.fname);
      setEmail(data.email);
      setNationality(data.country);
      setPosition(data.position);
      setPhoto(data.image_url);
    }

    setLoadingPage(false);
  };

  // Pick image
  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      setPhoto(result.assets[0].uri);
    }
  };

  // Update Profile
  const updateAccount = async () => {
    try {
      setLoadingPage(true);

      // 1️⃣ Get logged in user
      const { data: userData, error: userError } =
        await supabase.auth.getUser();
      if (userError || !userData?.user) {
        alert("Not logged in");
        setLoadingPage(false);
        return;
      }

      const uid = userData.user.id;

      // 2️⃣ Validate fields
      if (!name.trim() || !nationality || !position || !email.trim()) {
        alert("Please fill all required fields");
        setLoadingPage(false);
        return;
      }

      // 3️⃣ Update password (optional)
      if (password.trim().length > 0) {
        const { error: pwdError } = await supabase.auth.updateUser({
          password: password.trim(),
        });

        if (pwdError) {
          alert("Password update failed: " + pwdError.message);
          setLoadingPage(false);
          return;
        }
      }

      // 4️⃣ Upload profile image if it's a local file
      let updatedImage = photo;

      if (photo && photo.startsWith("file")) {
        const { data: sessionData } = await supabase.auth.getSession();
        const token = sessionData.session.access_token;

        const ext = photo.split(".").pop() || "jpg";
        const fileName = `profile_${uid}.${ext}`;
        const filePath = `profile_images/${fileName}`; // folder inside bucket

        // Build FormData for Expo fetch upload
        const formData = new FormData();
        formData.append("file", {
          uri: photo,
          name: fileName,
          type: `image/${ext}`,
        });

        // Upload to Supabase Storage (correct bucket path)
        const uploadRes = await fetch(
          `${process.env.EXPO_PUBLIC_SUPABASE_URL}/storage/v1/object/nutmegplay/${filePath}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "x-upsert": "true",
            },
            body: formData,
          }
        );

        if (!uploadRes.ok) {
          console.log("UPLOAD ERROR:", await uploadRes.text());
          throw new Error("Image upload failed");
        }

        // ■ Get public image URL from Supabase
        const { data: urlData } = supabase.storage
          .from("nutmegplay")
          .getPublicUrl(filePath);

        updatedImage = urlData.publicUrl;
      }

      // 5️⃣ Update the user's account in DB
      const { error: updateError } = await supabase
        .from("accounts")
        .update({
          fname: name,
          country: nationality,
          position: position,
          image_url: updatedImage,
        })
        .eq("uid", uid);

      if (updateError) {
        alert("Database update failed: " + updateError.message);
        setLoadingPage(false);
        return;
      }

      // 6️⃣ Success
      alert("Profile updated successfully!");
      navigation.goBack();
    } catch (err) {
      console.log("Update Profile Error:", err);
      alert("Something went wrong: " + err.message);
    } finally {
      setLoadingPage(false);
    }
  };

  if (loadingPage) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator color="#00C26D" size="large" />
      </View>
    );
  }

  return (
    <LinearGradient
      style={styles.background}
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <View style={styles.overlay}>
        {/* Back button */}
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="close" color={"white"} size={23} />
        </TouchableOpacity>

        <ScrollView
          style={{ flex: 1, width: "100%" }}
          contentContainerStyle={{ paddingBottom: 50 }}
        >
          <View
            style={[
              styles.card,
              { alignSelf: "center", marginBottom: 100, marginTop: 60 },
            ]}
          >
            {/* Title */}
            <Text style={styles.welcome}>Edit Profile</Text>
            <Text style={styles.subtitle}>Update your information</Text>

            {/* Photo */}
            <TouchableOpacity style={styles.photoContainer} onPress={pickImage}>
              {photo ? (
                <Image source={{ uri: photo }} style={styles.photo} />
              ) : (
                <View style={styles.photoPlaceholder}>
                  <Ionicons name="camera" size={30} color="#A5B4A8" />
                  <Text style={{ color: "#A5B4A8", fontSize: 12 }}>
                    Add Photo
                  </Text>
                </View>
              )}
            </TouchableOpacity>

            {/* Full Name */}
            <View style={styles.inputContainer}>
              <Ionicons name="person-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="Full Name"
                placeholderTextColor="#A5B4A8"
                style={styles.input}
                value={name}
                onChangeText={setName}
              />
            </View>

            {/* Nationality */}
            <View style={styles.dropdownContainer}>
              <Ionicons name="flag-outline" size={20} color="#A5B4A8" />
              <View style={{ flex: 1, marginLeft: 10 }}>
                {loadingCountries ? (
                  <ActivityIndicator color="#00C26D" />
                ) : (
                  <Dropdown
                    style={styles.dropdownSearchable}
                    data={countries}
                    labelField="label"
                    valueField="value"
                    placeholder="Select Nationality"
                    value={nationality}
                    selectedTextStyle={{ color: "#00C26D" }}
                    placeholderStyle={{ color: "#A5B4A8" }}
                    onChange={(item) => setNationality(item.value)}
                  />
                )}
              </View>
            </View>

            {/* Position */}
            <View style={styles.dropdownContainer}>
              <Ionicons name="football-outline" size={20} color="#A5B4A8" />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Dropdown
                  style={styles.dropdownSearchable}
                  data={positions}
                  labelField="label"
                  valueField="value"
                  placeholder="Select Position"
                  value={position}
                  selectedTextStyle={{ color: "#00C26D" }}
                  onChange={(item) => setPosition(item.value)}
                />
              </View>
            </View>

            {/* Email (READ ONLY) */}
            <View style={[styles.inputContainer, { opacity: 0.5 }]}>
              <Ionicons name="mail-outline" size={20} color="#A5B4A8" />
              <TextInput
                editable={false}
                value={email}
                style={[styles.input, { color: "#bbb" }]}
              />
            </View>

            {/* Optional Password */}
            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="New Password (optional)"
                placeholderTextColor="#A5B4A8"
                secureTextEntry
                style={styles.input}
                value={password}
                onChangeText={setPassword}
              />
            </View>

            {/* Save Button */}
            <TouchableOpacity
              style={styles.loginBtn}
              onPress={() => updateAccount()}
            >
              <Text style={styles.loginText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1 },
  overlay: {
    flex: 1,
    alignItems: "center",
  },
  backButton: {
    padding: 10,
    position: "absolute",
    top: 30,
    left: 20,
    zIndex: 10,
  },
  card: {
    width: "85%",
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
  },
  welcome: { color: "#fff", fontWeight: "700", fontSize: 22 },
  subtitle: { color: "#C9D4C8", marginBottom: 20 },
  photoContainer: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },
  photo: { width: 90, height: 90, borderRadius: 45 },
  photoPlaceholder: { alignItems: "center" },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  input: { color: "#fff", flex: 1, marginLeft: 10 },
  dropdownContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  dropdownSearchable: { height: 45, color: "white" },
  loginBtn: {
    backgroundColor: "#00C26D",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    width: "100%",
    marginVertical: 12,
  },
  loginText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});
