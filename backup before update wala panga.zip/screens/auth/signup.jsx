import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  Image,
  Platform,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import * as ImagePicker from "expo-image-picker";
import { Dropdown } from "react-native-element-dropdown";
import { supabase } from "../api/supabase";

// ⚽ Local positions model
const positions = [
  { label: "Goalkeeper (GK)", value: "GK" },
  { label: "Defender (DF)", value: "DF" },
  { label: "Midfielder (MF)", value: "MF" },
  { label: "Attacker (ATT)", value: "ATT" },
];

// Fetch countries
const fetchCountries = async () => {
  try {
    const res = await fetch(
      "https://restcountries.com/v3.1/all?fields=name,cca2"
    );
    if (!res.ok) throw new Error("Failed to fetch countries");

    const data = await res.json();
    if (!Array.isArray(data)) return [];

    // Map to {label, value} format
    const countryNames = data
      .map((c) => ({ label: c.name.common, value: c.cca2 }))
      .sort((a, b) => a.label.localeCompare(b.label));

    return countryNames;
  } catch (err) {
    console.error("Country Fetch Error:", err);
    // fallback
    return [
      { label: "France", value: "FR" },
      { label: "Pakistan", value: "PK" },
      { label: "United States", value: "US" },
      { label: "United Kingdom", value: "UK" },
      { label: "Canada", value: "CA" },
    ];
  }
};

export default function Signup() {
  const navigation = useNavigation();

  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [password, setpassword] = useState();
  const [cpassword, setCpassword] = useState();
  const [nationality, setNationality] = useState(null);
  const [position, setPosition] = useState("");
  const [photo, setPhoto] = useState(null);
  const [countries, setCountries] = useState([]);
  const [loadingCountries, setLoadingCountries] = useState(true);
  const [isFocusNationality, setIsFocusNationality] = useState(false);
  const [isFocusPosition, setIsFocusPosition] = useState(false);

  useEffect(() => {
    // Fetch countries
    (async () => {
      const data = await fetchCountries();
      setCountries(data);
      setLoadingCountries(false);
    })();

    if (Platform.OS !== "web") {
      ImagePicker.requestMediaLibraryPermissionsAsync();
    }
  }, []);

  // create account
  const createAccount = async () => {
    try {
      // ----------------------------------
      // 1️⃣ BASIC VALIDATION
      // ----------------------------------
      if (
        !name ||
        !email ||
        !password ||
        !cpassword ||
        !nationality ||
        !position
      ) {
        alert("Please fill all fields");
        return;
      }

      if (!validateEmail(email)) {
        alert("Invalid email address");
        return;
      }

      if (password !== cpassword) {
        alert("Passwords do not match");
        return;
      }

      // ----------------------------------
      // 2️⃣ SIGN UP USER (NO SESSION YET)
      // ----------------------------------
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        alert(error.message);
        return;
      }

      const userId = data?.user?.id;

      if (!userId) {
        alert("Please verify your email to continue.");
        return;
      }

      // ----------------------------------
      // 3️⃣ UPLOAD PROFILE IMAGE (ANON KEY)
      // ----------------------------------
      let imageUrl = null;

      if (photo) {
        const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
        const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

        const ext = photo.split(".").pop() || "jpg";
        const fileName = `profile_${userId}.${ext}`;
        const filePath = `profiles/${fileName}`;

        const formData = new FormData();
        formData.append("file", {
          uri: photo,
          name: fileName,
          type: `image/${ext}`,
        });

        const uploadRes = await fetch(
          `${SUPABASE_URL}/storage/v1/object/nutmegplay/${filePath}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
              apikey: SUPABASE_ANON_KEY,
              "x-upsert": "true",
            },
            body: formData,
          }
        );

        if (!uploadRes.ok) {
          console.log("UPLOAD ERROR:", await uploadRes.text());
          alert("Image upload failed");
          return;
        }

        const { data: publicData } = supabase.storage
          .from("nutmegplay")
          .getPublicUrl(filePath);

        imageUrl = publicData.publicUrl;
      }

      // ----------------------------------
      // 4️⃣ INSERT USER PROFILE DATA
      // ----------------------------------
      const { error: dbError } = await supabase.from("accounts").insert({
        uid: userId,
        fname: name,
        email: email,
        country: nationality,
        position: position,
        image_url: imageUrl,
      });

      if (dbError) {
        alert("Database error: " + dbError.message);
        return;
      }

      // ----------------------------------
      // 5️⃣ DONE
      // ----------------------------------
      alert("Signup successful! Please verify your email.");
      navigation.goBack();
    } catch (err) {
      console.error("Signup Error:", err);
      alert("Something went wrong. Please try again.");
    }
  };

  const validateEmail = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    return emailRegex.test(email);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      setPhoto(result.assets[0].uri);
    }
  };

  return (
    <ImageBackground
      source={require("../../assets/field-bg.jpg")}
      style={styles.background}
    >
      <View style={styles.overlay}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" color={"white"} size={23} />
        </TouchableOpacity>

        <ScrollView
          style={{ flex: 1, width: "100%" }}
          contentContainerStyle={{ paddingBottom: 50 }}
          nestedScrollEnabled
        >
          <LinearGradient
            colors={["rgba(30,60,30,0.9)", "rgba(20,40,20,0.9)"]}
            style={[styles.card, { alignSelf: "center", marginVertical: 100 }]}
          >
            {/* Logo */}
            <View style={styles.logoContainer}>
              <View style={styles.logoCircle}>
                <Image
                  source={require("../../assets/logotp.png")}
                  style={{ width: 30, height: 30 }}
                />
              </View>
              <Text style={styles.logoText}>NUTMEG PLAY</Text>
            </View>

            <Text style={styles.welcome}>Let the Game Begin!</Text>
            <Text style={styles.subtitle}>
              Signup to continue your journey.
            </Text>

            {/* Profile Photo */}
            <TouchableOpacity style={styles.photoContainer} onPress={pickImage}>
              {photo ? (
                <Image source={{ uri: photo }} style={styles.photo} />
              ) : (
                <View style={styles.photoPlaceholder}>
                  <Ionicons name="camera" size={30} color="#A5B4A8" />
                  <Text style={{ color: "#A5B4A8", fontSize: 12 }}>
                    Add Photo
                  </Text>
                </View>
              )}
            </TouchableOpacity>

            {/* Full Name */}
            <View style={styles.inputContainer}>
              <Ionicons name="person-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="Full Name"
                placeholderTextColor="#A5B4A8"
                style={styles.input}
                value={name}
                onChangeText={setName}
              />
            </View>

            {/* Nationality Dropdown */}
            <View style={[styles.dropdownContainer, { zIndex: 1000 }]}>
              <Ionicons name="flag-outline" size={20} color="#A5B4A8" />
              <View style={{ flex: 1, marginLeft: 10 }}>
                {loadingCountries ? (
                  <ActivityIndicator color="#00C26D" />
                ) : (
                  <Dropdown
                    style={styles.dropdownSearchable}
                    placeholderStyle={{ color: "#A5B4A8" }}
                    selectedTextStyle={{ color: "#00C26D" }} // Closed dropdown selected text
                    data={countries} // or positions
                    labelField="label"
                    valueField="value"
                    placeholder="Select Nationality"
                    value={nationality}
                    onChange={(item) => setNationality(item.value)}
                    renderItem={(item) => {
                      const isSelected = item.value === nationality;
                      return (
                        <View
                          style={{
                            padding: 10,
                            backgroundColor: isSelected
                              ? "rgba(0,194,109,0.2)"
                              : "transparent", // selected item bg
                          }}
                        >
                          <Text style={{ color: "#00C26D" }}>{item.label}</Text>
                        </View>
                      );
                    }}
                    containerStyle={{
                      backgroundColor: "rgba(30,60,30,0.95)",
                      borderWidth: 1,
                      borderColor: "rgba(30,60,30,0.95)",
                      borderRadius: 10,
                    }}
                  />
                )}
              </View>
            </View>

            {/* Position Dropdown */}
            <View style={[styles.dropdownContainer, { zIndex: 999 }]}>
              <Ionicons name="football-outline" size={20} color="#A5B4A8" />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Dropdown
                  style={styles.dropdownSearchable}
                  placeholderStyle={{ color: "#A5B4A8" }}
                  selectedTextStyle={{ color: "#00C26D" }}
                  data={positions}
                  labelField="label"
                  valueField="value"
                  placeholder="Select Position"
                  value={position}
                  onFocus={() => setIsFocusPosition(true)}
                  onBlur={() => setIsFocusPosition(false)}
                  onChange={(item) => {
                    setPosition(item.value);
                    setIsFocusPosition(false);
                  }}
                  containerStyle={{
                    backgroundColor: "rgba(30,60,30,0.95)",
                    borderRadius: 12,
                    elevation: 999,
                  }}
                  renderItem={(item) => (
                    <View style={{ padding: 10 }}>
                      <Text style={{ color: "#00C26D" }}>{item.label}</Text>
                    </View>
                  )}
                />
              </View>
            </View>

            {/* Email */}
            <View style={styles.inputContainer}>
              <Ionicons name="mail-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="Email or Username"
                placeholderTextColor="#A5B4A8"
                style={styles.input}
                value={email}
                onChangeText={(val) => setEmail(val)}
              />
            </View>

            {/* Password */}
            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="Password"
                placeholderTextColor="#A5B4A8"
                secureTextEntry
                style={styles.input}
                value={password}
                onChangeText={(val) => setpassword(val)}
              />
            </View>

            {/* Confirm Password */}
            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed-outline" size={20} color="#A5B4A8" />
              <TextInput
                placeholder="Confirm Password"
                placeholderTextColor="#A5B4A8"
                secureTextEntry
                style={styles.input}
                value={cpassword}
                onChangeText={(val) => setCpassword(val)}
              />
            </View>

            {/* Create Account Button */}
            <TouchableOpacity
              style={styles.loginBtn}
              onPress={() => createAccount()}
            >
              <Text style={styles.loginText}>Create Account</Text>
            </TouchableOpacity>

            {/* Divider */}
            <View style={styles.dividerContainer}>
              <View style={styles.line} />
              <Text style={styles.orText}>Or continue with</Text>
              <View style={styles.line} />
            </View>

            {/* Social Buttons */}
            <View style={styles.socialRow}>
              <TouchableOpacity style={styles.socialBtn}>
                <FontAwesome name="google" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.socialBtn}>
                <FontAwesome name="facebook" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.socialBtn}>
                <FontAwesome name="apple" size={24} color="#fff" />
              </TouchableOpacity>
            </View>

            {/* Redirect to Login */}
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Text style={styles.signupText}>
                Already have an Account?{" "}
                <Text style={styles.signupLink}>Login</Text>
              </Text>
            </TouchableOpacity>
          </LinearGradient>
        </ScrollView>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1, resizeMode: "cover", justifyContent: "center" },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  backButton: {
    padding: 10,
    position: "absolute",
    top: 50,
    left: 20,
    zIndex: 10,
  },
  card: { width: "85%", borderRadius: 20, padding: 24, alignItems: "center" },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  logoCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#083d1b",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  logoText: { color: "#fff", fontWeight: "bold", fontSize: 22 },
  welcome: { color: "#fff", fontWeight: "700", fontSize: 20, marginTop: 8 },
  subtitle: { color: "#C9D4C8", textAlign: "center", marginBottom: 20 },
  photoContainer: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  photo: { width: 90, height: 90, borderRadius: 45 },
  photoPlaceholder: { alignItems: "center", justifyContent: "center" },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  input: { color: "#fff", flex: 1, marginLeft: 10, fontSize: 16 },
  dropdownContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  dropdownSearchable: { height: 40 },
  loginBtn: {
    backgroundColor: "#00C26D",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    width: "100%",
    marginVertical: 16,
  },
  loginText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  dividerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 12,
  },
  line: { flex: 1, height: 1, backgroundColor: "#9BAA9B" },
  orText: { color: "#C9D4C8", marginHorizontal: 8 },
  socialRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    marginVertical: 10,
  },
  socialBtn: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
    width: 60,
  },
  signupText: { color: "#C9D4C8", marginTop: 12 },
  signupLink: { color: "#00C26D", fontWeight: "bold" },
});
