import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  Image,
  Alert,
} from "react-native";

import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { supabase } from "../api/supabase";

export default function Forgetpwd() {
  const navigation = useNavigation();
  const [email, setEmail] = useState();
  const [loading, setLoading] = useState(false);

  const forgotPwd = async () => {
    if (!validateEmail(email)) {
      Alert.alert("Invalid Email", "Please enter a valid email address.");
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.resetPasswordForEmail(email);
    setLoading(false);
    if (error) {
      Alert.alert("Error", error.message);
    } else {
      Alert.alert(
        "Email Sent",
        "Check your inbox for the password reset link.",
        [{ text: "OK", onPress: () => navigation.goBack() }],
      );
    }
  };

  const validateEmail = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    return emailRegex.test(email);
  };
  return (
    <ImageBackground
      source={require("../../assets/field-bg.jpg")}
      style={styles.background}
    >
      <View style={styles.overlay}>
        <TouchableOpacity
          style={{
            padding: 10,
            position: "absolute",
            top: 50,
            left: 20,
            zIndex: 10,
            elevation: 10,
          }}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" color={"white"} size={23} />
        </TouchableOpacity>

        <LinearGradient
          colors={["rgba(30,60,30,0.9)", "rgba(20,40,20,0.9)"]}
          style={styles.card}
        >
          {/* Logo and Title */}
          <View style={styles.logoContainer}>
            <View style={styles.logoCircle}>
              <Image
                source={require("../../assets/logotp.png")}
                style={{
                  width: 30,
                  height: 30,
                }}
              />
              {/* <Ionicons name="ellipse-outline" size={24} color="#00C26D" /> */}
            </View>
            <Text style={styles.logoText}>NUTMEG PLAY</Text>
          </View>

          <Text style={styles.welcome}>Reset Password</Text>
          <Text style={styles.subtitle}>
            Enter your email to receive a reset link.
          </Text>

          {/* Email */}
          <View style={styles.inputContainer}>
            <Ionicons name="person-outline" size={20} color="#A5B4A8" />
            <TextInput
              placeholder="Enter Email"
              placeholderTextColor="#A5B4A8"
              style={styles.input}
              value={email}
              onChangeText={(val) => setEmail(val)}
            />
          </View>

          {/* Reset Button */}
          <TouchableOpacity
            style={[styles.loginBtn, loading && { opacity: 0.6 }]}
            onPress={() => forgotPwd()}
            disabled={loading}
          >
            <Text style={styles.loginText}>
              {loading ? "Sending..." : "Send Reset Link"}
            </Text>
          </TouchableOpacity>

          {/* Sign Up */}
          <TouchableOpacity onPress={() => navigation.navigate("Signup")}>
            <Text style={styles.signupText}>
              Don’t have an account?{" "}
              <Text style={styles.signupLink}>Sign Up</Text>
            </Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  card: {
    width: "85%",
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  logoCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#083d1b",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  logoText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 22,
  },
  welcome: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 20,
    marginTop: 8,
  },
  subtitle: {
    color: "#C9D4C8",
    textAlign: "center",
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    paddingHorizontal: 12,
    marginVertical: 8,
    width: "100%",
    height: 50,
  },
  input: {
    color: "#fff",
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
  },
  forgotBtn: {
    alignSelf: "flex-end",
    marginTop: 4,
  },
  forgotText: {
    color: "#00C26D",
    fontWeight: "600",
  },
  loginBtn: {
    backgroundColor: "#00C26D",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    width: "100%",
    marginVertical: 16,
  },
  loginText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  dividerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 12,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: "#9BAA9B",
  },
  orText: {
    color: "#C9D4C8",
    marginHorizontal: 8,
  },
  socialRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    marginVertical: 10,
  },
  socialBtn: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
    width: 60,
  },
  signupText: {
    color: "#C9D4C8",
    marginTop: 12,
  },
  signupLink: {
    color: "#00C26D",
    fontWeight: "bold",
  },
});
