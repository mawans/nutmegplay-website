import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "./api/supabase";

export default function Club() {
  const navigation = useNavigation();

  const [hasClub, setHasClub] = useState(false);
  const [loading, setLoading] = useState(true);

  const checkUserClub = async () => {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();

    if (error || !user) {
      setHasClub(false);
      setLoading(false);
      return;
    }

    const { data: clubs, error: clubError } = await supabase
      .from("clubs")
      .select("*")
      .or(`owner.eq.${user.id},players.cs.["${user.id}"]`)
      .limit(1);

    if (!clubError && clubs?.length > 0) {
      setHasClub(true);
      navigation.replace("MyClub", { owner_data: clubs[0] });
    } else {
      setHasClub(false);
    }

    setLoading(false);
  };

  useEffect(() => {
    const channel = supabase
      .channel("realtime-clubs")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "clubs",
        },
        () => {
          checkUserClub();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    checkUserClub();
  }, []);

  if (loading) {
    return (
      <LinearGradient
        colors={["#1a1c2c", "#0b0809", "#0b0809"]}
        style={styles.screen}
      >
        <View style={styles.center}>
          <Text style={{ color: "white" }}>Loading...</Text>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={styles.screen}
    >
      <SafeAreaView style={styles.container}>
        {!hasClub && (
          <>
            <View style={styles.header}>
              <Text style={styles.headerTitle}>Your Team</Text>
            </View>

            <ScrollView
              contentContainerStyle={styles.content}
              showsVerticalScrollIndicator={false}
            >
              {/* CREATE TEAM */}
              <TouchableOpacity
                style={styles.card}
                onPress={() => navigation.navigate("CreateTeam")}
              >
                <View style={styles.cardTop}>
                  <MaterialIcons name="shield" size={30} color="#fff" />
                  <Text style={styles.cardTitle}>Create a Team</Text>
                </View>
                <Text style={styles.cardText}>
                  Create your own club and join the league.
                </Text>
              </TouchableOpacity>

              {/* JOIN TEAM */}
              <TouchableOpacity
                style={styles.card}
                onPress={() => navigation.navigate("Jointeam")}
              >
                <View style={styles.cardTop}>
                  <MaterialIcons name="groups" size={30} color="#fff" />
                  <Text style={styles.cardTitle}>Join a Team</Text>
                </View>
                <Text style={styles.cardText}>
                  Join an existing club and start playing.
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

/* ------------------------------------
   STYLES
------------------------------------ */

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    padding: 16,
    alignItems: "center",
    borderBottomColor: "#3b3b3b",
    borderBottomWidth: 1,
  },
  headerTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
  content: {
    padding: 16,
    justifyContent: "center",
    flex: 1,
  },
  card: {
    backgroundColor: "#00C26D",
    borderRadius: 16,
    padding: 20,
    marginBottom: 14,
    width: 300,
    marginHorizontal: "auto",
  },
  cardTop: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  cardTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginLeft: 10,
  },
  cardText: {
    color: "#000000",
    fontSize: 14,
  },
});
