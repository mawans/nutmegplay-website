import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ImageBackground,
} from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import Svg, { Line } from "react-native-svg";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation, useRoute } from "@react-navigation/native";
import { supabase } from "./api/supabase";
import { MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { PanResponder } from "react-native";

const { width } = Dimensions.get("window");

const CARD_WIDTH = 60;
const CARD_HEIGHT = 100;

const formations = {
  // New positions array structure: [Player 1, Player 2, Player 3, Player 4, Goalkeeper]
  "2-2-1": [
    { pos: "ATT", top: 10, left: 30 }, // ATT (Left)
    { pos: "ATT", top: 10, left: 70 }, // ATT (Right)
    { pos: "MD", top: 40, left: 30 }, // MD (Left)
    { pos: "MD", top: 40, left: 70 }, // MD (Right)
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
  "1-2-1": [
    { pos: "ATT", top: 5, left: 50 }, // ATT (Center)
    { pos: "MD", top: 30, left: 25 }, // MD (Left)
    { pos: "MD", top: 30, left: 75 }, // MD (Right)
    { pos: "DF", top: 50, left: 50 }, // DF (Center)
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
  "2-1-1": [
    { pos: "ATT", top: 5, left: 25 }, // ATT (Left) - Adjusted for symmetry
    { pos: "ATT", top: 5, left: 75 }, // ATT (Right) - Adjusted for symmetry
    { pos: "MD", top: 25, left: 50 }, // MD (Center)
    { pos: "DF", top: 50, left: 50 }, // DF (Center) - Adjusted to be lower
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
  "1-1-2": [
    { pos: "ATT", top: 5, left: 50 }, // ATT (Center)
    { pos: "MD", top: 30, left: 50 }, // MD (Center)
    { pos: "DF", top: 55, left: 25 }, // DF (Left)
    { pos: "DF", top: 55, left: 75 }, // DF (Right)
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
  "3-1": [
    { pos: "ATT", top: 10, left: 50 }, // ATT (Center)
    { pos: "MD", top: 35, left: 20 }, // MD (Left)
    { pos: "MD", top: 35, left: 50 }, // MD (Center)
    { pos: "MD", top: 35, left: 80 }, // MD (Right)
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
  "1-3-1": [
    { pos: "ATT", top: 10, left: 50 }, // ATT (Center)
    { pos: "MD", top: 35, left: 20 }, // MD (Left)
    { pos: "MD", top: 35, left: 50 }, // MD (Center)
    { pos: "MD", top: 35, left: 80 }, // MD (Right)
    { pos: "GK", top: 75, left: 50 }, // GK (Center)
  ],
};

const formationLinks = {
  // Connections adjusted to maintain symmetry and include GK
  "2-2-1": [
    [0, 2], // ATT-L to MD-L
    [1, 3], // ATT-R to MD-R
    [2, 3], // MD-L to MD-R
    [2, 4], // MD-L to GK (Symmetry maintained by linking to center)
    [3, 4], // MD-R to GK (Symmetry maintained by linking to center)
  ],
  "1-2-1": [
    [0, 1], // ATT to MD-L
    [0, 2], // ATT to MD-R
    [1, 3], // MD-L to DF
    [2, 3], // MD-R to DF
    [3, 4], // DF to GK (Central link, symmetry maintained)
  ],
  "2-1-1": [
    [0, 2], // ATT-L to MD
    [1, 2], // ATT-R to MD
    [2, 3], // MD to DF
    [3, 4], // DF to GK (Central link, symmetry maintained)
  ],
  "1-1-2": [
    [0, 1], // ATT to MD
    [1, 2], // MD to DF-L
    [1, 3], // MD to DF-R
    [2, 3], // DF-L to DF-R
    [2, 4], // DF-L to GK
    [3, 4], // DF-R to GK
  ],
  "3-1": [
    [0, 2], // ATT to MD-Center
    [1, 2], // MD-L to MD-Center
    [3, 2], // MD-R to MD-Center
    [1, 3], // MD-L to MD-R
    [2, 4], // MD-Center to GK (Central link, symmetry maintained)
  ],
  "1-3-1": [
    [0, 1], // ATT to MD-L
    [0, 2], // ATT to MD-Center
    [0, 3], // ATT to MD-R
    [1, 2], // MD-L to MD-Center
    [2, 3], // MD-Center to MD-R
    [2, 4], // MD-Center to GK (Central link, symmetry maintained)
  ],
};

const defaultBench = [
  {
    name: "K. DE BRUYNE",
    pos: "ATT",
    rating: "90",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDOQh_miI1KyNzySeILQ-86nEh5ESgk5im5TXJAcOy0-lrznjofeZzYC-7BYlDPEtxhIMUYTndQMDXhEr8CIJ1lND-mpz1W6syhC2qcRmvmw96OBDV00uRY2AaTX1_IH7bnCWUAi1r_aB6nHZkSYiD9Mn4AxX67jdysEqiUAYrP_ZihZzrwfWgaSy7D_bFERLzKj6Mfdag5h0TS57GA6CMbrKH9bkbLfDMqE9EI9d1Ixg9XaPpG-MG4jNEqlho6OQhqlH3LS5P41VTS",
  },
  { name: "ADD PLAYER", pos: " ", image: null },
];

const PLACEHOLDER_PLAYER = {
  name: "ADD PLAYER",
  rating: "",
  pos: "",
  image: "https://via.placeholder.com/80x100.png?text=+",
  isPlaceholder: true,
};

const buildLineupByFormation = (players, formationSlots) => {
  const buckets = {
    ATT: [],
    MD: [],
    DF: [],
    GK: [],
  };

  // group players by position
  players.forEach((p) => {
    if (buckets[p.pos]) {
      buckets[p.pos].push(p);
    }
  });

  const used = { ATT: 0, MD: 0, DF: 0, GK: 0 };

  // fill formation slots
  return formationSlots.map((slot) => {
    const role = slot.pos;
    const player = buckets[role]?.[used[role]];

    if (player) {
      used[role] += 1;
      return player;
    }

    // no player → placeholder for that role
    return {
      ...PLACEHOLDER_PLAYER,
      pos: role,
    };
  });
};

const normalizePlayers = (playersFromDB) => {
  return playersFromDB.map((p) => ({
    uid: p.uid,
    name: p.fname?.toUpperCase() || "UNKNOWN",
    rating: p.level ?? "-",
    pos: p.position || "MD",
    image: p.image_url || PLACEHOLDER_PLAYER.image,
    isPlaceholder: false,
  }));
};

export default function MyClub() {
  const [selectedFormation, setSelectedFormation] = useState("2-1-1");
  const [players, setPlayers] = useState([]);
  const [bench, setBench] = useState(defaultBench);
  const [selectedMain, setSelectedMain] = useState(null);
  const [draggingIndex, setDraggingIndex] = useState(null);
  const [ownerData, setOwnerData] = useState();

  const SAFE_FORMATION = "2-1-1";

  const formationPositions =
    formations[selectedFormation] || formations[SAFE_FORMATION];

  const links = formationLinks[selectedFormation] || [];

  const navigation = useNavigation();
  const route = useRoute();

  const handleBenchPress = (benchIndex) => {
    if (selectedMain === null) return;
    const newPlayers = [...players];
    const newBench = [...bench];
    const temp = newPlayers[selectedMain];
    newPlayers[selectedMain] = newBench[benchIndex];
    newBench[benchIndex] = temp;
    setPlayers(newPlayers);
    setBench(newBench);
    setSelectedMain(null);
  };

  const applyFormation = (formationKey, allPlayers) => {
    const formation = formations[formationKey] || formations[SAFE_FORMATION];

    const realPlayers = allPlayers.filter((p) => !p.isPlaceholder);

    const usedPlayerIds = new Set();

    const lineup = formation.map((slot) => {
      const match = realPlayers.find(
        (p) => p.pos === slot.pos && !usedPlayerIds.has(p.uid)
      );

      if (match) {
        usedPlayerIds.add(match.uid);
        return match;
      }

      return {
        ...PLACEHOLDER_PLAYER,
        pos: slot.pos,
      };
    });

    // players that didn't fit the formation
    const leftovers = realPlayers.filter((p) => !usedPlayerIds.has(p.uid));

    setPlayers(lineup);

    setBench([...leftovers, { ...PLACEHOLDER_PLAYER }]);
  };

  const saveFormation = async (formation) => {
    const owner = route.params?.owner_data;
    if (!owner) return;

    await supabase
      .from("clubs")
      .update({ field_layout: formation })
      .eq("id", owner.id);

    setSelectedFormation(formation);

    const allPlayers = [
      ...players.filter((p) => !p.isPlaceholder),
      ...bench.filter((p) => !p.isPlaceholder),
    ];

    applyFormation(formation, allPlayers);
  };

  useEffect(() => {
    const owner = route.params?.owner_data;
    console.log("OWNER_DATA:", owner?.players);

    setOwnerData(owner);

    const fetchPlayers = async () => {
      if (!owner?.players || !Array.isArray(owner.players)) {
        applyFormation(selectedFormation, []);
        return;
      }

      const { data, error } = await supabase
        .from("accounts")
        .select("uid, fname, level, position, image_url")
        .in("uid", owner.players);

      if (error) {
        console.log("Fetch players failed:", error);
        applyFormation(selectedFormation, []);
        return;
      }

      const normalized = normalizePlayers(data);

      // main lineup
      applyFormation(owner?.field_layout || selectedFormation, normalized);

      // bench
      if (normalized.length > 5) {
        setBench([...normalized.slice(5), { ...PLACEHOLDER_PLAYER }]);
      } else {
        setBench([{ ...PLACEHOLDER_PLAYER }]);
      }
    };

    fetchPlayers();

    const layout = owner?.field_layout;

    if (layout && formations[layout]) {
      setSelectedFormation(layout);
    } else {
      console.warn("Invalid formation from DB:", layout);
      setSelectedFormation("2-1-1");
    }
  }, []);

  const swapPlayers = (from, to) => {
    if (from === to) return;

    const updated = [...players];
    const temp = updated[from];
    updated[from] = updated[to];
    updated[to] = temp;

    setPlayers(updated);
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}
    >
      <SafeAreaView style={{ flex: 1 }}>
        {ownerData && selectedFormation && (
          <>
            <View style={styles.topbar}>
              <View
                style={{
                  flexDirection: "column",
                }}
              >
                <Text
                  style={[
                    styles.benchName,
                    {
                      fontSize: 16,
                      width: Dimensions.get("screen").width / 2 - 50,
                      textAlign: "left",
                      textTransform: "uppercase",
                    },
                  ]}
                >
                  {route.params?.owner_data.name}
                </Text>
                <Text
                  style={[
                    styles.benchName,
                    {
                      fontSize: 16,
                      width: Dimensions.get("screen").width / 2 - 50,
                      textAlign: "left",
                    },
                  ]}
                >
                  Level:{" "}
                  {route.params?.owner_data.level
                    ? route.params?.owner_data.level
                    : 1}
                </Text>
              </View>

              {route.params?.owner_data && (
                <Image
                  source={{ uri: route.params?.owner_data.logo }}
                  style={styles.logo}
                />
              )}

              <View
                style={{
                  width: Dimensions.get("screen").width / 2 - 50,
                  justifyContent: "flex-end",
                  alignItems: "flex-end",
                }}
              >
                <TouchableOpacity
                  onPress={() => navigation.navigate("InvitationList")}
                >
                  <MaterialIcons
                    name="notifications"
                    size={30}
                    color="#ffffff"
                  />
                </TouchableOpacity>
              </View>
            </View>

            <ScrollView
              style={{ flex: 1, maxHeight: 56 }}
              horizontal
              showsHorizontalScrollIndicator={false}
            >
              <View style={styles.formationSelector}>
                {Object.keys(formations).map((f) => (
                  <TouchableOpacity
                    key={f}
                    style={[
                      styles.formationButton,
                      selectedFormation === f && styles.formationSelected,
                    ]}
                    onPress={() => saveFormation(f)}
                  >
                    <Text
                      style={[
                        styles.formationText,
                        selectedFormation === f && styles.formationTextSelected,
                      ]}
                    >
                      {f}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Pitch */}
            <View style={styles.pitchContainer}>
              <ImageBackground
                source={require("../assets/playingfield.jpg")}
                style={styles.pitch}
              >
                <Svg
                  height="100%"
                  width="100%"
                  style={{ position: "absolute" }}
                >
                  {links.map(([a, b], i) => {
                    const p1 = formationPositions[a];
                    const p2 = formationPositions[b];
                    if (!p1 || !p2) return null;

                    const Y_CENTER_OFFSET_PX = CARD_HEIGHT / 2; // 50px

                    return (
                      <Line
                        key={i}
                        x1={`${p1.left}%`}
                        x2={`${p2.left}%`}
                        y1={`${
                          p1.top +
                          (Y_CENTER_OFFSET_PX / ((width * 0.9 * 4) / 3)) * 100
                        }%`}
                        y2={`${
                          p2.top +
                          (Y_CENTER_OFFSET_PX / ((width * 0.9 * 4) / 3)) * 100
                        }%`}
                        stroke="rgba(255,255,255,0.6)"
                        strokeWidth="1"
                      />
                    );
                  })}
                </Svg>

                {/* Player cards (including GK at index 4) */}
                {players.map((p, i) => {
                  const panResponder = PanResponder.create({
                    onStartShouldSetPanResponder: () => !p.isPlaceholder,
                    onPanResponderGrant: () => setDraggingIndex(i),
                    onPanResponderRelease: (_, gesture) => {
                      setDraggingIndex(null);

                      const droppedIndex = players.findIndex((_, idx) => {
                        const pos = formationPositions[idx];
                        if (!pos) return false;

                        const x = (pos.left / 100) * width;
                        const y = (pos.top / 100) * width;

                        return (
                          Math.abs(gesture.moveX - x) < 40 &&
                          Math.abs(gesture.moveY - y) < 60
                        );
                      });

                      if (droppedIndex !== -1 && droppedIndex !== i) {
                        swapPlayers(i, droppedIndex);
                      }
                    },
                  });

                  return (
                    <TouchableOpacity
                      key={i}
                      {...panResponder.panHandlers}
                      style={[
                        styles.playerContainer,
                        {
                          top: `${formationPositions[i]?.top || 50}%`,
                          left: `${formationPositions[i]?.left || 50}%`,
                          transform: [{ translateX: -CARD_WIDTH / 2 }],
                          opacity: draggingIndex === i ? 0.7 : 1,
                        },
                      ]}
                      onPress={() => {
                        if (p.isPlaceholder) {
                          navigation.navigate("CreateAnnouncement", {
                            club: ownerData,
                          });
                        } else {
                          setSelectedMain(i);
                        }
                      }}
                    >
                      <ImageBackground
                        source={require("../assets/players/playercardbg.png")}
                        style={{
                          width: CARD_WIDTH,
                          height: CARD_HEIGHT,
                          alignItems: "center",
                          padding: 5,
                        }}
                      >
                        {/* Player Rating for non-GK players, removed for GK for simplicity if needed */}
                        {p.pos !== "GK" && p.rating ? (
                          <View style={styles.playerRatingView}>
                            <Text style={styles.playerRatingText}>
                              {p.rating}
                            </Text>
                          </View>
                        ) : null}

                        {p.image && (
                          <Image
                            source={{ uri: p.image }}
                            style={[
                              styles.playerImage,
                              p.isPlaceholder && { opacity: 0.6 },
                            ]}
                          />
                        )}

                        <Text style={styles.playerName}>
                          {p.isPlaceholder ? "ADD PLAYER" : p.name}
                        </Text>

                        <View style={styles.playerStat}>
                          <Text style={styles.playerPos}>{p.pos}</Text>
                        </View>
                        {selectedMain === i && (
                          <View
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              right: 0,
                              bottom: 0,
                              backgroundColor: "rgba(19,127,236,0.3)",
                              borderRadius: 8,
                            }}
                          />
                        )}
                      </ImageBackground>
                    </TouchableOpacity>
                  );
                })}
              </ImageBackground>
            </View>

            {/* Bench */}
            <View style={styles.benchContainer}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {bench.map((b, i) => {
                  if (b.name !== "ADD PLAYER") {
                    return (
                      <TouchableOpacity
                        key={i}
                        style={styles.benchPlayer}
                        onPress={() => handleBenchPress(i)}
                      >
                        {b.image ? (
                          <Image
                            source={{ uri: b.image }}
                            style={styles.benchImage}
                          />
                        ) : (
                          <View style={styles.addBench}>
                            <Icon name="add" color="#888" size={22} />
                          </View>
                        )}
                        <Text style={styles.benchName}>{b.name}</Text>
                        <Text style={styles.benchPos}>{b.pos}</Text>
                      </TouchableOpacity>
                    );
                  } else {
                    return (
                      <TouchableOpacity
                        key={i}
                        style={styles.benchPlayer}
                        // onPress={() => setAddPlayer(true)}
                        onPress={() =>
                          navigation.navigate("CreateAnnouncement", {
                            club: ownerData,
                          })
                        }
                      >
                        <View style={styles.addBench}>
                          <Icon name="add" color="#888" size={22} />
                        </View>

                        <Text style={styles.benchName}>{b.name}</Text>
                        <Text style={styles.benchPos}>{b.pos}</Text>
                      </TouchableOpacity>
                    );
                  }
                })}
              </ScrollView>
            </View>
          </>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

// STYLES
const styles = StyleSheet.create({
  topbar: {
    width: "100%",
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    paddingHorizontal: 5,
    paddingVertical: 10,
    borderBottomColor: "#3b3b3b",
    borderBottomWidth: 1,
  },
  logo: {
    width: 55,
    height: 55,
    borderRadius: 30,
    borderWidth: 1,
  },
  container: { flex: 1 },
  formationSelector: {
    flexDirection: "row",
    justifyContent: "center",
    marginVertical: 10,
  },
  formationButton: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 6,
    backgroundColor: "#333",
    marginHorizontal: 5,
  },
  formationSelected: {
    backgroundColor: "#1DB954",
  },
  formationText: {
    color: "#fff",
    fontSize: 14,
  },
  formationTextSelected: {
    color: "#fff",
    fontWeight: "bold",
  },
  pitchContainer: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
  pitch: {
    width: width * 0.9,
    aspectRatio: 3 / 4,
    backgroundColor: "#0c4f22",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#ccc",
    overflow: "hidden",
    position: "relative",
  },
  playerContainer: {
    position: "absolute",
    alignItems: "center",
    padding: 5,
    height: CARD_HEIGHT,
    width: CARD_WIDTH,
  },
  playerImage: {
    width: 35,
    height: 35,
    borderRadius: 20,
    marginBottom: 5,
  },
  playerName: {
    color: "#fff",
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 6,
    borderRadius: 8,
    fontSize: 9,
    marginTop: 2,
    textAlign: "center",
  },
  playerStat: {
    flexDirection: "row",
    backgroundColor: "rgba(0,0,0,0.5)",
    borderRadius: 8,
    paddingHorizontal: 4,
    marginTop: 2,
    alignItems: "center",
  },
  playerPos: { color: "#ffffff", fontSize: 10, fontWeight: "bold" },
  playerRatingView: {
    position: "absolute",
    top: 0,
    right: 0,
    backgroundColor: "gold",
    padding: 2,
    borderRadius: 5,
    zIndex: 1,
  },
  playerRatingText: {
    fontSize: 9,
    fontWeight: "bold",
    color: "black",
  },
  benchContainer: {
    backgroundColor: "#1C2127",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 12,
    marginBottom: -40,
  },
  benchPlayer: { alignItems: "center", marginRight: 12 },
  benchImage: {
    width: 50,
    height: 50,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: "#555",
    marginBottom: 4,
  },
  addBench: {
    width: 50,
    height: 50,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: "#555",
    backgroundColor: "#333",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  benchName: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  benchPos: { color: "#9dabb9", fontSize: 10 },
});
