import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { supabase } from "./api/supabase";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";

export default function Profile() {
  const [tab, setTabe] = useState(true);
  const [profile, setProfile] = useState();
  const navigation = useNavigation();

  const logOut = async () => {
    const { error } = await supabase.auth.signOut();

    if (error) {
      console.error(error);
      alert("Logout failed");
      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const uid = (await supabase.auth.getUser()).data.user.id;
    const { data, error } = await supabase
      .from("accounts")
      .select("*")
      .eq("uid", uid);
    console.log(data[0]);
    setProfile(data[0]);
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      <SafeAreaProvider style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Profile</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate("RecentMatchesScreen")}
          >
            <MaterialIcons name="video-library" size={26} color="#EAEAEA" />
          </TouchableOpacity>
        </View>

        {/* Scrollable Content */}
        {profile && (
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Profile Card */}
            <View style={styles.profileSection}>
              <Image
                source={{
                  uri: profile?.image_url
                    ? profile.image_url
                    : "https://ui-avatars.com/api/?name=" +
                      profile?.fname +
                      "&background=00C26D&color=fff",
                }}
                style={styles.avatar}
              />

              {/* <Image
                source={{
                  uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH7x-pmiDVaj5VEBh1GK63tHwEPd_gfY03ZmMcUxn2csDkFFAiVt-gY1-prZ1xtPQi5mCwcSSJphOfTgfanm57BJmOGSAGynSDKMkBlXbhhPwIiq8ZWM8E434YPfGab8LneRfXSAixuDaXkr7UgLrSyA4UaqPrLjTypp_WHQ8fSGl-5-_1-tIiHwQ1KrTB5wlfm-nI677MJcAUG164LGRGJXQ44iouYSsuwc6WktbElDIec-Nzo0q5VO9LSQT_E65IIPo3Cski5yWh",
                }}
                style={styles.avatar}
                imageStyle={{ borderRadius: 100 }}
              /> */}
              <Text style={styles.playerName}>{profile.fname}</Text>
              <Text style={styles.playerInfo}>
                {profile.position} - {profile.country}
              </Text>
              <Text style={styles.playerRating}>
                {profile.level ?? 85} <Text style={styles.ratingText}>OVR</Text>
              </Text>
            </View>

            {/* Stats */}
            <View style={styles.statsGrid}>
              {[
                { label: "Speed", value: profile.speed ?? "--" },
                { label: "Shooting", value: profile.shooting ?? "--" },
                { label: "Physical", value: profile.physical ?? "--" },
                { label: "Dribbling", value: profile.dribbling ?? "--" },
                { label: "Passes", value: profile.passes ?? "--" },
                { label: "Defense", value: profile.defense ?? "--" },
              ].map((item, i) => (
                <View key={i} style={styles.statCard}>
                  <Text style={styles.statLabel}>{item.label}</Text>
                  <Text style={styles.statValue}>{item.value}</Text>
                </View>
              ))}
            </View>

            {/* Share Button */}
            <TouchableOpacity
              style={styles.shareButton}
              onPress={() => alert("Card shared!")}
            >
              <MaterialIcons name="share" size={20} color="black" />
              <Text style={styles.shareText}>Share my Card</Text>
            </TouchableOpacity>

            {/* Level Progress */}
            <View style={styles.levelSection}>
              <View style={styles.levelHeader}>
                <Text style={styles.levelText}>Level {profile.level ?? 1}</Text>
                <Text style={styles.xpText}>
                  {profile.xp ?? 0} / {profile.xp_required ?? 2000} XP
                </Text>
              </View>
              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    {
                      width: `${Math.min(((profile.xp ?? 0) / (profile.xp_required ?? 2000)) * 100, 100)}%`,
                    },
                  ]}
                ></View>
              </View>
            </View>

            {/* Stats Summary */}
            <View style={styles.tabHeader}>
              <TouchableOpacity onPress={() => setTabe(true)}>
                <Text style={[styles.tabTitle, tab && styles.activeTab]}>
                  Global History
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setTabe(false)}>
                <Text style={[styles.tabTitle, !tab && styles.activeTab]}>
                  Personal Records
                </Text>
              </TouchableOpacity>
            </View>

            {(tab && (
              <View style={styles.summaryGrid}>
                {[
                  { label: "Matches", value: profile.matches ?? "0" },
                  { label: "Wins", value: profile.wins ?? "0" },
                  { label: "Losses", value: profile.losses ?? "0" },
                  { label: "Draws", value: profile.draws ?? "0" },
                ].map((item, i) => (
                  <View key={i} style={styles.summaryCard}>
                    <Text style={styles.summaryValue}>{item.value}</Text>
                    <Text style={styles.summaryLabel}>{item.label}</Text>
                  </View>
                ))}
                <View style={[styles.summaryCard, { gridColumn: "span 2" }]}>
                  <Text style={styles.summaryLabel}>Total Playing Time</Text>
                  <Text style={styles.summaryValue}>
                    {profile.total_minutes ?? 0} Mins
                  </Text>
                </View>
              </View>
            )) || (
              <View style={[styles.statsGrid, { paddingTop: 20 }]}>
                {[
                  { label: "Speed", value: profile.speed ?? "--" },
                  { label: "Shooting", value: profile.shooting ?? "--" },
                  { label: "Physical", value: profile.physical ?? "--" },
                  { label: "Dribbling", value: profile.dribbling ?? "--" },
                  { label: "Passes", value: profile.passes ?? "--" },
                  { label: "Defense", value: profile.defense ?? "--" },
                ].map((item, i) => (
                  <View key={i} style={styles.statCard}>
                    <Text style={styles.statLabel}>{item.label}</Text>
                    <Text style={styles.statValue}>{item.value}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Personalization */}
            <View style={styles.personalSection}>
              <Text style={styles.sectionTitle}>Personalization</Text>

              <TouchableOpacity
                style={styles.optionCard}
                onPress={() => navigation.navigate("Editprofile")}
              >
                <View style={styles.optionLeft}>
                  <MaterialIcons name="edit" size={22} color="#EAEAEA" />
                  <Text style={styles.optionText}>Edit Profile</Text>
                </View>
                <MaterialIcons name="chevron-right" size={22} color="#9ca3af" />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.optionCard, { backgroundColor: "#d00101ff" }]}
                onPress={() => logOut()}
              >
                <View style={styles.optionLeft}>
                  <MaterialIcons name="logout" size={22} color="#fff" />
                  <Text style={[styles.optionText, { color: "#ffff" }]}>
                    Logout
                  </Text>
                </View>
                <MaterialIcons name="chevron-right" size={22} color="#fff" />
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}
      </SafeAreaProvider>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 30,
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#EAEAEA",
  },
  profileSection: {
    alignItems: "center",
    paddingVertical: 20,
  },
  avatar: {
    width: 128,
    height: 128,
    borderWidth: 4,
    borderColor: "#00C26D",
    borderRadius: 100,
  },
  playerName: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 10,
    textTransform: "uppercase",
    width: "100%",
    textAlign: "center",
  },
  playerInfo: {
    color: "#9ca3af",
  },
  playerRating: {
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 10,
    color: "white",
    fontSize: 28,
    fontWeight: "bold",
    marginTop: 6,
  },
  ratingText: {
    color: "#00C26D",
    fontSize: 20,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    gap: 8,
  },
  statCard: {
    backgroundColor: "#1F1F1F",
    borderWidth: 1,
    borderColor: "#2D3748",
    borderRadius: 12,
    width: "48%",
    padding: 12,
  },
  statLabel: {
    color: "#9ca3af",
    fontSize: 14,
  },
  statValue: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
  },
  shareButton: {
    marginTop: 20,
    flexDirection: "row",
    backgroundColor: "#00C26D",
    borderRadius: 10,
    alignSelf: "center",
    paddingHorizontal: 20,
    height: 48,
    alignItems: "center",
    gap: 8,
  },
  shareText: {
    color: "black",
    fontWeight: "bold",
  },
  levelSection: {
    paddingHorizontal: 16,
    marginTop: 24,
  },
  levelHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  levelText: {
    color: "#EAEAEA",
    fontWeight: "bold",
    fontSize: 18,
  },
  xpText: {
    color: "#9ca3af",
    fontSize: 14,
  },
  progressBar: {
    backgroundColor: "#1F1F1F",
    borderWidth: 1,
    borderColor: "#2D3748",
    borderRadius: 20,
    marginTop: 8,
    height: 10,
  },
  progressFill: {
    width: "75%",
    height: "100%",
    backgroundColor: "#00C26D",
    borderRadius: 20,
  },
  tabHeader: {
    flexDirection: "row",
    justifyContent: "space-around",
    borderBottomWidth: 1,
    borderColor: "#2D3748",
    marginTop: 20,
  },
  tabTitle: {
    color: "#9ca3af",
    paddingVertical: 10,
    fontWeight: "bold",
  },
  activeTab: {
    color: "#00C26D",
    borderBottomWidth: 2,
    borderColor: "#00C26D",
  },
  summaryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    marginTop: 16,
  },
  summaryCard: {
    backgroundColor: "#1F1F1F",
    borderColor: "#2D3748",
    borderWidth: 1,
    borderRadius: 12,
    width: "48%",
    paddingVertical: 16,
    alignItems: "center",
    marginVertical: 5,
  },
  summaryLabel: {
    color: "#9ca3af",
  },
  summaryValue: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
  },
  personalSection: {
    paddingHorizontal: 16,
    marginTop: 30,
    marginBottom: 80,
  },
  sectionTitle: {
    color: "#EAEAEA",
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 10,
  },
  optionCard: {
    backgroundColor: "#1F1F1F",
    borderColor: "#2D3748",
    borderWidth: 1,
    borderRadius: 10,
    padding: 14,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  optionLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  optionText: {
    color: "#EAEAEA",
    fontSize: 15,
    fontWeight: "600",
  },
  bottomNav: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#1F1F1F",
    borderTopWidth: 1,
    borderColor: "#2D3748",
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
  },
  navItem: {
    alignItems: "center",
  },
  navLabel: {
    fontSize: 12,
    color: "#9ca3af",
  },
});
