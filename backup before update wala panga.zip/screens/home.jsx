import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { supabase } from "./api/supabase";

const { width, height } = Dimensions.get("window");
export default function Home() {
  const [league, setLeague] = useState("Premier League");
  const [challenger, setChallenger] = useState();
  const [opponent, setOpponent] = useState();
  const [upcoming, setUpcoming] = useState();
  const navigation = useNavigation();

  useEffect(() => {
    fetch_the_upcoming_match();
  }, []);

  const fetch_the_upcoming_match = async () => {
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.log("Auth error:", authError);
      return;
    }

    const { data: userProfile, error: profileError } = await supabase
      .from("accounts")
      .select("club_assign")
      .eq("uid", user.id)
      .single();

    if (profileError || !userProfile?.club_assign) {
      console.log("Profile error:", profileError);
      return;
    }

    const { data: matches, error: matchError } = await supabase
      .from("matchs")
      .select("*")
      .or(
        `challenger_id.in.(${userProfile.club_assign}),opponent_id.in.(${userProfile.club_assign})`,
      )
      .order("created_at", { ascending: false })
      .limit(1);

    if (matchError || !matches?.length) {
      console.error("Match error:", matchError);
      return;
    }

    const match = matches[0];

    const [{ data: opponent }, { data: challenger }] = await Promise.all([
      supabase
        .from("clubs")
        .select("logo")
        .eq("id", match.opponent_id)
        .single(),
      supabase
        .from("clubs")
        .select("logo")
        .eq("id", match.challenger_id)
        .single(),
    ]);

    setOpponent(opponent?.logo ?? null);
    setChallenger(challenger?.logo ?? null);
    setUpcoming(match);
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.screen}
    >
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <Image
          source={require("../assets/logotp.png")}
          style={{
            width: 100,
            height: 100,
            alignSelf: "center",
          }}
        />
        {upcoming && <Text style={styles.sectionTitle}>Next Match</Text>}

        {upcoming && (
          <TouchableOpacity
            style={styles.matchCard}
            onPress={() =>
              navigation.navigate("PayandJoin", { clubsData: upcoming })
            }
          >
            <View style={styles.matchHeader}>
              <View style={styles.locationRow}>
                <Ionicons name="location-outline" size={16} color="#fff" />
                <Text style={styles.locationText}>
                  {upcoming.location
                    ? upcoming.location
                    : "Location Not Available"}
                </Text>
              </View>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>Next Match</Text>
              </View>
            </View>

            <View style={styles.locationRow}>
              <Ionicons name="calendar-clear-outline" size={16} color="#fff" />
              <Text style={styles.locationText}>{upcoming.date}</Text>
            </View>
            <View style={styles.locationRow}>
              <Ionicons name="time-outline" size={16} color="#fff" />
              <Text style={styles.locationText}>{upcoming.time}</Text>
            </View>

            <View style={styles.matchRow}>
              <View style={styles.team}>
                {challenger && (
                  <Image source={{ uri: challenger }} style={styles.logo} />
                )}
                <Text style={styles.teamName}>{upcoming.challanger}</Text>
              </View>

              <View style={styles.team}>
                {opponent && (
                  <Image source={{ uri: opponent }} style={styles.logo} />
                )}
                <Text style={styles.teamName}>{upcoming.opponent}</Text>
              </View>
            </View>
          </TouchableOpacity>
        )}

        {/* Weekly Challenges */}
        <Text style={[styles.sectionTitle, { marginTop: 20 }]}>
          Weekly Challenges
        </Text>
        <View
          style={[
            styles.matchCard,
            {
              backgroundColor: "#292929ff",
              marginTop: 0,
              marginBottom: 20,
            },
          ]}
        >
          <View
            style={{
              flex: 1,
              justifyContent: "space-between",
              alignItems: "center",
              flexDirection: "row",
            }}
          >
            <View style={{ width: "70%" }}>
              <Text style={{ color: "#c0c0c0", fontSize: 12, marginBottom: 5 }}>
                Challenge of the Week
              </Text>
              <Text
                style={{
                  color: "white",
                  fontSize: 13,
                  marginBottom: 5,
                  fontWeight: "bold",
                }}
              >
                Score 5 Goals
              </Text>
              <Text style={{ color: "#c0c0c0", fontSize: 12, marginBottom: 5 }}>
                Reward: +500 XP
              </Text>

              <TouchableOpacity
                style={{
                  paddingHorizontal: 10,
                  paddingVertical: 7,
                  backgroundColor: "#404040",
                  width: "120",
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: 20,
                  marginTop: 5,
                }}
                onPress={() =>
                  navigation.navigate("PlayStack", { screen: "Challenges" })
                }
              >
                <Text style={{ color: "#fff", fontSize: 12, fontWeight: 500 }}>
                  View Challenge
                </Text>
              </TouchableOpacity>
            </View>
            <View style={{ width: "30%", alignItems: "center" }}>
              <Ionicons name="football" color={"#00D26A"} size={32} />
            </View>
          </View>
        </View>

        {/* <TouchableOpacity
          style={styles.playButton}
          onPress={() => navigation.navigate("PayandJoin")}
        >
          <Text style={styles.playButtonText}>Match Payments</Text>
        </TouchableOpacity> */}

        {/* <TouchableOpacity
          style={[styles.playButton, { marginTop: 7 }]}
          onPress={() => navigation.navigate("Invitations")}
        >
          <Text style={styles.playButtonText}>Invitations (1)</Text>
        </TouchableOpacity> */}
      </ScrollView>
    </LinearGradient>
  );
}

const gold = "#e9cc74";

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    width: width,
    height: height,
  },
  container: {
    flex: 1,
    padding: 16,
    marginTop: 80,
  },
  sectionTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
  },
  matchCard: {
    backgroundColor: "#12A454",
    borderRadius: 16,
    padding: 16,
  },
  matchHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  locationRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 3,
  },
  locationText: {
    color: "#fff",
    marginLeft: 6,
    fontWeight: "500",
  },
  badge: {
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    paddingVertical: 2,
    paddingHorizontal: 8,
  },
  badgeText: {
    color: "#fff",
    fontSize: 12,
  },
  weekday: {
    color: "#e0e0e0",
    fontSize: 12,
    marginVertical: 4,
  },
  matchRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    marginTop: 12,
  },
  team: {
    alignItems: "center",
  },
  teamLogo: {
    width: 50,
    height: 50,
    resizeMode: "contain",
  },
  teamName: {
    color: "#fff",
    fontSize: 14,
    marginVertical: 14,
    fontWeight: "bold",
  },
  score: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "700",
  },
  playButton: {
    backgroundColor: "#00D26A",
    borderRadius: 10,
    alignSelf: "center",
    paddingHorizontal: 30,
    paddingVertical: 15,
    width: width - 32,
  },
  playButtonText: {
    color: "#fff",
    fontWeight: "700",
    textAlign: "center",
  },
  tabRow: {
    flexDirection: "row",
    marginTop: 10,
    marginBottom: 12,
  },
  tabButton: {
    flex: 1,
    backgroundColor: "#1E1E1E",
    borderRadius: 20,
    paddingVertical: 8,
    alignItems: "center",
    marginRight: 6,
  },
  tabActive: {
    backgroundColor: "#00D26A",
  },
  tabText: {
    color: "#888",
    fontWeight: "500",
  },
  tabTextActive: {
    color: "#fff",
  },
  challengeCard: {
    backgroundColor: "#1E1E1E",
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  matchRowSmall: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
  },
  smallLogo: {
    width: 30,
    height: 30,
    resizeMode: "contain",
  },
  smallTeamName: {
    color: "#fff",
    fontSize: 12,
    flexShrink: 1,
  },
  smallScore: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  topbar: {
    width: width - 32,
    height: 20,
    borderRadius: 30,
    borderColor: "#ffffff",
    borderWidth: 1,
    position: "absolute",
    top: 70,
    zIndex: 10,
    elevation: 10,
    alignSelf: "center",
  },
  topbarFill: {
    width: "70%",
    height: 18,
    borderRadius: 30,
    backgroundColor: "#00D26A",
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: "#fff",
  },
});
