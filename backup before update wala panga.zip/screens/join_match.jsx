import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  ScrollView,
  TouchableOpacity,
  Image,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

export default function JoinMatch() {
  const [tab, setTabe] = useState(true);
  const navigation = useNavigation();
  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1, paddingTop: 10 }}
    >
      <SafeAreaView style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <MaterialIcons name="arrow-back" size={26} color="#EAEAEA" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}></Text>
        </View>

        {/* Scrollable Content */}
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={{ marginBottom: 20 }}>
            {/* Profile Card */}
            <View style={styles.profileSection}>
              <Image
                source={{
                  uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH7x-pmiDVaj5VEBh1GK63tHwEPd_gfY03ZmMcUxn2csDkFFAiVt-gY1-prZ1xtPQi5mCwcSSJphOfTgfanm57BJmOGSAGynSDKMkBlXbhhPwIiq8ZWM8E434YPfGab8LneRfXSAixuDaXkr7UgLrSyA4UaqPrLjTypp_WHQ8fSGl-5-_1-tIiHwQ1KrTB5wlfm-nI677MJcAUG164LGRGJXQ44iouYSsuwc6WktbElDIec-Nzo0q5VO9LSQT_E65IIPo3Cski5yWh",
                }}
                style={styles.avatar}
                imageStyle={{ borderRadius: 100 }}
              />
              <Text style={styles.playerName}>Alex Hunter</Text>
              <Text style={styles.playerInfo}>Striker - Real Madrid CF</Text>
              <Text style={styles.playerRating}>
                85 <Text style={styles.ratingText}>OVR</Text>
              </Text>
            </View>

            {/* Share Button */}
            <TouchableOpacity style={styles.shareButton}>
              <MaterialIcons name="share" size={20} color="black" />
              <Text style={styles.shareText}>Share my Card</Text>
            </TouchableOpacity>

            {/* Level Progress */}
            <View style={styles.levelSection}>
              <View style={styles.levelHeader}>
                <Text style={styles.levelText}>Level 12</Text>
                <Text style={styles.xpText}>1500 / 2000 XP</Text>
              </View>
              <View style={styles.progressBar}>
                <View style={styles.progressFill}></View>
              </View>
            </View>

            {/* Stats Summary */}
            <View style={styles.tabHeader}>
              <TouchableOpacity onPress={() => setTabe(true)}>
                <Text style={[styles.tabTitle, tab && styles.activeTab]}>
                  Global History
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setTabe(false)}>
                <Text style={[styles.tabTitle, !tab && styles.activeTab]}>
                  Personal Records
                </Text>
              </TouchableOpacity>
            </View>

            {(tab && (
              <View style={styles.summaryGrid}>
                {[
                  { label: "Matches", value: "124" },
                  { label: "Wins", value: "88" },
                  { label: "Losses", value: "21" },
                  { label: "Draws", value: "15" },
                ].map((item, i) => (
                  <View key={i} style={styles.summaryCard}>
                    <Text style={styles.summaryValue}>{item.value}</Text>
                    <Text style={styles.summaryLabel}>{item.label}</Text>
                  </View>
                ))}
                <View style={[styles.summaryCard, { gridColumn: "span 1" }]}>
                  <Text style={styles.summaryLabel}>Total Playing Time</Text>
                  <Text style={styles.summaryValue}>10,540 Mins</Text>
                </View>
              </View>
            )) || (
              <View style={[styles.statsGrid, { paddingTop: 20 }]}>
                {[
                  { label: "Speed", value: "92" },
                  { label: "Shooting", value: "89" },
                  { label: "Physical", value: "85" },
                  { label: "Dribbling", value: "90" },
                  { label: "Passes", value: "165" },
                  { label: "Defense", value: "105" },
                ].map((item, i) => (
                  <View key={i} style={styles.statCard}>
                    <Text style={styles.statLabel}>{item.label}</Text>
                    <Text style={styles.statValue}>{item.value}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#EAEAEA",
  },
  profileSection: {
    alignItems: "center",
    paddingVertical: 20,
  },
  avatar: {
    width: 128,
    height: 128,
    borderWidth: 4,
    borderColor: "#00C26D",
    borderRadius: 100,
  },
  playerName: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 10,
  },
  playerInfo: {
    color: "#9ca3af",
  },
  playerRating: {
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 10,
    color: "white",
    fontSize: 28,
    fontWeight: "bold",
    marginTop: 6,
  },
  ratingText: {
    color: "#00C26D",
    fontSize: 20,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    gap: 8,
  },
  statCard: {
    backgroundColor: "#1F1F1F",
    borderWidth: 1,
    borderColor: "#2D3748",
    borderRadius: 12,
    width: "48%",
    padding: 12,
  },
  statLabel: {
    color: "#9ca3af",
    fontSize: 14,
  },
  statValue: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
  },
  shareButton: {
    marginTop: 20,
    flexDirection: "row",
    backgroundColor: "#00C26D",
    borderRadius: 10,
    alignSelf: "center",
    paddingHorizontal: 20,
    height: 48,
    alignItems: "center",
    gap: 8,
  },
  shareText: {
    color: "black",
    fontWeight: "bold",
  },
  levelSection: {
    paddingHorizontal: 16,
    marginTop: 24,
  },
  levelHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  levelText: {
    color: "#EAEAEA",
    fontWeight: "bold",
    fontSize: 18,
  },
  xpText: {
    color: "#9ca3af",
    fontSize: 14,
  },
  progressBar: {
    backgroundColor: "#1F1F1F",
    borderWidth: 1,
    borderColor: "#2D3748",
    borderRadius: 20,
    marginTop: 8,
    height: 10,
  },
  progressFill: {
    width: "75%",
    height: "100%",
    backgroundColor: "#00C26D",
    borderRadius: 20,
  },
  tabHeader: {
    flexDirection: "row",
    justifyContent: "space-around",
    borderBottomWidth: 1,
    borderColor: "#2D3748",
    marginTop: 20,
  },
  tabTitle: {
    color: "#9ca3af",
    paddingVertical: 10,
    fontWeight: "bold",
  },
  activeTab: {
    color: "#00C26D",
    borderBottomWidth: 2,
    borderColor: "#00C26D",
  },
  summaryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    marginTop: 16,
  },
  summaryCard: {
    backgroundColor: "#1F1F1F",
    borderColor: "#2D3748",
    borderWidth: 1,
    borderRadius: 12,
    width: "48%",
    paddingVertical: 16,
    alignItems: "center",
    marginVertical: 5,
  },
  summaryLabel: {
    color: "#9ca3af",
  },
  summaryValue: {
    color: "#EAEAEA",
    fontSize: 22,
    fontWeight: "bold",
  },
  personalSection: {
    paddingHorizontal: 16,
    marginTop: 30,
    marginBottom: 80,
  },
  sectionTitle: {
    color: "#EAEAEA",
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 10,
  },
  optionCard: {
    backgroundColor: "#1F1F1F",
    borderColor: "#2D3748",
    borderWidth: 1,
    borderRadius: 10,
    padding: 14,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  optionLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  optionText: {
    color: "#EAEAEA",
    fontSize: 15,
  },
  bottomNav: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#1F1F1F",
    borderTopWidth: 1,
    borderColor: "#2D3748",
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
  },
  navItem: {
    alignItems: "center",
  },
  navLabel: {
    fontSize: 12,
    color: "#9ca3af",
  },
});
