// FindMatchScreen.jsx

import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Dimensions,
  ActivityIndicator,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { MaterialIcons } from "@expo/vector-icons";
import MapView, { Marker } from "react-native-maps";
import BottomSheet from "react-native-simple-bottom-sheet";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { supabase } from "./api/supabase";
import * as Location from "expo-location";

const PRIMARY = "#00C26D";
const BG_LIGHT = "#f6f7f8";

export default function FindMatchScreen() {
  const [matches, setMatches] = useState([]);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState("");
  const [region, setRegion] = useState({
    latitude: 48.8566,
    longitude: 2.3522,
    latitudeDelta: 0.08,
    longitudeDelta: 0.08,
  });
  const panelRef = useRef(null);
  const navigation = useNavigation();

  useEffect(() => {
    fetchMatches();
    getUserLocation();
  }, []);

  const getUserLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return;

      const loc = await Location.getCurrentPositionAsync({});
      setRegion((prev) => ({
        ...prev,
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      }));
    } catch (e) {
      console.log("Location error:", e);
    }
  };

  const fetchMatches = async () => {
    try {
      const { data, error } = await supabase
        .from("matchs")
        .select("*")
        .eq("match_status", "waiting")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Match fetch error:", error);
        return;
      }

      const parsed = (data || []).map((m) => {
        let coords = null;
        if (m.loc_codrinates) {
          const [lat, lng] = m.loc_codrinates.split(",").map(Number);
          if (!isNaN(lat) && !isNaN(lng)) {
            coords = { latitude: lat, longitude: lng };
          }
        }
        return {
          ...m,
          coords,
          title: `${m.challanger} vs ${m.opponent}`,
          players: `${m.match_status}`,
        };
      });

      setMatches(parsed);
      if (parsed.length > 0) setSelectedMatch(parsed[0]);
    } catch (err) {
      console.error("Unexpected error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkerPress = (match) => {
    setSelectedMatch(match);
    panelRef.current?.togglePanel();
  };

  const filteredMatches = matches.filter((m) => {
    if (!searchText.trim()) return true;
    const q = searchText.toLowerCase();
    return (
      (m.location || "").toLowerCase().includes(q) ||
      (m.challanger || "").toLowerCase().includes(q) ||
      (m.opponent || "").toLowerCase().includes(q)
    );
  });

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={styles.root}>
        <StatusBar style="light" />

        {/* Top Bar */}
        <View style={styles.topBar}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{ marginRight: 8 }}
          >
            <MaterialIcons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.searchContainer}>
            <View style={styles.searchBox}>
              <View style={styles.searchIconWrapper}>
                <MaterialIcons name="search" size={22} color="#737373" />
              </View>

              <TextInput
                style={styles.searchInput}
                placeholder="Location, field, or team."
                placeholderTextColor="#737373"
                keyboardType="default"
                value={searchText}
                onChangeText={setSearchText}
              />
            </View>
          </View>

          <View style={styles.actions}>
            <TouchableOpacity style={styles.iconButton} onPress={fetchMatches}>
              <MaterialIcons name="refresh" size={24} color={PRIMARY} />
            </TouchableOpacity>
          </View>
        </View>

        {/* MAP */}
        <View style={{ flex: 1 }}>
          {loading ? (
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ActivityIndicator size="large" color={PRIMARY} />
            </View>
          ) : (
            <MapView
              style={StyleSheet.absoluteFill}
              region={region}
              onRegionChangeComplete={setRegion}
            >
              {filteredMatches
                .filter((m) => m.coords)
                .map((match) => (
                  <Marker
                    key={match.id}
                    coordinate={match.coords}
                    onPress={() => handleMarkerPress(match)}
                  >
                    <View style={styles.markerWrapper}>
                      <View style={styles.markerPrimary}>
                        <MaterialIcons
                          name="sports-soccer"
                          size={16}
                          color="#fff"
                        />
                      </View>
                    </View>
                  </Marker>
                ))}
            </MapView>
          )}
        </View>

        {/* BOTTOM SHEET */}
        <BottomSheet
          ref={panelRef}
          sliderMinHeight={selectedMatch ? 120 : 40}
          sliderMaxHeight={Dimensions.get("screen").height - 100}
          isOpen={false}
          wrapperStyle={{ backgroundColor: "#0b0809" }}
          lineStyle={{ width: 60, height: 4, backgroundColor: "#ccc" }}
          containerStyle={styles.sheetContainer}
        >
          {selectedMatch ? (
            <View style={styles.sheetContent}>
              <Text style={styles.sheetSubTitle}>
                {selectedMatch.match_status}
              </Text>
              <Text style={styles.sheetTitle}>{selectedMatch.title}</Text>

              <Text style={styles.sheetDetailText}>
                {selectedMatch.location || "Location TBD"}
              </Text>
              <Text style={styles.sheetDetailText}>
                {selectedMatch.date} — {selectedMatch.time}
              </Text>

              <TouchableOpacity
                style={styles.viewDetailsButton}
                onPress={() =>
                  navigation.navigate("MatchDetails", { match: selectedMatch })
                }
              >
                <Text style={styles.viewDetailsText}>View Details</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.sheetContent}>
              <Text style={styles.sheetTitle}>No matches found</Text>
              <Text style={styles.sheetDetailText}>
                Try searching for a different location or check back later.
              </Text>
            </View>
          )}
        </BottomSheet>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#0b0809",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: Platform.OS === "android" ? 8 : 0,
    paddingBottom: 12,
    backgroundColor: "#0b0809",
    marginTop: 35,
  },
  searchContainer: {
    flex: 1,
    marginRight: 8,
  },
  searchBox: {
    flexDirection: "row",
    height: 45,
    borderRadius: 50,
    overflow: "hidden",
  },
  searchIconWrapper: {
    backgroundColor: "#e5e5e5",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    backgroundColor: "#e5e5e5",
    paddingHorizontal: 0,
    fontSize: 14,
    color: "#000000",
  },
  actions: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 5,
  },
  iconButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#e5e5e5",
    marginHorizontal: 2,
    borderRadius: 50,
  },

  // MARKERS
  markerWrapper: {
    alignItems: "center",
    justifyContent: "center",
  },
  markerPrimary: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  markerHighlight: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f59e0b",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  highlightOuter: {
    backgroundColor: "rgba(245,158,11,0.35)",
    padding: 5,
    borderRadius: 30,
  },

  // BOTTOM SHEET
  sheetContainer: {
    backgroundColor: BG_LIGHT,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    padding: 20,
    overflow: "scroll",
  },
  sheetContent: {
    paddingVertical: 10,
  },
  sheetSubTitle: {
    fontSize: 14,
    color: BG_LIGHT,
    opacity: 0.8,
  },
  sheetTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginTop: 4,
    color: BG_LIGHT,
  },
  sheetDetailText: {
    marginTop: 8,
    fontSize: 14,
    color: BG_LIGHT,
    opacity: 0.8,
  },
  viewDetailsButton: {
    marginTop: 18,
    height: 48,
    borderRadius: 8,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
  },
  viewDetailsText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "700",
  },
});
