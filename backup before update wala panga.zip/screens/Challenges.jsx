import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { supabase } from "./api/supabase";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

const PRIMARY = "#1DB954";
const TEXT_MUTED = "#B3B3B3";

export default function Challenges({ navigation }) {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMatches = async () => {
    try {
      setLoading(true);

      // 1️⃣ Get logged-in user
      const { data: auth, error: authError } = await supabase.auth.getUser();
      const userId = auth?.user?.id;

      if (authError || !userId) {
        console.log("User not logged in");
        return;
      }

      // 2️⃣ Get user account
      const { data: userData, error: userError } = await supabase
        .from("accounts")
        .select("club_assign")
        .eq("uid", userId)
        .single();

      if (userError || !userData?.club_assign) {
        console.log("assign_id missing");
        return;
      }

      const assignId = userData.club_assign;

      // 3️⃣ Fetch matches
      const { data: matchs, error: matchError } = await supabase
        .from("matchs")
        .select("*")
        .or(`challenger_id.eq.${assignId},opponent_id.eq.${assignId}`)
        .order("created_at", { ascending: false });

      if (matchError) {
        console.error("Match fetch error:", matchError);
        return;
      }

      // 4️⃣ Set matches
      setMatches(matchs || []);
    } catch (err) {
      console.error("Unexpected error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches();
  }, []);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation?.navigate?.("MatchDetails", { match: item })}
    >
      {/* TEAMS */}
      <View style={styles.teamsRow}>
        <View style={styles.teamBox}>
          <Text style={styles.teamName}>{item.challanger}</Text>
          <Text style={styles.teamLabel}>Challenger</Text>
        </View>

        <Text style={styles.vsText}>VS</Text>

        <View style={styles.teamBox}>
          <Text style={styles.teamName}>{item.opponent}</Text>
          <Text style={styles.teamLabel}>Opponent</Text>
        </View>
      </View>

      {/* META */}
      <View style={styles.metaRow}>
        <Text style={styles.metaText}>📍 {item.location}</Text>
        <Text style={styles.metaText}>
          📅 {item.date} — 🕒 {item.time}
        </Text>
      </View>

      {/* STATUS */}
      <View style={styles.statusRow}>
        <View style={styles.statusBadge}>
          <Text style={styles.statusText}>
            {item.match_status || "waiting"}
          </Text>
        </View>

        <MaterialIcons name="chevron-right" size={26} color="white" />
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        {/* HEADER */}
        <View style={styles.appBar}>
          <TouchableOpacity
            style={styles.appBarIcon}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="arrow-back" size={28} color="#fff" />
          </TouchableOpacity>

          <Text style={styles.appBarTitle}>Challenges</Text>
          <View style={styles.appBarIcon} />
        </View>

        {/* CONTENT */}
        <View style={styles.container}>
          {loading ? (
            <View style={styles.center}>
              <Text style={{ color: "white" }}>Loading matches...</Text>
            </View>
          ) : matches.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialIcons
                name="sports-soccer"
                size={60}
                color={TEXT_MUTED}
              />
              <Text style={styles.emptyText}>No matches available</Text>
            </View>
          ) : (
            <FlatList
              data={matches}
              renderItem={renderItem}
              keyExtractor={(item) => item.id.toString()}
              contentContainerStyle={{ paddingBottom: 40 }}
            />
          )}
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

/* ---------------- STYLES ---------------- */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },

  appBarIcon: {
    width: 48,
    height: 48,
    justifyContent: "center",
  },

  appBarTitle: {
    flex: 1,
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginRight: 24,
  },

  card: {
    backgroundColor: "#222",
    padding: 16,
    borderRadius: 14,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },

  teamsRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  teamBox: {
    flex: 1,
    alignItems: "center",
  },

  teamName: {
    color: "white",
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
  },

  teamLabel: {
    color: TEXT_MUTED,
    fontSize: 12,
    marginTop: 2,
  },

  vsText: {
    color: PRIMARY,
    fontSize: 16,
    fontWeight: "900",
    marginHorizontal: 10,
  },

  metaRow: {
    marginTop: 12,
  },

  metaText: {
    color: TEXT_MUTED,
    marginTop: 4,
    fontSize: 13,
  },

  statusRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 14,
  },

  statusBadge: {
    backgroundColor: "rgba(29,185,84,0.15)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },

  statusText: {
    color: PRIMARY,
    fontSize: 13,
    fontWeight: "700",
    textTransform: "capitalize",
  },

  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  emptyText: {
    color: TEXT_MUTED,
    fontSize: 16,
    marginTop: 10,
  },

  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
