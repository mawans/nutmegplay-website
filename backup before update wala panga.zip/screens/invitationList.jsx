import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from "react-native";
import { supabase } from "./api/supabase";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";

const PRIMARY = "#1DB954";
const DANGER = "#E74C3C";
const TEXT_MUTED = "#B3B3B3";

export default function InvitationList({ navigation }) {
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    loadInvites();
  }, []);

  // ---------------- LOAD INVITES ----------------

  const loadInvites = async () => {
    setLoading(true);

    const { data: auth } = await supabase.auth.getUser();
    const userId = auth?.user?.id;

    if (!userId) {
      setInvitations([]);
      setLoading(false);
      return;
    }

    setCurrentUserId(userId);

    const { data: invites, error } = await supabase
      .from("invites")
      .select("*")
      .eq("sent_to", userId)
      .order("created_at", { ascending: false });

    if (error || !invites) {
      console.log("Invite load error:", error);
      setInvitations([]);
      setLoading(false);
      return;
    }

    const senderIds = [
      ...new Set(invites.map((i) => i.sent_by).filter(Boolean)),
    ];

    const { data: users } = await supabase
      .from("accounts")
      .select("*")
      .in("uid", senderIds);

    const usersMap = {};
    (users || []).forEach((u) => {
      usersMap[u.uid] = u;
    });

    const finalInvites = invites.map((invite) => ({
      ...invite,
      sender: invite.sent_by ? usersMap[invite.sent_by] || null : null,
    }));

    setInvitations(finalInvites);
    setLoading(false);
  };

  // ---------------- APPROVE INVITE ----------------
  const approveInvite = async (invite) => {
    try {
      setActionLoading(invite.id);

      const invitedUserId = invite.sent_to;
      if (!invitedUserId) {
        Alert.alert("Error", "Invalid invited user");
        return;
      }

      const clubId = Number(invite.club?.id);
      if (!clubId) {
        Alert.alert("Error", "Invalid club ID");
        return;
      }

      const { data: club, error: clubError } = await supabase
        .from("clubs")
        .select("players")
        .eq("id", clubId)
        .single();

      if (clubError) throw clubError;

      let players = [];

      if (Array.isArray(club.players)) {
        players = [...club.players];
      } else if (club.players && typeof club.players === "object") {
        players = Object.values(club.players);
      }

      if (!players.includes(invite.sent_by)) {
        players.push(invite.sent_by);
      }

      const { error: updateClubError } = await supabase
        .from("clubs")
        .update({ players, number_player: players.length })
        .eq("id", clubId);

      if (updateClubError) throw updateClubError;

      const { error: accountError } = await supabase
        .from("accounts")
        .update({ club_assign: clubId })
        .eq("uid", invite.sent_by);

      if (accountError) throw accountError;

      const { error: inviteError } = await supabase
        .from("invites")
        .update({ status: "approved" })
        .eq("id", invite.id);

      if (inviteError) throw inviteError;

      setInvitations((prev) =>
        prev.map((i) => (i.id === invite.id ? { ...i, status: "approved" } : i))
      );
    } catch (err) {
      console.log("Approve error:", err);
      Alert.alert("Error", err.message || "Failed to approve invitation");
    } finally {
      setActionLoading(null);
    }
  };

  // ---------------- CANCEL INVITE ----------------

  const confirmCancel = (inviteId) => {
    Alert.alert(
      "Cancel Invitation",
      "Are you sure you want to cancel this invitation?",
      [
        { text: "No" },
        {
          text: "Yes, Cancel",
          style: "destructive",
          onPress: async () => {
            await supabase
              .from("invites")
              .update({ status: "cancelled" })
              .eq("id", inviteId);

            setInvitations((prev) =>
              prev.map((i) =>
                i.id === inviteId ? { ...i, status: "cancelled" } : i
              )
            );
          },
        },
      ]
    );
  };

  // ---------------- RENDER ITEM ----------------

  const renderItem = ({ item }) => {
    const club = item.club || {};
    const senderName = item.sender?.fname || "Unknown Player";
    const isPending = item.status === "pending";

    const isClubOwner = club.owner === currentUserId;

    return (
      <View style={styles.card}>
        <View style={styles.logoBox}>
          {item.sender?.image_url ? (
            <Image
              source={{ uri: item.sender.image_url }}
              style={styles.logo}
            />
          ) : club.logo ? (
            <Image source={{ uri: club.logo }} style={styles.logo} />
          ) : (
            <MaterialIcons name="groups" size={30} color={TEXT_MUTED} />
          )}
        </View>

        <View style={{ flex: 1 }}>
          <Text style={styles.clubName}>👤 Invited by: {senderName}</Text>
          <Text style={styles.clubName}>{club.name || "Unknown Club"}</Text>
          <Text style={styles.subText}>Status: {item.status}</Text>
          <Text style={styles.subText}>
            {new Date(item.created_at).toLocaleString()}
          </Text>

          {isPending && isClubOwner && (
            <View style={styles.actions}>
              <TouchableOpacity
                style={[styles.btn, styles.approveBtn]}
                disabled={actionLoading === item.id}
                onPress={() => approveInvite(item)}
              >
                {actionLoading === item.id ? (
                  <ActivityIndicator size="small" color="#000" />
                ) : (
                  <Text style={styles.btnTextDark}>Approve</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.btn, styles.cancelBtn]}
                disabled={actionLoading === item.id}
                onPress={() => confirmCancel(item.id)}
              >
                <Text style={styles.btnTextLight}>Cancel</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    );
  };

  // ---------------- UI ----------------

  if (loading) {
    return (
      <LinearGradient
        colors={["#1a1c2c", "#0b0809", "#0b0809"]}
        style={styles.center}
      >
        <ActivityIndicator size="large" color={PRIMARY} />
      </LinearGradient>
    );
  }

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.appBar}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <MaterialIcons name="arrow-back" size={28} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.appBarTitle}>Invitations</Text>
          <View style={{ width: 28 }} />
        </View>

        <View style={styles.container}>
          {invitations.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="mail-outline" size={48} color={TEXT_MUTED} />
              <Text style={styles.emptyText}>No invitations found</Text>
            </View>
          ) : (
            <FlatList
              data={invitations}
              keyExtractor={(item) => item.id.toString()}
              renderItem={renderItem}
              contentContainerStyle={{ paddingBottom: 40 }}
            />
          )}
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

/* ---------------- STYLES ---------------- */

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },

  appBarTitle: {
    flex: 1,
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },

  card: {
    flexDirection: "row",
    backgroundColor: "#222",
    padding: 14,
    borderRadius: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },

  logoBox: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
    overflow: "hidden",
  },

  logo: { width: "100%", height: "100%" },

  clubName: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },

  subText: {
    color: TEXT_MUTED,
    marginTop: 4,
  },

  actions: {
    flexDirection: "row",
    marginTop: 10,
    gap: 10,
  },

  btn: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },

  approveBtn: {
    backgroundColor: PRIMARY,
  },

  cancelBtn: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: DANGER,
  },

  btnTextDark: {
    color: "#000",
    fontWeight: "700",
  },

  btnTextLight: {
    color: DANGER,
    fontWeight: "700",
  },

  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  emptyText: {
    color: TEXT_MUTED,
    fontSize: 16,
    marginTop: 8,
  },
});
