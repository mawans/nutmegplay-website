import * as Linking from "expo-linking";
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { useStripe } from "@stripe/stripe-react-native";
import { useRoute } from "@react-navigation/native";
import { supabase } from "./api/supabase";

const BG_LIGHT = "#f6f7f8";
const BG_DARK = "#191414";
const PRIMARY = "#1DB954";

export default function PayandJoin({ navigation }) {
  const { initPaymentSheet, presentPaymentSheet } = useStripe();
  const [match, setMatch] = useState();
  const route = useRoute();

  useEffect(() => {
    const matchData = route.params?.clubsData || route.params?.match;
    setMatch(matchData);
  }, []);

  const payAndJoin = async () => {
    try {
      await Linking.openURL(
        "https://buy.stripe.com/test_cNi7sNbcQ4PhgncgXKfEk00",
      );
    } catch (err) {
      console.log(err);
      alert("Unable to open payment page");
    }
  };

  const payAtCenter = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert("Error", "You must be logged in");
        return;
      }
      if (match?.id) {
        // Update match to add current user as a participant
        const { error } = await supabase
          .from("matchs")
          .update({ match_status: "confirmed" })
          .eq("id", match.id);
        if (error) {
          Alert.alert("Error", error.message);
          return;
        }
      }
      Alert.alert(
        "Spot Reserved!",
        "You're confirmed. Please pay at the center before the match.",
        [{ text: "OK", onPress: () => navigation.goBack() }],
      );
    } catch (err) {
      Alert.alert("Error", "Something went wrong");
    }
  };

  // const payAndJoin = async () => {
  //   try {
  //     const res = await fetch(
  //       "https://strddrjneurylxoolimj.supabase.co/functions/v1/create-payment-intent",
  //       {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //           // Authorization: `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
  //         },
  //         body: JSON.stringify({
  //           amount: 10,
  //           matchId: match?.id || "match_123",
  //         }),
  //       }
  //     );

  //     const data = await res.json();

  //     if (!data.clientSecret) {
  //       console.log(data);
  //       alert("Payment initialization failed");
  //       return;
  //     }

  //     const init = await initPaymentSheet({
  //       paymentIntentClientSecret: data.clientSecret,
  //       merchantDisplayName: "NutmegPlay",
  //     });

  //     if (init.error) {
  //       alert(init.error.message);
  //       return;
  //     }

  //     const payment = await presentPaymentSheet();

  //     if (payment.error) {
  //       alert(payment.error.message);
  //       return;
  //     }

  //     alert("Payment successful! You joined the match ⚽");
  //     navigation.goBack();
  //   } catch (err) {
  //     console.log("PAY ERROR:", err);
  //     alert("Something went wrong");
  //   }
  // };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={styles.root}>
        {match && (
          <ScrollView
            contentContainerStyle={{ paddingBottom: 10 }}
            showsVerticalScrollIndicator={false}
          >
            {/* Top App Bar */}
            <View style={styles.appBar}>
              <TouchableOpacity
                style={styles.iconBox}
                onPress={() => navigation?.goBack?.()}
              >
                <MaterialIcons name="arrow-back" size={26} color="#fff" />
              </TouchableOpacity>

              <Text style={styles.appBarTitle}>Payment</Text>

              <TouchableOpacity style={styles.iconBox}>
                {/* <MaterialIcons name="more-vert" size={26} color="#fff" /> */}
              </TouchableOpacity>
            </View>

            {/* Headline */}
            <Text style={styles.pageTitle}>
              Your spot is reserved! Pay to confirm.
            </Text>

            {/* Match Card */}
            <View style={styles.matchCard}>
              <View style={styles.matchImage} />
              <View style={styles.matchInfo}>
                <Text style={styles.mutedLabel}>MATCH DETAILS</Text>
                <Text style={styles.matchTitle}>{match.location}</Text>

                <View style={{ marginTop: 8 }}>
                  <Text style={styles.mutedText}>
                    {match.time + " - " + match.date}
                  </Text>
                  <Text style={styles.mutedText}>Price: $10/player</Text>
                </View>
              </View>
            </View>

            {/* Team Status */}
            <View style={{ paddingHorizontal: 16, paddingTop: 10 }}>
              <Text style={styles.sectionTitle}>Team Status</Text>

              <View style={styles.statusRow}>
                <View style={styles.avatarStack}>
                  <Image
                    style={styles.avatar}
                    source={{
                      uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuCW7kyEDmwYh4-sIxMoUBX4bTItlVtnI9kYgMvJLR76BkQpAD1JUcu4nXrYWbY3iya4gzFILIx8TQXM41mxm_NWcYxILrFsMQTgM97ro3Y36Mn0NMUkcH0PD0q09tkKi1roJvmMlmGeFAoiNqyI8bW_epXVkAdOSoFe5T0cd5-28CmeV8snAitA3Q04EJYsDT4WJkWVhQaLxNujgKKl3Qrd4XkRsBxAinV0rpXNwHQ2BLNiNFff2TPEfAi6eFUlH3NeVah0VRycVb2F",
                    }}
                  />
                  <Image
                    style={styles.avatar}
                    source={{
                      uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuC7UzvTDXqloM5DptpjWUwxCaR4Zw0p0HW3LEk7z8E-ZeEVjCdDzmXS_wf-e66RS5wqCD-3IkoIvcJSgPVbySItghCJJKWuTFLjHLXkTgg9QWTAa45FmP7rIN3FEJTp3LM5G4tBGgpUVh07qCAmSD5vmT3Cqfh0JDGyXh4X0AQkm3624ZQpNO3Zpq5BFQ23T9Q2PQqjJKPdvkm-O6-ftCgYChNSMlTeRDVRReZF3T0twvahgADHmkoosMk71M3exo_Y2kzofxwC6u07",
                    }}
                  />
                  <Image
                    style={styles.avatar}
                    source={{
                      uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuD72KNdFVKwWxai4UEqZkxHg4HuEPrVlnVaYInhmEcCN4QTm_aAA-ZcOBQbKputG_Apen-5nW3hpxjpCvUgA2lo6rFyyGmDTRqzwW_KP-sd9i-VWvc9vvloJ2Kq4s1sEiyx_4HtkmkRMfz-0bZ7pGI6znr7zxxxIa6eXw7cHCCvhnPJC4m14tnYA1DLwFH_rGORjxT1U3ZfekOqUHmOVLk1yVoezPAxSDKyFIrWRQoiD3rfIS-vJKfyDJ79wAtii49fyRt4qr7Apvtd",
                    }}
                  />
                </View>

                <Text style={styles.statusText}>3/10 players have paid.</Text>
              </View>
            </View>

            {/* Choose Payment Method */}
            <Text style={styles.sectionHeader}>Choose your payment method</Text>

            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={styles.payNowBtn}
                onPress={() => payAndJoin()}
              >
                <Text style={styles.payNowText}>Pay $10 Now</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.payLaterBtn}
                onPress={payAtCenter}
              >
                <Text style={styles.payLaterText}>I'll Pay at the Center</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}

        {/* Persistent Bottom Button */}
        {/* <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.chatButton}>
          <MaterialIcons name="chat" size={22} color="#fff" />
          <Text style={styles.chatLabel}>Chat with Team</Text>
        </TouchableOpacity>
      </View> */}
      </SafeAreaView>
    </LinearGradient>
  );
}

/* ------------------ STYLES ------------------ */

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },

  iconBox: {
    width: 48,
    height: 48,
    justifyContent: "center",
    alignItems: "flex-start",
  },

  appBarTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    flex: 1,
    textAlign: "center",
  },

  pageTitle: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "700",
    paddingHorizontal: 16,
    marginTop: 10,
  },

  matchCard: {
    marginTop: 16,
    marginHorizontal: 16,
    backgroundColor: "rgba(255,255,255,0.05)",
    borderRadius: 12,
    overflow: "hidden",
  },

  matchImage: {
    width: "100%",
    height: 170,
    borderRadius: 12,
    backgroundColor: "#333",
  },

  matchInfo: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 4,
  },

  mutedLabel: {
    color: "#9dabb9",
    fontSize: 12,
  },

  matchTitle: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
    marginTop: 3,
  },

  mutedText: {
    color: "#9dabb9",
    fontSize: 15,
  },

  sectionTitle: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 10,
  },

  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },

  avatarStack: {
    flexDirection: "row",
    marginRight: 6,
  },

  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 2,
    borderColor: BG_DARK,
    marginLeft: -10,
  },

  statusText: {
    color: "#ccc",
    fontSize: 15,
  },

  sectionHeader: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "700",
    paddingHorizontal: 16,
    marginTop: 20,
  },

  buttonGroup: {
    paddingHorizontal: 16,
    marginTop: 20,
  },

  payNowBtn: {
    height: 56,
    borderRadius: 10,
    backgroundColor: "#1DB954",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },

  payNowText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },

  payLaterBtn: {
    height: 56,
    borderRadius: 10,
    backgroundColor: "#283039",
    justifyContent: "center",
    alignItems: "center",
  },

  payLaterText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },

  bottomBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 16,
    backgroundColor: "rgba(16,25,34,0.9)",
    borderTopWidth: 1,
    borderTopColor: "#222",
  },

  chatButton: {
    height: 56,
    borderRadius: 10,
    backgroundColor: PRIMARY,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },

  chatLabel: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },
});
