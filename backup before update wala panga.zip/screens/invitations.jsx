import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "./api/supabase";

export default function Invitations() {
  const navigation = useNavigation();
  const route = useRoute();
  const invite = route.params?.invite || {};
  const [ignoring, setIgnoring] = useState(false);

  const clubName = invite.club_name || "Unknown Team";
  const clubLogo = invite.club_logo;
  const location = invite.location || "TBD";
  const matchDate = invite.date
    ? new Date(invite.date).toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    : "TBD";
  const matchTime = invite.time || "TBD";
  const position = invite.position || "Any";
  const message =
    invite.message ||
    "You've been invited to join this match. Hope you can make it!";

  const handleIgnore = async () => {
    if (invite.id) {
      setIgnoring(true);
      const { error } = await supabase
        .from("invites")
        .update({ status: "rejected" })
        .eq("id", invite.id);
      setIgnoring(false);
      if (error) {
        Alert.alert("Error", "Failed to decline invitation");
        return;
      }
    }
    navigation.goBack();
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1, paddingTop: 0 }}
    >
      <SafeAreaView style={styles.root}>
        {/* Top Bar */}
        <View style={styles.topBar}>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="arrow-back" size={28} color="#FFFFFF" />
          </TouchableOpacity>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView contentContainerStyle={styles.content}>
          {/* Team Logo */}
          <TouchableOpacity
            style={styles.logoSection}
            onPress={() => navigation.navigate("TeamDivisionStatusScreen")}
          >
            {clubLogo ? (
              <Image source={{ uri: clubLogo }} style={styles.teamLogo} />
            ) : (
              <View
                style={[
                  styles.teamLogo,
                  {
                    backgroundColor: "#333",
                    justifyContent: "center",
                    alignItems: "center",
                  },
                ]}
              >
                <MaterialIcons name="groups" size={44} color="#B3B3B3" />
              </View>
            )}

            <Text style={styles.teamName}>{clubName}</Text>
          </TouchableOpacity>

          {/* Headline */}
          <Text style={styles.headline}>You've Been Invited!</Text>

          {/* Details List */}
          <View style={styles.detailsList}>
            {/* Location */}
            <View style={styles.detailRow}>
              <View style={styles.detailLeft}>
                <MaterialIcons name="location-pin" size={22} color="#B3B3B3" />
                <Text style={styles.detailLabel}>Location</Text>
              </View>
              <Text style={[styles.detailValue, { paddingLeft: 5 }]}>
                {location}
              </Text>
            </View>

            {/* Date */}
            <View style={styles.detailRow}>
              <View style={styles.detailLeft}>
                <MaterialIcons
                  name="calendar-month"
                  size={22}
                  color="#B3B3B3"
                />
                <Text style={styles.detailLabel}>Date</Text>
              </View>
              <Text style={styles.detailValue}>{matchDate}</Text>
            </View>

            {/* Time */}
            <View style={styles.detailRow}>
              <View style={styles.detailLeft}>
                <MaterialIcons name="schedule" size={22} color="#B3B3B3" />
                <Text style={styles.detailLabel}>Time</Text>
              </View>
              <Text style={styles.detailValue}>{matchTime}</Text>
            </View>

            {/* Position */}
            <View style={styles.detailRow}>
              <View style={styles.detailLeft}>
                <MaterialIcons name="person" size={22} color="#B3B3B3" />
                <Text style={styles.detailLabel}>Position</Text>
              </View>
              <Text style={styles.detailValue}>{position}</Text>
            </View>
          </View>

          {/* Message Card */}
          <View style={styles.messageCard}>
            <Text style={styles.messageTitle}>Message from the Captain</Text>

            <Text style={styles.messageBody}>{message}</Text>
          </View>

          {/* Action Buttons */}
          <View style={styles.footer}>
            <TouchableOpacity
              style={styles.joinButton}
              onPress={() =>
                navigation.navigate("PayandJoin", { match: invite })
              }
            >
              <Text style={styles.joinText}>Join Match</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.ignoreButton, ignoring && { opacity: 0.6 }]}
              onPress={handleIgnore}
              disabled={ignoring}
            >
              <Text style={styles.ignoreText}>
                {ignoring ? "Declining..." : "Ignore"}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const BG = "#191414";
const CARD = "#282828";
const PRIMARY = "#1DB954";
const MUTED = "#535353";
const BORDER = "#3b3b3b";

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },

  /* Top Bar */
  topBar: {
    paddingHorizontal: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  closeButton: {
    height: 40,
    width: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },

  /* Scroll Content */
  content: {
    paddingHorizontal: 20,
    // paddingBottom: 20,
  },

  /* Team Section */
  logoSection: {
    marginTop: 10,
    alignItems: "center",
  },
  teamLogo: {
    height: 110,
    width: 110,
    borderRadius: 55,
  },
  teamName: {
    marginTop: 10,
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
  },

  /* Headline */
  headline: {
    color: "#FFFFFF",
    fontSize: 36,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 30,
  },

  /* Details */
  detailsList: {
    marginTop: 30,
    borderTopWidth: 1,
    borderColor: BORDER,
  },
  detailRow: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderColor: BORDER,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  detailLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  detailLabel: {
    fontSize: 16,
    color: "#B3B3B3",
    fontWeight: "500",
  },
  detailValue: {
    flex: 1,
    textAlign: "right",
    color: "#FFFFFF",
    fontSize: 16,
  },

  /* Message Card */
  messageCard: {
    backgroundColor: CARD,
    padding: 20,
    borderRadius: 16,
    marginTop: 30,
  },
  messageTitle: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "700",
  },
  messageBody: {
    color: "#B3B3B3",
    fontSize: 16,
    marginTop: 10,
    lineHeight: 22,
  },

  /* Footer Buttons */
  footer: {
    // position: "absolute",
    // bottom: 0,
    // left: 0,
    // right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 30,
    // backgroundColor: BG,
  },
  joinButton: {
    backgroundColor: PRIMARY,
    borderRadius: 30,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 12,
  },
  joinText: {
    fontSize: 18,
    fontWeight: "700",
    color: "#fff",
  },
  ignoreButton: {
    backgroundColor: MUTED,
    borderRadius: 30,
    paddingVertical: 16,
    alignItems: "center",
  },
  ignoreText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "700",
  },
});
