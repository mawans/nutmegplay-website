import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { MaterialIcons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import Toast from "react-native-toast-message";
import { supabase } from "./api/supabase";

export default function CreateTeamScreen() {
  const navigation = useNavigation();

  const [clubName, setClubName] = useState("");
  const [clubLogo, setClubLogo] = useState(null);
  const [saving, setSaving] = useState(false);

  const pickLogo = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [1, 1],
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.9,
    });

    if (!res.canceled) {
      setClubLogo(res.assets[0].uri);
    }
  };

  const saveClub = async () => {
    try {
      setSaving(true);

      if (!clubName.trim()) return showError("Enter a valid team name");
      if (!clubLogo) return showError("Upload a team logo");

      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) return showError("You must be logged in");

      const uid = sessionData.session.user.id;

      // ---------- UPLOAD LOGO ----------
      const ext = clubLogo.split(".").pop();
      const fileName = `club_${uid}_${Date.now()}.${ext}`;
      const filePath = `clubs/${fileName}`;

      const formData = new FormData();
      formData.append("file", {
        uri: clubLogo,
        name: fileName,
        type: `image/${ext}`,
      });

      const uploadRes = await fetch(
        `https://strddrjneurylxoolimj.supabase.co/storage/v1/object/nutmegplay/${filePath}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${sessionData.session.access_token}`,
            "x-upsert": "true",
          },
          body: formData,
        }
      );

      if (!uploadRes.ok) {
        console.log(await uploadRes.text());
        throw new Error("Logo upload failed");
      }

      const { data: publicURL } = supabase.storage
        .from("nutmegplay")
        .getPublicUrl(filePath);

      // ---------- INSERT CLUB ----------
      const { data: newClub, error: clubError } = await supabase
        .from("clubs")
        .insert({
          name: clubName,
          logo: publicURL.publicUrl,
          owner: uid,
          players: uid,
        })
        .select()
        .single(); // 🔥 IMPORTANT

      if (clubError) throw clubError;

      // ---------- UPDATE ACCOUNT ----------
      const { error: accountError } = await supabase
        .from("accounts")
        .update({ club_assign: newClub.id })
        .eq("uid", uid);

      if (accountError) throw accountError;

      showSuccess("Team created successfully!");
      navigation.goBack();
    } catch (err) {
      console.log("Save Club Error:", err);
      showError(err.message || "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  const showError = (msg) =>
    Toast.show({ type: "error", text1: "Error", text2: msg });

  const showSuccess = (msg) =>
    Toast.show({ type: "success", text1: "Success", text2: msg });

  return (
    <>
      <LinearGradient
        colors={["#1a1c2c", "#0b0809", "#0b0809"]}
        style={{ flex: 1 }}
      >
        <SafeAreaView style={styles.container}>
          {/* HEADER */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <MaterialIcons name="close" size={26} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Create Your Team</Text>
            <View style={{ width: 26 }} />
          </View>

          {/* CONTENT */}
          <View style={styles.content}>
            {/* LOGO PICKER */}
            <TouchableOpacity style={styles.logoContainer} onPress={pickLogo}>
              {clubLogo ? (
                <Image source={{ uri: clubLogo }} style={styles.logo} />
              ) : (
                <View style={styles.logoPlaceholder}>
                  <MaterialIcons name="add-a-photo" size={32} color="#A7B0BA" />
                  <Text style={styles.logoText}>Add Logo</Text>
                </View>
              )}
            </TouchableOpacity>

            {/* TEAM NAME */}
            <Text style={styles.label}>Team Name</Text>
            <View style={styles.inputWrapper}>
              <MaterialIcons name="edit" size={20} color="#A7B0BA" />
              <TextInput
                value={clubName}
                onChangeText={setClubName}
                placeholder="Enter team name"
                placeholderTextColor="#A7B0BA"
                style={styles.input}
              />
            </View>

            {/* BUTTON */}
            <TouchableOpacity
              style={[styles.createButton, saving && { opacity: 0.6 }]}
              disabled={saving}
              onPress={saveClub}
            >
              {saving ? (
                <ActivityIndicator size="small" color="#0b0809" />
              ) : (
                <Text style={styles.createButtonText}>Create Team</Text>
              )}
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </LinearGradient>

      {/* GLOBAL TOAST */}
      <Toast />
    </>
  );
}

/* ---------------------------------------------------------- */

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16 },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 14,
    alignItems: "center",
  },

  headerTitle: { color: "#fff", fontSize: 18, fontWeight: "700" },

  content: { marginTop: 40, alignItems: "center" },

  logoContainer: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#00C26D",
    marginBottom: 20,
    overflow: "hidden",
  },

  logo: { width: "100%", height: "100%" },

  logoPlaceholder: { alignItems: "center" },

  logoText: { color: "#A7B0BA", fontSize: 12, marginTop: 4 },

  label: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    width: "100%",
    marginBottom: 6,
  },

  inputWrapper: {
    flexDirection: "row",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.3)",
    paddingHorizontal: 10,
    width: "100%",
    height: 50,
    alignItems: "center",
    marginBottom: 20,
  },

  input: { flex: 1, color: "#fff", fontSize: 16, marginLeft: 8 },

  createButton: {
    width: "100%",
    backgroundColor: "#00C26D",
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: "center",
  },

  createButtonText: { color: "#0b0809", fontSize: 16, fontWeight: "700" },
});
