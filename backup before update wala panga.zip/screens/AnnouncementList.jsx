import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { supabase } from "./api/supabase";
import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";

const PRIMARY = "#1DB954";
const TEXT_MUTED = "#B3B3B3";

export default function AnnouncementList({ navigation }) {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) setUserId(user.id);
    };
    loadUser();
  }, []);

  // FETCH ANNOUNCEMENTS
  const fetchAnnouncements = async () => {
    const { data, error } = await supabase
      .from("announcement")
      .select("*")
      .neq("user_id", userId)
      .order("created_at", { ascending: false });

    if (error) {
      Toast.show({
        type: "error",
        text1: "Failed to load announcements",
      });
      return;
    }

    setAnnouncements(data || []);
    setLoading(false);
  };

  useEffect(() => {
    if (userId) {
      fetchAnnouncements();
    }
  }, [userId]);

  const joinMatch = async (announcement) => {
    if (!userId) {
      Toast.show({
        type: "error",
        text1: "Login required",
      });
      return;
    }

    const existingRequests = announcement.requests || [];

    const alreadyRequested = existingRequests.some((r) => r.user_id === userId);

    if (alreadyRequested) {
      Toast.show({
        type: "info",
        text1: "Already requested",
      });
      return;
    }

    const updatedRequests = [
      ...existingRequests,
      { user_id: userId, requested_at: new Date().toISOString() },
    ];

    const { error } = await supabase
      .from("announcement")
      .update({ requests: updatedRequests })
      .eq("id", announcement.id);

    if (error) {
      Toast.show({
        type: "error",
        text1: "Request failed",
        text2: error.message,
      });
      return;
    }

    Toast.show({
      type: "success",
      text1: "Request Sent",
    });

    fetchAnnouncements();
  };

  // CANCEL REQUEST
  const cancelRequest = async (announcement) => {
    const updatedRequests = (announcement.requests || []).filter(
      (r) => r.user_id !== userId,
    );

    const { error } = await supabase
      .from("announcement")
      .update({ requests: updatedRequests })
      .eq("id", announcement.id);

    if (error) {
      Toast.show({
        type: "error",
        text1: "Cancel failed",
        text2: error.message,
      });
      return;
    }

    Toast.show({
      type: "success",
      text1: "Request cancelled",
    });

    fetchAnnouncements();
  };

  const renderItem = ({ item }) => {
    const alreadyRequested =
      item.requests?.some((r) => r.user_id === userId) ?? false;

    return (
      <View style={styles.card}>
        <View style={{ flex: 1 }}>
          <Text style={styles.clubName}>{item.club}</Text>

          {item.message && <Text style={styles.message}>{item.message}</Text>}

          <Text style={styles.subText}>📍 {item.location}</Text>
          <Text style={styles.subText}>
            📅 {item.date} — 🕒 {item.time}
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.joinBtn,
            { backgroundColor: alreadyRequested ? "#8B0000" : PRIMARY },
          ]}
          onPress={() =>
            alreadyRequested ? cancelRequest(item) : joinMatch(item)
          }
        >
          <Text style={styles.joinText}>
            {alreadyRequested ? "Cancel Request" : "Join Match"}
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.appBar}>
          <TouchableOpacity
            style={styles.appBarIcon}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="arrow-back" size={28} color="#ffffff" />
          </TouchableOpacity>

          <Text style={styles.appBarTitle}>Announcements</Text>
          <View style={styles.appBarIcon} />
        </View>

        <View style={styles.container}>
          {loading ? (
            <Text style={styles.loadingText}>Loading announcements...</Text>
          ) : announcements.length === 0 ? (
            <Text style={styles.emptyText}>No announcements available.</Text>
          ) : (
            <FlatList
              data={announcements}
              renderItem={renderItem}
              keyExtractor={(item) => item.id.toString()}
              contentContainerStyle={{ paddingBottom: 40 }}
            />
          )}
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

/* ---------------- STYLES ---------------- */

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },

  appBarIcon: { width: 48, height: 48, justifyContent: "center" },

  appBarTitle: {
    flex: 1,
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginRight: 24,
  },

  loadingText: { color: "white", textAlign: "center", marginTop: 20 },
  emptyText: { color: TEXT_MUTED, textAlign: "center", marginTop: 20 },

  card: {
    backgroundColor: "#222",
    padding: 16,
    borderRadius: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },

  clubName: {
    color: "white",
    fontSize: 17,
    fontWeight: "700",
    marginBottom: 6,
  },

  message: { color: "#fff", opacity: 0.85, marginBottom: 8 },
  subText: { color: TEXT_MUTED, marginTop: 4 },

  joinBtn: {
    marginTop: 12,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },

  joinText: { color: "white", fontWeight: "700", fontSize: 15 },
});
