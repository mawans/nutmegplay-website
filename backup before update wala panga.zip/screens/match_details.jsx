// MatchDetailsScreen.js
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Platform,
} from "react-native";
import { MaterialCommunityIcons, MaterialIcons } from "@expo/vector-icons";
import MapView, { Marker } from "react-native-maps";
import { useNavigation, useRoute } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "./api/supabase";

const PRIMARY = "#1DB954";
const BG_DARK = "#191414";
const CARD_DARK = "#27272a";
const TEXT_PRIMARY = "#ffffff";
const TEXT_SECONDARY = "#e4e4e7";
const TEXT_MUTED = "#a1a1aa";

export default function MatchDetailsScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [match, setMatch] = useState();
  const [playerAccounts, setPlayerAccounts] = useState([]);
  const [totalPlayer, setTotalPlayer] = useState(0);
  const [clubRanks, setclubRanks] = useState(0);
  const [accepting, setAccepting] = useState(false);

  useEffect(() => {
    console.log(route.params?.match);

    setMatch(route.params?.match);
    getPlayers(route.params?.match);
  }, []);

  const getPlayers = async (match_data) => {
    if (!match_data) return;

    const { data: clubs, error } = await supabase
      .from("clubs")
      .select("*")
      .or(`id.eq.${match_data.challenger_id},id.eq.${match_data.opponent_id}`);

    if (error) {
      console.error("Club fetch error:", error);
      return;
    }

    const challengerClub = clubs.find((c) => c.id === match_data.challenger_id);
    const opponentClub = clubs.find((c) => c.id === match_data.opponent_id);
    setclubRanks({
      challenger: challengerClub?.ranking ?? 0,
      opponent: opponentClub?.ranking ?? 0,
    });

    const playerIds = clubs
      .flatMap((club) =>
        Array.isArray(club.players) ? club.players : [club.players],
      )
      .filter(Boolean);

    if (playerIds.length === 0) return;

    const { data: accounts, error: accError } = await supabase
      .from("accounts")
      .select("uid, fname, image_url")
      .in("uid", playerIds);

    if (accError) {
      console.error("Accounts fetch error:", accError);
      return;
    }

    setTotalPlayer(playerIds.length);
    setPlayerAccounts(accounts);
  };

  const coordinates = React.useMemo(() => {
    if (!match?.loc_codrinates) return null;

    const [lat, lng] = match.loc_codrinates.split(",").map(Number);

    if (isNaN(lat) || isNaN(lng)) return null;

    return {
      latitude: lat,
      longitude: lng,
    };
  }, [match]);

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      {match && (
        <SafeAreaView style={styles.root}>
          {/* TOP APP BAR */}
          <View style={styles.topBar}>
            <TouchableOpacity
              style={styles.topIconButton}
              onPress={() =>
                navigation && navigation.goBack && navigation.goBack()
              }
            >
              <MaterialIcons name="arrow-back" size={24} color={TEXT_PRIMARY} />
            </TouchableOpacity>

            <Text style={styles.topTitle}>
              {match.challanger} vs {match.opponent}
            </Text>

            <TouchableOpacity style={styles.topIconButton}>
              <MaterialIcons name="share" size={24} color={TEXT_PRIMARY} />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={{ paddingBottom: 120 }}
          >
            {/* MAP (replaces background-image map) */}
            <View style={styles.mapContainer}>
              {coordinates && (
                <MapView
                  style={styles.map}
                  initialRegion={{
                    latitude: coordinates.latitude,
                    longitude: coordinates.longitude,
                    latitudeDelta: 0.02,
                    longitudeDelta: 0.02,
                  }}
                >
                  <Marker coordinate={coordinates}>
                    <MaterialIcons
                      name="location-on"
                      size={34}
                      color={PRIMARY}
                    />
                  </Marker>
                </MapView>
              )}
            </View>

            {/* MATCH DETAILS CARD */}
            <View style={styles.card}>
              <DetailRow
                icon="calendar-today"
                text={`${match.date} — ${match.time}`}
              />

              <DetailRow icon="location-on" text={match.location} />

              <DetailRow
                icon="sports-soccer"
                text={`Status: ${match.match_status}`}
              />
            </View>

            {/* ORGANIZER + PLAYERS CARD */}
            <View style={styles.card}>
              {/* Organizer */}
              <Text style={styles.sectionLabel}>Organizer</Text>

              <View style={styles.organizerRow}>
                <Image
                  source={{
                    uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuBc_o4WdloVrm6cU-uQR6CYpRuPuJ-uhxtC65Z6FbzyGq2QbEvOEHqgweU8mXWujROXVFE-aZZImYjNXSlaLd-tlggaszaXjvRHWJuWg8pNaBEz8GmzbJTGfyZHuKru1CiNDEaiR0hOW0zzHBn5HMqtKI869zZK5-b706g6ZmBP12oRpqX-_0aOCsgAPLRHS1HcCOr3A1rgQQRKkOwzTxIkrEklnR3J7anK9ILo44E8oKZyw7ImS6pWRr6iiPlaC7TNMYyU0T2bwthN",
                  }}
                  style={styles.organizerImg}
                />

                <View>
                  <Text style={styles.organizerName}>Alex Morgan</Text>
                  <View style={styles.ratingRow}>
                    <MaterialIcons name="star" size={16} color="#fbbf24" />
                    <Text style={styles.ratingText}>4.9 (120 games)</Text>
                  </View>
                </View>
              </View>

              {/* Players */}
              <View style={{ marginTop: 20 }}>
                <View style={styles.playersHeader}>
                  <Text style={styles.sectionLabel}>Players</Text>
                  <Text style={styles.playersCount}>
                    {" "}
                    {totalPlayer} / 10 spots filled
                  </Text>
                </View>

                <View style={styles.progressBarBg}>
                  <View
                    style={[
                      styles.progressFill,
                      { width: 10 * totalPlayer + "%" },
                    ]}
                  />
                </View>

                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={{ marginTop: 10 }}
                >
                  {playerAccounts.map((player) => (
                    <Image
                      key={player.uid}
                      source={{ uri: player.image_url }}
                      style={styles.playerAvatar}
                    />
                  ))}
                </ScrollView>
              </View>
            </View>

            {/* RULES / DESCRIPTION CARD */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Match Details</Text>
              <Text style={styles.description}>
                {match.challanger} vs {match.opponent}
              </Text>

              <View style={styles.grid}>
                <Rule icon="signal-cellular-alt" label="Skill Level: Casual" />
                <Rule icon="grass" label="Surface: Turf" />
                <Rule icon="gpp-bad" label="No slide tackles" />
                <Rule icon="tshirt-crew-outline" label="Bibs provided" />
              </View>
            </View>
          </ScrollView>

          {/* STICKY FOOTER CTA */}
          <View style={styles.ctaWrapper}>
            <TouchableOpacity
              style={[styles.ctaButton, accepting && { opacity: 0.6 }]}
              disabled={accepting || match.match_status === "accepted"}
              onPress={async () => {
                try {
                  setAccepting(true);
                  const { error } = await supabase
                    .from("matchs")
                    .update({
                      match_status: "accepted",
                      challange_status: "accepted",
                    })
                    .eq("id", match.id);
                  if (error) {
                    alert("Failed to accept challenge: " + error.message);
                  } else {
                    setMatch({
                      ...match,
                      match_status: "accepted",
                      challange_status: "accepted",
                    });
                    alert("Challenge accepted! Get ready for the match!");
                  }
                } catch (err) {
                  alert("Something went wrong");
                } finally {
                  setAccepting(false);
                }
              }}
            >
              <Text style={styles.ctaText}>
                {match.match_status === "accepted"
                  ? "Challenge Accepted ✓"
                  : "Accept Challenge"}
              </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      )}
    </LinearGradient>
  );
}

// Reusable Row for details
function DetailRow({ icon, text }) {
  return (
    <View style={styles.detailRow}>
      <View style={styles.detailIconWrapper}>
        <MaterialIcons name={icon} size={22} color={PRIMARY} />
      </View>
      <Text style={styles.detailText}>{text}</Text>
    </View>
  );
}

// Reusable Rule item
function Rule({ icon, label }) {
  if (label == "Bibs provided") {
    return (
      <View style={styles.ruleRow}>
        <MaterialCommunityIcons name={icon} size={20} color={TEXT_MUTED} />
        <Text style={styles.ruleText}>{label}</Text>
      </View>
    );
  } else {
    return (
      <View style={styles.ruleRow}>
        <MaterialIcons name={icon} size={20} color={TEXT_MUTED} />
        <Text style={styles.ruleText}>{label}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    // backgroundColor: BG_DARK,
  },

  scroll: {
    flex: 1,
    paddingHorizontal: 16,
  },

  // Top App Bar (sticky-style feel)
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 12,
    paddingTop: Platform.OS === "android" ? 12 : 8,
    paddingBottom: 10,
    // backgroundColor: "rgba(25, 20, 20, 0.9)",
    marginTop: 0,
  },
  topIconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  topTitle: {
    flex: 1,
    textAlign: "center",
    color: TEXT_PRIMARY,
    fontSize: 17,
    fontWeight: "700",
  },

  // Map
  mapContainer: {
    marginTop: 16,
    height: 220,
    borderRadius: 16,
    overflow: "hidden",
    backgroundColor: "#111827",
  },
  map: {
    flex: 1,
  },

  // Generic card
  card: {
    marginTop: 16,
    padding: 16,
    backgroundColor: CARD_DARK,
    borderRadius: 16,
  },

  // Detail rows in first card
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 14,
  },
  detailIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: "rgba(29, 185, 84, 0.18)", // primary/20
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  detailText: {
    flex: 1,
    fontSize: 15,
    color: TEXT_SECONDARY,
  },

  // Organizer
  sectionLabel: {
    fontSize: 13,
    color: TEXT_MUTED,
    fontWeight: "500",
    marginBottom: 6,
  },
  organizerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 6,
  },
  organizerImg: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  organizerName: {
    fontSize: 16,
    fontWeight: "600",
    color: TEXT_PRIMARY,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 2,
  },
  ratingText: {
    marginLeft: 4,
    fontSize: 13,
    color: TEXT_SECONDARY,
  },

  // Players section
  playersHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  playersCount: {
    fontSize: 13,
    fontWeight: "600",
    color: TEXT_PRIMARY,
  },
  progressBarBg: {
    marginTop: 6,
    height: 10,
    borderRadius: 999,
    backgroundColor: "#3f3f46", // zinc-700-ish
    overflow: "hidden",
  },
  progressFill: {
    height: 10,
    borderRadius: 999,
    backgroundColor: PRIMARY,
  },
  playerAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: BG_DARK,
    marginRight: -10,
  },
  addPlayerCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#52525b",
    borderStyle: "dashed",
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 14,
    backgroundColor: "#18181b",
  },

  // Rules / description
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: TEXT_PRIMARY,
  },
  description: {
    marginTop: 8,
    fontSize: 14,
    lineHeight: 20,
    color: TEXT_SECONDARY,
  },
  grid: {
    marginTop: 16,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  ruleRow: {
    width: "48%",
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  ruleText: {
    marginLeft: 8,
    fontSize: 14,
    color: TEXT_SECONDARY,
  },

  // CTA at bottom
  ctaWrapper: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 20,
    // backgroundColor: "rgba(25, 20, 20, 0.98)",
  },
  ctaButton: {
    height: 54,
    borderRadius: 14,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: PRIMARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 4,
  },
  ctaText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "700",
  },
});
