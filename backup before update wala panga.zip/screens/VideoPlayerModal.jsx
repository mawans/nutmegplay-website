import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
  Dimensions,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

const { width } = Dimensions.get("window");

const PRIMARY = "#16a34a";
const BG = "#101922";
const CARD = "#101922";
const TEXT_MUTED = "#9dabb9";

export default function VideoPlayerScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        {/* HEADER */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <MaterialIcons name="close" size={26} color="white" />
          </TouchableOpacity>

          <Text style={styles.headerTitle}>Video</Text>

          <View style={{ width: 26 }} />
        </View>

        <ScrollView showsVerticalScrollIndicator={false}>
          {/* VIDEO */}
          <View style={styles.videoWrapper}>
            <ImageBackground
              source={{
                uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuDYeBCEWX2xg-R3PLkWQrMj7z5ilBZb-4bByjQ3Fp41-8hF4x_lJaF4P2x4HAlRjP4ZQlckZdHJH_DqzPZ6_YByjEBAeo82Ftt-GM84T9KatUjAqVkxQCt82wvFXCQxKc1sOtzx8msCH0yxrUdRZjOvWI3TCQjy29VFPoc6EkM-4FRzS71sGI5ZW2F_P7kkq3cotpCTUG3ttTNsZ_rZz0zkgCvzXi3HqaTa4S489N5GhqRfjhGA284BuE9bZCRFaJWd-zXmLanx1sYn",
              }}
              style={styles.video}
            >
              <TouchableOpacity style={styles.playBtn}>
                <MaterialIcons name="play-arrow" size={46} color="white" />
              </TouchableOpacity>

              {/* PROGRESS */}
              <View style={styles.progressTrack}>
                <View style={styles.progressFill} />
              </View>

              <View style={styles.timeBadge}>
                <Text style={styles.timeText}>14:20 / 45:00</Text>
              </View>
            </ImageBackground>
          </View>

          {/* CONTENT */}
          <View style={styles.content}>
            <Text style={styles.title}>Manchester City vs. Arsenal</Text>

            <View style={styles.metaRow}>
              <MaterialIcons
                name="calendar-today"
                size={16}
                color={TEXT_MUTED}
              />
              <Text style={styles.metaText}>Oct 28, 2023</Text>
              <Text style={styles.dot}>•</Text>
              <Text style={styles.metaText}>Premier League</Text>
              <Text style={styles.dot}>•</Text>
              <Text style={styles.metaText}>90 min</Text>
            </View>

            {/* ACTION BUTTONS */}
            <View style={styles.actions}>
              <TouchableOpacity style={styles.primaryBtn}>
                <MaterialIcons name="download" size={20} color="white" />
                <Text style={styles.primaryText}>Download</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.secondaryBtn}>
                <MaterialIcons name="ios-share" size={20} color="white" />
                <Text style={styles.secondaryText}>Share</Text>
              </TouchableOpacity>
            </View>

            {/* TAGS */}
            <Text style={styles.sectionLabel}>TAGS</Text>
            <View style={styles.tags}>
              <Tag label="Goal" />
              <Tag label="Highlights" />
              <Tag label="Top Rated" />
            </View>

            {/* SUMMARY */}
            <Text style={styles.sectionLabel}>MATCH SUMMARY</Text>
            <Text style={styles.summary}>
              An intense battle at the Etihad Stadium seeing both sides create
              numerous chances. Features a controversial VAR decision in the
              first half and a spectacular late winner that secures vital points
              in the title race.
            </Text>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

/* ---------------- TAG ---------------- */

function Tag({ label }) {
  return (
    <View style={styles.tag}>
      <Text style={styles.tagText}>{label}</Text>
    </View>
  );
}

/* ---------------- STYLES ---------------- */

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: BG,
  },

  container: {
    flex: 1,
    backgroundColor: BG,
  },

  header: {
    height: 54,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  headerTitle: {
    color: "white",
    fontSize: 17,
    fontWeight: "700",
  },

  videoWrapper: {
    width: "100%",
    aspectRatio: 16 / 9,
    backgroundColor: "black",
  },

  video: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  playBtn: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.25)",
  },

  progressTrack: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: "rgba(255,255,255,0.25)",
  },

  progressFill: {
    width: "33%",
    height: "100%",
    backgroundColor: PRIMARY,
  },

  timeBadge: {
    position: "absolute",
    bottom: 10,
    right: 12,
    backgroundColor: "rgba(0,0,0,0.7)",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },

  timeText: {
    color: "white",
    fontSize: 11,
    fontWeight: "600",
  },

  content: {
    padding: 20,
  },

  title: {
    fontSize: 24,
    fontWeight: "800",
    color: "white",
  },

  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },

  metaText: {
    color: TEXT_MUTED,
    fontSize: 13,
    marginLeft: 4,
  },

  dot: {
    color: TEXT_MUTED,
    marginHorizontal: 6,
  },

  actions: {
    flexDirection: "row",
    gap: 12,
    marginVertical: 24,
  },

  primaryBtn: {
    flex: 1,
    height: 48,
    borderRadius: 10,
    backgroundColor: PRIMARY,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  primaryText: {
    color: "white",
    fontWeight: "700",
  },

  secondaryBtn: {
    flex: 1,
    height: 48,
    borderRadius: 10,
    backgroundColor: "#283039",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  secondaryText: {
    color: "white",
    fontWeight: "700",
  },

  sectionLabel: {
    color: "#94a3b8",
    fontSize: 12,
    fontWeight: "700",
    marginBottom: 8,
  },

  tags: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 28,
  },

  tag: {
    height: 32,
    paddingHorizontal: 14,
    borderRadius: 8,
    backgroundColor: "#283039",
    justifyContent: "center",
    alignItems: "center",
  },

  tagText: {
    color: "white",
    fontSize: 13,
    fontWeight: "600",
  },

  summary: {
    color: "#cbd5e1",
    fontSize: 14,
    lineHeight: 20,
  },
});
