import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ScrollView,
  Image,
  Modal,
  TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { supabase } from "./api/supabase";
import ViewShot from "react-native-view-shot";
import * as MediaLibrary from "expo-media-library";
import {
  GetXpRequiredForNextOvr,
  ApplyXpProgress,
  CalculateMatchXp,
} from "./functions/main";

const { width } = Dimensions.get("window");
const gold = "#31200B";

export default function PlayerStatsScreen() {
  const [userProfile, setUserProfile] = useState(null);
  const [activeStat, setActiveStat] = useState(null);
  const viewShotRef = useRef(null);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    const { data: auth } = await supabase.auth.getUser();
    const userId = auth?.user?.id;
    if (!userId) return;

    const { data } = await supabase
      .from("accounts")
      .select("*")
      .eq("uid", userId)
      .single();

    setUserProfile(data);
  };

  const downloadImage = async () => {
    const uri = await viewShotRef.current.capture();
    await MediaLibrary.requestPermissionsAsync();
    await MediaLibrary.saveToLibraryAsync(uri);
    setActiveStat(null);
  };

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={{ flex: 1 }}
    >
      <ScrollView
        contentContainerStyle={{ alignItems: "center", paddingVertical: 70 }}
        showsVerticalScrollIndicator={false}
      >
        <PlayerCard userProfile={userProfile} />
        <StatsDashboard onOpen={setActiveStat} />
      </ScrollView>

      <Modal visible={!!activeStat} transparent animationType="fade">
        <View style={modal.overlay}>
          <ViewShot ref={viewShotRef} options={{ format: "png", quality: 1 }}>
            <View style={modal.card}>
              <TouchableOpacity
                onPress={() => setActiveStat(null)}
                style={modal.closeBtn}
              >
                <Text style={modal.close}>✕</Text>
              </TouchableOpacity>
              <View style={modal.header}>
                <Text style={modal.title}>{activeStat}</Text>
              </View>

              {activeStat === "DRIBBLES" && (
                <>
                  <Text style={modal.big}>90%</Text>
                  <Text style={modal.sub}>Attempted: 30</Text>
                  <Text style={modal.sub}>Successful: 27</Text>
                  <VerticalBars values={[40, 60, 65, 85]} />
                </>
              )}

              {activeStat === "TIRS" && (
                <>
                  <Donut percent={40} />
                  <Text style={modal.sub}>Shots: 10</Text>
                  <Text style={modal.sub}>Goals: 4</Text>
                </>
              )}

              {activeStat === "PASSES" && (
                <>
                  <ProgressBar percent={80} />
                  <Text style={modal.big}>80%</Text>
                  <Text style={modal.sub}>Successful: 32</Text>
                  <Text style={modal.sub}>Unsuccessful: 8</Text>
                </>
              )}

              {activeStat === "DÉFENSE" && (
                <>
                  <Text style={modal.big}>8</Text>
                  <Text style={modal.sub}>Interceptions</Text>
                  <Text style={modal.big}>12</Text>
                  <Text style={modal.sub}>Duels won</Text>
                </>
              )}

              {activeStat === "PHYSICAL" && (
                <>
                  <LineChart />
                  <Text style={[modal.big, { marginTop: 6 }]}>1200</Text>
                  <Text style={modal.sub}>Minutes played</Text>
                  <Text style={[modal.big, { marginTop: 6 }]}>120km</Text>
                  <Text style={modal.sub}>Distance covered</Text>
                </>
              )}

              {activeStat === "SPEED" && (
                <>
                  <SpeedGauge value={26.3} />
                  <Text style={[modal.sub, { marginTop: 16 }]}>
                    Top Speed km/h
                  </Text>
                  <Text style={[modal.big, { marginTop: 16 }]}>120km</Text>
                  <Text style={modal.sub}>Number of sprints</Text>
                </>
              )}
            </View>
          </ViewShot>

          <TouchableOpacity style={modal.download} onPress={downloadImage}>
            <Text style={modal.downloadText}>Download Image</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </LinearGradient>
  );
}

function PlayerCard({ userProfile }) {
  return (
    <View style={styles.wrapper}>
      <Image
        source={require("../assets/players/playercardbg.png")}
        style={styles.cardBackground}
      />
      <View style={styles.topSection}>
        <View style={styles.masterInfo}>
          <Text style={styles.rating}>{userProfile?.level ?? 85}</Text>
          <Text style={styles.position}>{userProfile?.position ?? "ATT"}</Text>

          <Image
            source={{
              uri: `https://flagcdn.com/16x12/${(userProfile?.country || "fr").toLowerCase()}.png`,
            }}
            style={styles.nation}
          />

          <Image
            source={require("../assets/players/afc-bournemouth.png")}
            style={styles.club}
          />
        </View>
        <View style={styles.playerPicture}>
          {userProfile?.image_url ? (
            <Image
              source={{ uri: userProfile.image_url }}
              style={styles.playerImage}
            />
          ) : (
            <Image
              source={require("../assets/players/IMG_6404-removebg-preview.png")}
              style={styles.playerImage}
            />
          )}
        </View>
      </View>
      <View style={styles.bottomSection}>
        <Text style={styles.playerName}>
          {userProfile?.name || userProfile?.fname || "PLAYER"}
        </Text>
        <View style={styles.featuresRow}>
          <View style={styles.featuresCol}>
            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.speed ?? 1}{" "}
              </Text>
              <Text style={styles.featureTitle}>PAC</Text>
            </Text>

            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.shooting ?? 50}{" "}
              </Text>
              <Text style={styles.featureTitle}>SHO</Text>
            </Text>

            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.passes ?? 50}{" "}
              </Text>
              <Text style={styles.featureTitle}>PAS</Text>
            </Text>
          </View>

          <View style={[styles.featuresCol, { borderRightWidth: 0 }]}>
            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.dribbling ?? 50}{" "}
              </Text>
              <Text style={styles.featureTitle}>DRI</Text>
            </Text>

            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.defense ?? 50}{" "}
              </Text>
              <Text style={styles.featureTitle}>DEF</Text>{" "}
            </Text>

            <Text style={styles.feature}>
              <Text style={styles.featureValue}>
                {userProfile?.physical ?? 50}{" "}
              </Text>
              <Text style={styles.featureTitle}>PHY</Text>
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

function StatsDashboard({ onOpen }) {
  return (
    <View style={styles.statsGrid}>
      <StatCard title="DRIBBLES" onOpen={onOpen}>
        <VerticalBars values={[40, 60, 65, 85]} />
        <Text style={styles.statValue}>90%</Text>
        <Text style={styles.statSubtitle}>Attempted: 30</Text>
        <Text style={styles.statSubtitle}>Successful: 27</Text>
      </StatCard>

      <StatCard title="TIRS" onOpen={onOpen}>
        <Donut percent={40} />
        <Text style={styles.statSubtitle}>Shots: 10</Text>
        <Text style={styles.statSubtitle}>Goals: 4</Text>
      </StatCard>

      <StatCard title="PASSES" onOpen={onOpen}>
        <ProgressBar percent={80} />
        <Text style={styles.statValue}>80%</Text>
        <Text style={styles.statSubtitle}>Successful: 32</Text>
        <Text style={styles.statSubtitle}>Unsuccessful: 8</Text>
      </StatCard>

      <StatCard title="DÉFENSE" onOpen={onOpen}>
        <Text style={styles.statValue}>8</Text>
        <Text style={styles.statSubtitle}>Interceptions</Text>
        <Text style={[styles.statValue, { marginTop: 6 }]}>12</Text>
        <Text style={styles.statSubtitle}>Duels won</Text>
      </StatCard>

      <StatCard title="PHYSICAL" onOpen={onOpen}>
        <LineChart />
        <Text style={[styles.statValue, { marginTop: 6 }]}>1200</Text>
        <Text style={styles.statSubtitle}>Minutes played</Text>
        <Text style={[styles.statValue, { marginTop: 6 }]}>120km</Text>
        <Text style={styles.statSubtitle}>Distance covered</Text>
      </StatCard>

      <StatCard title="SPEED" onOpen={onOpen}>
        <SpeedGauge value={26.3} />
        <Text style={[styles.statSubtitle, { marginTop: 16 }]}>
          Top Speed km/h
        </Text>
        <Text style={[styles.statValue, { marginTop: 16 }]}>120km</Text>
        <Text style={styles.statSubtitle}>Number of sprints</Text>
      </StatCard>
    </View>
  );
}

function StatCard({ title, children, onOpen }) {
  return (
    <TouchableOpacity
      style={styles.statCard}
      activeOpacity={0.85}
      onPress={() => onOpen(title)}
    >
      <Text style={styles.statTitle}>{title}</Text>
      {children}
    </TouchableOpacity>
  );
}

/* ===== CHARTS ===== */

const ProgressBar = ({ percent }) => (
  <View style={chart.progressBg}>
    <View style={[chart.progressFill, { width: `${percent}%` }]} />
  </View>
);

const Donut = ({ percent }) => (
  <View style={chart.donutOuter}>
    <View style={chart.donutInner}>
      <Text style={chart.donutText}>{percent}%</Text>
    </View>
  </View>
);

const VerticalBars = ({ values }) => (
  <View style={chart.barRow}>
    {values.map((v, i) => (
      <View key={i} style={chart.barCol}>
        <View style={[chart.barFill, { height: `${v}%` }]} />
      </View>
    ))}
  </View>
);

const LineChart = () => (
  <View style={chart.lineBox}>
    {[20, 45, 30, 60, 50, 70].map((v, i) => (
      <View key={i} style={[chart.dot, { left: i * 22, bottom: v }]} />
    ))}
  </View>
);

const SpeedGauge = ({ value }) => {
  const MAX_SPEED = 40;
  const angle = (Math.min(value, MAX_SPEED) / MAX_SPEED) * 180 - 90;

  return (
    <View style={{ alignItems: "center" }}>
      <View style={chart.speedArc}>
        <View
          style={[chart.needle, { transform: [{ rotate: `${angle}deg` }] }]}
        />

        {/* center pivot circle */}
        <View style={chart.needleCenter} />
      </View>

      <Text style={[styles.statValue, { marginTop: 10 }]}>{value}</Text>
    </View>
  );
};

// const SpeedGauge = ({ value }) => (
//   <View style={chart.speedArc}>
//     <View style={chart.needle} />
//     <Text style={styles.statValue}>{value}</Text>
//   </View>
// );

/* ===== STYLES (UNCHANGED) ===== */

const modal = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.9)",
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    width: width * 0.9,
    backgroundColor: "#0e1114",
    borderRadius: 22,
    padding: 30,
    justifyContent: "center",
    alignItems: "center",
    height: "auto",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  title: {
    color: "white",
    fontSize: 24,
    fontWeight: "800",
    marginBottom: 30,
  },
  close: {
    color: "#aaa",
    fontSize: 24,
  },
  closeBtn: {
    position: "absolute",
    right: 20,
    top: 20,
  },
  big: {
    fontSize: 40,
    fontWeight: "900",
    color: "white",
    marginTop: 12,
  },
  sub: {
    color: "#aaa",
    marginBottom: 5,
    fontSize: 18,
  },
  download: {
    marginTop: 20,
    backgroundColor: "#00C26D",
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 30,
  },
  downloadText: { color: "black", fontWeight: "800", fontSize: 16 },
});

const styles = StyleSheet.create({
  wrapper: {
    width: 280,
    height: 420,
    alignItems: "center",
    position: "relative",
    marginBottom: 30,
  },
  cardBackground: {
    position: "absolute",
    width: "100%",
    height: "100%",
    resizeMode: "stretch",
  },
  topSection: {
    width: "100%",
    alignItems: "center",
    paddingTop: 40,
  },
  masterInfo: {
    position: "absolute",
    left: 15,
    top: 30,
    alignItems: "flex-start",
  },
  rating: {
    fontSize: 35,
    fontWeight: "500",
    color: gold,
  },
  position: {
    fontSize: 22,
    color: gold,
    fontWeight: "600",
    marginTop: 5,
  },
  nation: {
    width: 35,
    height: 25,
    marginTop: 10,
  },
  club: {
    width: 35,
    height: 35,
    resizeMode: "contain",
    marginTop: 10,
  },
  playerPicture: {
    width: 200,
    height: 200,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: "16%",
  },
  playerImage: {
    width: "100%",
    height: "100%",
    resizeMode: "contain",
  },
  bottomSection: {
    width: "90%",
    alignItems: "center",
    marginTop: 10,
  },
  playerName: {
    color: gold,
    fontSize: 22,
    fontWeight: "700",
    textTransform: "uppercase",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(233,204,116,0.2)",
    paddingBottom: 4,
  },
  featuresRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 3,
    width: 200,
    marginLeft: 50,
  },
  featuresCol: {
    borderRightWidth: 1,
    borderRightColor: "rgba(233,204,116,0.2)",
    paddingHorizontal: 15,
  },
  feature: {
    fontSize: 18,
    color: gold,
    marginVertical: 2,
  },
  featureValue: {
    fontWeight: "700",
    fontSize: 22,
  },
  featureTitle: {
    fontWeight: "400",
  },
  statsGrid: {
    width: width * 0.9,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  statCard: {
    width: "47%",
    backgroundColor: "#282828ff",
    borderRadius: 18,
    padding: 16,
    marginBottom: 16,
    alignItems: "center",
  },
  statTitle: {
    fontWeight: "700",
    color: "#00C26D",
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "800",
    color: "white",
  },
  statSubtitle: {
    fontSize: 14,
    color: "#d5d5d5ff",
    marginTop: 5,
  },
  needle: {
    width: 3,
    height: 45,
    backgroundColor: "#00C26D",
    position: "absolute",
    bottom: 0,
    left: "50%",
    // marginLeft: -1.5,
  },
});

const chart = StyleSheet.create({
  progressBg: {
    width: "100%",
    height: 14,
    backgroundColor: "#e6e6e6",
    borderRadius: 8,
    overflow: "hidden",
    marginVertical: 10,
  },
  progressFill: {
    height: "100%",
    backgroundColor: "#00C26D",
  },
  donutOuter: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 12,
    borderColor: "#00C26D",
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 8,
  },
  donutInner: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
  },
  donutText: {
    fontSize: 22,
    fontWeight: "800",
  },
  barRow: {
    flexDirection: "row",
    height: 90,
    alignItems: "flex-end",
    marginVertical: 8,
  },
  barCol: {
    width: 18,
    height: "100%",
    marginHorizontal: 4,
    justifyContent: "flex-end",
  },
  barFill: {
    width: "100%",
    backgroundColor: "#00C26D",
    borderRadius: 4,
  },
  lineBox: {
    width: "100%",
    height: 90,
    borderLeftWidth: 2,
    borderBottomWidth: 2,
    borderColor: "#ddd",
    position: "relative",
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#00C26D",
    position: "absolute",
  },
  speedArc: {
    width: 140,
    height: 70,
    borderTopLeftRadius: 120,
    borderTopRightRadius: 120,
    borderWidth: 10,
    borderBottomWidth: 0,
    borderColor: "#00C26D",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  needle: {
    width: 2,
    height: 40,
    backgroundColor: "#00C26D",
    position: "absolute",
    bottom: 0,
    transform: [{ rotate: "30deg" }],
  },
  needleCenter: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#00C26D",
    position: "absolute",
    bottom: 5,
    left: "50%",
    marginLeft: -10,
  },
});
