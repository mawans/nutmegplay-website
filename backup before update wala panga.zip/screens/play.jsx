import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "./api/supabase";

export default function Play() {
  const navigation = useNavigation();
  const [userData, setUserData] = useState();
  const [club, setClub] = useState();
  useEffect(() => {
    const user = async () => {
      const uid = (await supabase.auth.getUser()).data.user.id;
      const { data, error } = await supabase
        .from("accounts")
        .select("*")
        .eq("uid", uid);
      setUserData(data);
      setClub(data[0].club_assign);
    };

    user();
  }, []);
  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.screen}
    >
      <SafeAreaView style={styles.container}>
        {/* Top Bar */}
        <View style={styles.header}>
          <View style={{ width: 40 }}></View>
          <Text style={styles.headerTitle}>Choose Your Match</Text>
          <View style={{ width: 40 }}></View>
        </View>
        {/* Main Content */}
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ flex: 1, justifyContent: "center" }}
        >
          {/* Card: Club vs Club */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("ChallengeClubScreen")}
          >
            <View style={styles.cardContent}>
              <View style={styles.cardTop}>
                <View
                  style={[styles.iconBox, { backgroundColor: "#009253ff" }]}
                >
                  <Ionicons
                    name="shield-half-outline"
                    size={30}
                    color="#ffffff"
                  />
                </View>
                <Text style={styles.cardTitle}>Club vs Club</Text>
                <MaterialIcons
                  name="chevron-right"
                  size={24}
                  color="#fff"
                  style={{ marginLeft: "auto" }}
                />
              </View>
              <Text style={styles.cardText}>
                Challenge another club to a match.
              </Text>
            </View>
          </TouchableOpacity>

          {/* Card: Open Play */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("FindMatch")}
          >
            <View style={styles.cardContent}>
              <View style={styles.cardTop}>
                <View
                  style={[styles.iconBox, { backgroundColor: "#009253ff" }]}
                >
                  <MaterialIcons name="groups" size={30} color="#fff" />
                </View>
                <Text style={styles.cardTitle}>Open Play</Text>
                <MaterialIcons
                  name="chevron-right"
                  size={24}
                  color="#fff"
                  style={{ marginLeft: "auto" }}
                />
              </View>
              <Text style={styles.cardText}>
                Join a game and play with new people.
              </Text>
            </View>
          </TouchableOpacity>

          {/* Card: Open Play */}
          {/* <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("InvitationList")}
            // onPress={() => navigation.navigate("InvitationsList")}
          >
            <View style={styles.cardContent}>
              <View style={styles.cardTop}>
                <View
                  style={[styles.iconBox, { backgroundColor: "#009253ff" }]}
                >
                  <MaterialIcons name="notifications" size={30} color="#fff" />
                </View>
                <Text style={styles.cardTitle}>Invitations</Text>
                <MaterialIcons
                  name="chevron-right"
                  size={24}
                  color="#fff"
                  style={{ marginLeft: "auto" }}
                />
              </View>
              <Text style={styles.cardText}>
                Join a game and play with new people.
              </Text>
            </View>
          </TouchableOpacity> */}

          {/* Matches */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("Challenges")}
            // onPress={() => navigation.navigate("InvitationsList")}
          >
            <View style={styles.cardContent}>
              <View style={styles.cardTop}>
                <View
                  style={[styles.iconBox, { backgroundColor: "#009253ff" }]}
                >
                  <MaterialIcons name="sports-soccer" size={30} color="#fff" />
                </View>
                <Text style={styles.cardTitle}>Challenges</Text>
                <MaterialIcons
                  name="chevron-right"
                  size={24}
                  color="#fff"
                  style={{ marginLeft: "auto" }}
                />
              </View>
              <Text style={styles.cardText}>Challenges From Other teams</Text>
            </View>
          </TouchableOpacity>

          {club && (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate("AnnouncementList")}
              // onPress={() => navigation.navigate("InvitationsList")}
            >
              <View style={styles.cardContent}>
                <View style={styles.cardTop}>
                  <View
                    style={[styles.iconBox, { backgroundColor: "#009253ff" }]}
                  >
                    <MaterialIcons name="reply" size={30} color="#fff" />
                  </View>
                  <Text style={styles.cardTitle}>Response</Text>
                  <MaterialIcons
                    name="chevron-right"
                    size={24}
                    color="#fff"
                    style={{ marginLeft: "auto" }}
                  />
                </View>
                <Text style={styles.cardText}>Announcement Response</Text>
              </View>
            </TouchableOpacity>
          )}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    height: Dimensions.get("screen").height,
  },
  container: {
    flex: 1,
    width: "100%",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomColor: "#3b3b3b",
    borderBottomWidth: 1,
  },
  iconButton: {
    padding: 6,
  },
  headerTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
  content: {
    padding: 16,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
  card: {
    width: 300,
    backgroundColor: "#00C26D",
    borderRadius: 16,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 4,
    marginBottom: 14,
    marginHorizontal: "auto",
  },
  cardContent: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  cardTop: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  cardTitle: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "700",
    marginLeft: 10,
  },
  cardText: {
    color: "#1c1c1cff",
    fontSize: 14,
    marginTop: 4,
  },
  navbar: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingTop: 6,
    paddingBottom: 10,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
    alignItems: "flex-end",
  },
  navItem: {
    flex: 1,
    alignItems: "center",
  },
  navText: {
    fontSize: 11,
    fontWeight: "500",
    color: "#9CA3AF",
  },
  playButtonWrapper: {
    flex: 1,
    alignItems: "center",
  },
  playButton: {
    backgroundColor: "#fff",
    borderRadius: 9999,
    width: 60,
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    marginTop: -25,
    borderWidth: 3,
    borderColor: "#fff",
  },
});
