import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  TextInput,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import MapView from "react-native-maps";
import * as Location from "expo-location";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { supabase } from "./api/supabase";

const BG_DARK = "#191414";
const PRIMARY = "#1DB954";
const TEXT_MUTED = "#B3B3B3";

export default function ChallengeClubScreen({ navigation }) {
  const [userClub, setUserClub] = useState(null);
  const [opponentClubs, setOpponentClubs] = useState([]);

  const [searchText, setSearchText] = useState("");
  const [filteredClubs, setFilteredClubs] = useState([]);

  const [opponentLogo, setOpponentLogo] = useState(null);
  const [opponentName, setOpponentName] = useState("Select a Club");
  const [opponentId, setOpponentId] = useState(null);

  const getClubs = async () => {
    const { data: user } = await supabase.auth.getUser();
    const userId = user?.user?.id;

    if (!userId) return;

    const { data: clubs, error } = await supabase.from("clubs").select("*");

    if (error) {
      console.log(error);
      return;
    }

    if (clubs) {
      const myClub = clubs.find((c) => c.owner === userId) || null;
      const opponents = clubs.filter((c) => c.owner !== userId);

      setUserClub(myClub);
      setOpponentClubs(opponents);
    }
  };

  const handleSearch = (text) => {
    setSearchText(text);

    if (!text.trim()) {
      setFilteredClubs([]);
      return;
    }

    const results = opponentClubs.filter((club) =>
      club.name.toLowerCase().includes(text.toLowerCase())
    );

    setFilteredClubs(results);
  };

  const selectClub = (club) => {
    setOpponentName(club.name);
    setOpponentLogo(club.logo);
    setOpponentId(club.id);
    setSearchText(club.name);
    setFilteredClubs([]);
  };

  const [region, setRegion] = useState({
    latitude: 31.5204,
    longitude: 74.3587,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const [placeName, setPlaceName] = useState("");

  async function getUserLocation() {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") return;

    let loc = await Location.getCurrentPositionAsync({});
    const { latitude, longitude } = loc.coords;

    setRegion((prev) => ({ ...prev, latitude, longitude }));

    fetchPlaceName(latitude, longitude);
  }

  async function fetchPlaceName(lat, lng) {
    try {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=YOUR_GOOGLE_API_KEY`;
      const res = await fetch(url);
      const json = await res.json();

      if (json.results?.[0]?.formatted_address) {
        setPlaceName(json.results[0].formatted_address);
      }
    } catch (e) {
      console.log("Reverse geocode error:", e);
    }
  }

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState(new Date());

  const [isDatePickerVisible, setDatePickerVisible] = useState(false);
  const [isTimePickerVisible, setTimePickerVisible] = useState(false);

  const showDatePicker = () => setDatePickerVisible(true);
  const hideDatePicker = () => setDatePickerVisible(false);

  const showTimePicker = () => setTimePickerVisible(true);
  const hideTimePicker = () => setTimePickerVisible(false);

  const handleDateConfirm = (date) => {
    setSelectedDate(date);
    hideDatePicker();
  };

  const handleTimeConfirm = (time) => {
    setSelectedTime(time);
    hideTimePicker();
  };

  const sendChallenge = async () => {
    if (!userClub) {
      alert("Your club is not loaded yet.");
      return;
    }

    if (opponentName === "Select a Club") {
      alert("Please select an opponent club.");
      return;
    }

    if (!placeName) {
      // alert("Please select a location.");
      setPlaceName("paris");
      // return;
    }

    // Format time
    const formattedTime = selectedTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    // Coordinates
    const coords = `${region.latitude},${region.longitude}`;

    // alert(userClub.id);
    const { data, error } = await supabase.from("matchs").insert({
      challanger: userClub.name,
      opponent: opponentName,
      challange_status: "pending",
      location: placeName,
      loc_codrinates: coords,
      date: selectedDate.toDateString(),
      time: formattedTime,
      match_status: "waiting",
      result: null,
      video_url: null,
      video_status: "not_uploaded",
      challenger_id: userClub.id,
      opponent_id: opponentId,
    });

    if (error) {
      console.log("Error inserting match:", error);
      alert("Failed to send challenge.");
      return;
    }

    alert("Challenge sent successfully!");
    navigation.goBack();
  };

  useEffect(() => {
    getClubs();
    getUserLocation();
  }, []);

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={styles.root}>
        {/* HEADER */}
        <View style={styles.appBar}>
          <TouchableOpacity
            style={styles.appBarIcon}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="arrow-back" size={28} color="#ffffff" />
          </TouchableOpacity>

          <Text style={styles.appBarTitle}>Challenge a Club</Text>

          <View style={styles.appBarIcon} />
        </View>

        {(userClub && (
          <>
            <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
              <View style={styles.content}>
                <View style={styles.clubRow}>
                  {/* YOUR CLUB */}
                  <View style={styles.clubCol}>
                    {userClub ? (
                      <Image
                        source={{ uri: userClub.logo }}
                        style={styles.clubLogoImage}
                      />
                    ) : (
                      <View style={styles.opponentCircle}>
                        <MaterialIcons
                          name="home"
                          size={32}
                          color={TEXT_MUTED}
                        />
                      </View>
                    )}

                    <Text style={styles.clubLabel}>Your Club</Text>
                    <Text style={styles.clubSubLabel}>
                      {userClub ? userClub.name : "Loading..."}
                    </Text>
                  </View>

                  {/* OPPONENT CLUB */}
                  <View style={styles.clubCol}>
                    {opponentLogo ? (
                      <Image
                        source={{ uri: opponentLogo }}
                        style={styles.clubLogoImage}
                      />
                    ) : (
                      <View style={styles.opponentCircle}>
                        <MaterialIcons
                          name="shield"
                          size={32}
                          color={TEXT_MUTED}
                        />
                      </View>
                    )}

                    <Text style={styles.clubLabel}>Opponent</Text>
                    <Text style={styles.clubSubLabel}>{opponentName}</Text>
                  </View>
                </View>

                {/* SEARCH OPPONENT */}
                <View style={{ marginBottom: 20 }}>
                  <Text style={styles.fieldLabel}>Choose Opponent Club</Text>

                  <View style={styles.searchClubBox}>
                    <TextInput
                      value={searchText}
                      onChangeText={handleSearch}
                      placeholder="Search Club..."
                      placeholderTextColor={TEXT_MUTED}
                      style={styles.searchClubInput}
                    />

                    <MaterialIcons
                      name="search"
                      size={24}
                      color={TEXT_MUTED}
                      style={{ marginRight: 10 }}
                    />
                  </View>

                  {filteredClubs.length > 0 && (
                    <View style={styles.dropdownResults}>
                      {filteredClubs.map((club) => (
                        <TouchableOpacity
                          key={club.id}
                          style={styles.dropdownResultItem}
                          onPress={() => selectClub(club)}
                        >
                          <Text style={{ color: "white", fontSize: 15 }}>
                            {club.name}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  )}
                </View>

                {/* LOCATION */}
                <View style={styles.fieldBlock}>
                  <Text style={styles.fieldLabel}>Location</Text>

                  <View style={styles.mapWrapper}>
                    <MapView
                      style={styles.map}
                      provider="google"
                      initialRegion={region}
                      onRegionChangeComplete={(reg) => {
                        setRegion(reg);
                        fetchPlaceName(reg.latitude, reg.longitude);
                      }}
                    />

                    <View style={styles.pinWrapper}>
                      <MaterialIcons
                        name="location-pin"
                        size={40}
                        color={PRIMARY}
                      />
                    </View>
                  </View>

                  <Text style={styles.placeName}>
                    {placeName || "Move map to select a location"}
                  </Text>
                </View>

                {/* DATE + TIME */}
                <View style={styles.dateTimeRow}>
                  {/* DATE */}
                  <View style={styles.dateTimeCol}>
                    <Text style={styles.fieldLabel}>Date</Text>

                    <TouchableOpacity
                      style={styles.iconInput}
                      onPress={showDatePicker}
                    >
                      <Text style={{ color: "white" }}>
                        {selectedDate.toDateString()}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {/* TIME */}
                  <View style={styles.dateTimeCol}>
                    <Text style={styles.fieldLabel}>Time</Text>

                    <TouchableOpacity
                      style={styles.iconInput}
                      onPress={showTimePicker}
                    >
                      <Text style={{ color: "white" }}>
                        {selectedTime.toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
              <View style={styles.footer}>
                <TouchableOpacity
                  style={styles.ctaButton}
                  onPress={() => sendChallenge()}
                >
                  <Text style={styles.ctaText}>Send Challenge</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>

            {/* FOOTER */}

            {/* DATE PICKER */}
            <DateTimePickerModal
              isVisible={isDatePickerVisible}
              mode="date"
              onConfirm={handleDateConfirm}
              onCancel={hideDatePicker}
              themeVariant="dark"
            />

            {/* TIME PICKER */}
            <DateTimePickerModal
              isVisible={isTimePickerVisible}
              mode="time"
              onConfirm={handleTimeConfirm}
              onCancel={hideTimePicker}
              themeVariant="dark"
            />
          </>
        )) || (
          <View style={styles.emptyState}>
            <MaterialIcons
              name="group-add"
              size={64}
              color={TEXT_MUTED}
              style={{ marginBottom: 12 }}
            />

            <Text style={styles.emptyTitle}>No Club Found</Text>

            <Text style={styles.emptyText}>
              You need to create or join a club before challenging others.
            </Text>
          </View>
        )}
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },
  appBarIcon: {
    width: 48,
    height: 48,
    justifyContent: "center",
  },
  appBarTitle: {
    flex: 1,
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginRight: 24,
  },

  content: { padding: 16 },

  clubRow: { flexDirection: "row", gap: 12, marginBottom: 20 },
  clubCol: { flex: 1, alignItems: "center" },

  clubLogoImage: {
    width: "100%",
    aspectRatio: 1,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: PRIMARY,
  },

  opponentCircle: {
    width: "100%",
    aspectRatio: 1,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.3)",
    borderStyle: "dashed",
    justifyContent: "center",
    alignItems: "center",
  },

  clubLabel: {
    color: "#fff",
    marginTop: 10,
    fontWeight: "600",
    fontSize: 16,
  },
  clubSubLabel: { color: TEXT_MUTED, fontSize: 14 },

  searchClubBox: {
    height: 56,
    borderRadius: 12,
    backgroundColor: "rgba(0,0,0,0.3)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 16,
  },

  searchClubInput: {
    flex: 1,
    color: "white",
    fontSize: 16,
  },

  dropdownResults: {
    marginTop: 6,
    backgroundColor: "#000",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
    overflow: "hidden",
  },

  dropdownResultItem: {
    padding: 14,
    borderBottomWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },

  fieldBlock: { marginVertical: 10 },

  fieldLabel: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 6,
  },

  mapWrapper: {
    width: "100%",
    height: 230,
    borderRadius: 12,
    overflow: "hidden",
  },
  map: { width: "100%", height: "100%" },

  pinWrapper: {
    position: "absolute",
    left: "50%",
    top: "50%",
    marginLeft: -20,
    marginTop: -40,
  },

  placeName: {
    color: "#fff",
    opacity: 0.8,
    marginTop: 8,
  },

  dateTimeRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 10,
  },

  dateTimeCol: { flex: 1 },

  iconInput: {
    height: 56,
    backgroundColor: "#2E2B2D",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    paddingHorizontal: 16,
    marginTop: 6,
  },

  footer: {
    padding: 16,
  },
  ctaButton: {
    height: 56,
    backgroundColor: PRIMARY,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  ctaText: { color: "white", fontSize: 18, fontWeight: "700" },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 30,
  },

  emptyTitle: {
    color: "white",
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 6,
  },

  emptyText: {
    color: TEXT_MUTED,
    fontSize: 14,
    textAlign: "center",
  },
});
