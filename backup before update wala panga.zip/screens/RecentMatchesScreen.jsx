import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { supabase } from "./api/supabase";

const { width } = Dimensions.get("window");
const PRIMARY = "#22c55e";
const BG_DARK = "#101922";
const CARD_DARK = "#1c2127";
const TEXT_MUTED = "#9dabb9";

export default function RecentMatchesScreen() {
  const navigation = useNavigation();
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentMatches();
  }, []);

  const fetchRecentMatches = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from("accounts")
        .select("club_assign")
        .eq("uid", user.id)
        .single();

      if (!profile?.club_assign) {
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("matchs")
        .select("*")
        .or(
          `challenger_id.eq.${profile.club_assign},opponent_id.eq.${profile.club_assign}`,
        )
        .in("match_status", ["completed", "accepted"])
        .order("created_at", { ascending: false })
        .limit(20);

      if (!error && data) {
        setMatches(data);
      }
    } catch (err) {
      console.error("Failed to fetch matches:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <MaterialIcons name="arrow-back-ios" size={22} color="white" />
        </TouchableOpacity>

        <Text style={styles.headerTitle}>Recent Matches</Text>

        <TouchableOpacity style={{ opacity: 0 }}>
          <MaterialIcons name="tune" size={22} color="white" />
        </TouchableOpacity>
      </View>

      {/* CONTENT */}
      <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
        {loading ? (
          <ActivityIndicator
            size="large"
            color={PRIMARY}
            style={{ marginTop: 40 }}
          />
        ) : matches.length === 0 ? (
          <View
            style={{
              alignItems: "center",
              marginTop: 60,
              paddingHorizontal: 20,
            }}
          >
            <MaterialIcons name="sports-soccer" size={48} color={TEXT_MUTED} />
            <Text
              style={{
                color: TEXT_MUTED,
                fontSize: 16,
                marginTop: 12,
                textAlign: "center",
              }}
            >
              No recent matches found. Play a match to see it here!
            </Text>
          </View>
        ) : (
          matches.map((item) => (
            <MatchCard key={item.id} match={item} navigation={navigation} />
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

/* ---------------- COMPONENTS ---------------- */

function Chip({ label, active }) {
  return (
    <View style={[styles.chip, active && styles.chipActive]}>
      <Text style={[styles.chipText, active && { color: "white" }]}>
        {label}
      </Text>
    </View>
  );
}

function MatchCard({ match, navigation }) {
  const matchDate = match.date
    ? new Date(match.date).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "";
  const title = `${match.challanger || "Team A"} vs ${match.opponent || "Team B"}`;

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() =>
        navigation.navigate("PlayStack", {
          screen: "MatchDetails",
          params: { clubsData: match },
        })
      }
    >
      <View
        style={[
          styles.thumbnail,
          {
            backgroundColor: "#1c2830",
            justifyContent: "center",
            alignItems: "center",
          },
        ]}
      >
        <MaterialIcons name="sports-soccer" size={40} color={PRIMARY} />
      </View>

      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{title}</Text>

        <View style={styles.meta}>
          <MaterialIcons name="calendar-today" size={14} color={TEXT_MUTED} />
          <Text style={styles.metaText}>{matchDate}</Text>
          {match.time && (
            <>
              <Text style={styles.dot}>•</Text>
              <Text style={styles.metaText}>{match.time}</Text>
            </>
          )}
        </View>

        {match.location && (
          <View style={[styles.meta, { marginTop: 4 }]}>
            <MaterialIcons name="location-on" size={14} color={TEXT_MUTED} />
            <Text style={styles.metaText} numberOfLines={1}>
              {match.location}
            </Text>
          </View>
        )}

        <View style={[styles.meta, { marginTop: 6 }]}>
          <View
            style={{
              paddingHorizontal: 8,
              paddingVertical: 3,
              borderRadius: 10,
              backgroundColor:
                match.match_status === "completed" ? "#1a3a2a" : "#2a2a1a",
            }}
          >
            <Text
              style={{
                color: match.match_status === "completed" ? PRIMARY : "#f0c040",
                fontSize: 12,
                fontWeight: "600",
                textTransform: "capitalize",
              }}
            >
              {match.match_status}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function Action({ icon, value }) {
  return (
    <View style={styles.action}>
      <MaterialIcons name={icon} size={18} color={TEXT_MUTED} />
      <Text style={styles.actionText}>{value}</Text>
    </View>
  );
}

function NavItem({ icon, label, active }) {
  return (
    <View style={styles.navItem}>
      <MaterialIcons
        name={icon}
        size={26}
        color={active ? PRIMARY : "#64748b"}
      />
      <Text style={[styles.navText, active && { color: PRIMARY }]}>
        {label}
      </Text>
    </View>
  );
}

/* ---------------- STYLES ---------------- */

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BG_DARK,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    justifyContent: "space-between",
  },

  headerTitle: {
    color: "white",
    fontSize: 18,
    fontWeight: "700",
  },

  filters: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 10,
  },

  chip: {
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#283039",
  },

  chipActive: {
    backgroundColor: PRIMARY,
  },

  chipText: {
    color: "#cbd5e1",
    fontSize: 13,
    fontWeight: "600",
  },

  card: {
    margin: 16,
    backgroundColor: CARD_DARK,
    borderRadius: 14,
    overflow: "hidden",
  },

  thumbnail: {
    width: "100%",
    height: width * 0.56,
    justifyContent: "center",
    alignItems: "center",
  },

  playBtn: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
  },

  duration: {
    position: "absolute",
    bottom: 10,
    right: 10,
    backgroundColor: "rgba(0,0,0,0.7)",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },

  durationText: {
    color: "white",
    fontSize: 11,
    fontWeight: "700",
  },

  cardContent: {
    padding: 14,
  },

  cardTitle: {
    color: "white",
    fontSize: 16,
    fontWeight: "700",
  },

  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 4,
  },

  metaText: {
    color: TEXT_MUTED,
    fontSize: 12,
  },

  dot: {
    color: TEXT_MUTED,
    marginHorizontal: 4,
  },

  score: {
    color: TEXT_MUTED,
    fontSize: 13,
    marginTop: 6,
  },

  actions: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 12,
    alignItems: "center",
  },

  action: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },

  actionText: {
    color: TEXT_MUTED,
    fontSize: 12,
    fontWeight: "700",
  },

  loader: {
    marginVertical: 20,
    alignSelf: "center",
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 4,
    borderColor: "#334155",
    borderTopColor: PRIMARY,
  },
});
