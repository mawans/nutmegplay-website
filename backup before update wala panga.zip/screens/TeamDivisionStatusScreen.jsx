// TeamDivisionStatusScreen.js
import React, { useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Animated,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import DivisionProgressBar from "../components/DivisionProgressBar";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";

const BG_DARK = "#191414";
const CARD_BG = "rgba(39,39,42,0.6)"; // zinc-800/50 style
const PRIMARY = "#FFD600";
const TEXT_MUTED = "#9ca3af";
const BAR_HEIGHT = 400;

const CURRENT_POINTS = 10;
const MAX_POINTS = 21; // 7 matches * 3 points

export default function TeamDivisionStatusScreen({ navigation }) {
  const progress = useRef(new Animated.Value(0)).current;

  const progressRatio = CURRENT_POINTS / MAX_POINTS; // ~0.476

  useEffect(() => {
    Animated.timing(progress, {
      toValue: progressRatio,
      duration: 700,
      useNativeDriver: false,
    }).start();
  }, [progressRatio]);

  const indicatorBottom = progress.interpolate({
    inputRange: [0, 1],
    outputRange: [0, BAR_HEIGHT], // from bottom to top
  });

  return (
    <LinearGradient
      colors={["#1a1c2c", "#0b0809", "#0b0809"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={styles.root}>
        {/* Top App Bar */}
        <View style={styles.appBar}>
          <TouchableOpacity
            style={styles.appBarIconLeft}
            onPress={() => navigation?.goBack?.()}
          >
            <MaterialIcons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>

          <Text style={styles.appBarTitle}>Team Alpha</Text>

          <View style={styles.appBarIconRight}>
            <Image
              source={{
                uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuAsyJ4xh850nWtHmdAGF5JRNe-Nr3dVO7n312Vm9ovQWxPIEmKb6nORM2WfCYFgBb4NWuhe3EfAxLB6vKg2TiXko1RBcnlJHu2xD2syo-KFPh11py-i7OaUrQ7jB36GQMLcIzq7xF-WXUHvDrcMBK0ODQCrweCzfDBNj91OaAXemEAU4fMt3LPWzHQbk3uLu5ak9l4_-T_L2CcJob5E5In1eY-_HMtLD-RWdx4N-N-NJFPr4WA9CT6uoxwwWQzU03EcubbsZIjtwu6i",
              }}
              style={styles.teamLogo}
            />
          </View>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={{ paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.mainGrid}>
            {/* LEFT COLUMN: Division card, stats, rules */}
            <View style={styles.leftColumn}>
              {/* Division Status Card */}
              <View style={styles.divisionCardWrapper}>
                <View style={styles.divisionCard}>
                  <View style={styles.divisionBadgeWrap}>
                    <Image
                      source={{
                        uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuCW1x6UC3W6bhldORHx9S8hPoXQxF6NhmKD2DtwcTVojgggikir0iRc9fLJdvbKuc0OEkMbDB-I_ULnPeVLAVbjMAVvUM0_VAGADaeGQKOaN03A1xp3VGNMabgry8EQH8Sk_li0XWyUnAHj1fPwKfVXdTr3dTkBMk1DwW-czo191wTNPqmOnpRGzfHOdfAL9QqJozw2vPiewafuIdcd1C-FKB5tHgOUwrJ7rO7oNLsJdI2S3NwqZuIQ86PY0A3NRu3JxbBno-OqA8_J",
                      }}
                      style={styles.divisionBadge}
                      resizeMode="contain"
                    />
                  </View>

                  <View style={styles.divisionInfo}>
                    <Text style={styles.subLabel}>Current Division</Text>
                    <Text style={styles.divisionName}>Silver II</Text>

                    <View style={styles.pointsRow}>
                      <View>
                        <Text style={styles.subLabel}>Current Points</Text>
                        <Text style={styles.pointsValue}>{CURRENT_POINTS}</Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>

              {/* Stats Grid */}
              <View style={styles.statsRow}>
                <View style={styles.statCard}>
                  <Text style={styles.statLabel}>Matches Played</Text>
                  <Text style={styles.statValue}>4 / 7</Text>
                </View>

                <View style={styles.statCard}>
                  <Text style={styles.statLabel}>Record (W-D-L)</Text>
                  <Text style={styles.statValue}>3-1-0</Text>
                </View>
              </View>

              {/* Rules Info Card */}
              <View style={styles.rulesCard}>
                <View style={styles.rulesHeader}>
                  <MaterialIcons name="gavel" size={24} color={TEXT_MUTED} />
                  <Text style={styles.rulesTitle}>Division Rules</Text>
                </View>

                <View style={styles.rulesGrid}>
                  <View style={styles.ruleBox}>
                    <Text style={styles.ruleValue}>3</Text>
                    <Text style={styles.ruleCaption}>Points for a Win</Text>
                  </View>

                  <View style={styles.ruleBox}>
                    <Text style={styles.ruleValue}>1</Text>
                    <Text style={styles.ruleCaption}>Point for a Draw</Text>
                  </View>

                  <View style={styles.ruleBox}>
                    <Text style={styles.ruleValue}>0</Text>
                    <Text style={styles.ruleCaption}>Points for a Loss</Text>
                  </View>
                </View>

                <Text style={styles.rulesNote}>
                  Each season consists of 7 matches. Your final point total
                  determines your standing.
                </Text>
              </View>
            </View>

            {/* RIGHT COLUMN: Vertical Progress Bar */}
            <View style={styles.rightColumn}>
              <View style={styles.progressCard}>
                <Text style={styles.progressTitle}>Division Standing</Text>
                <DivisionProgressBar />
              </View>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: BG_DARK,
  },

  appBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: BG_DARK,
  },
  appBarIconLeft: {
    width: 48,
    height: 48,
    justifyContent: "center",
    alignItems: "flex-start",
  },
  appBarTitle: {
    flex: 1,
    textAlign: "center",
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "700",
  },
  appBarIconRight: {
    width: 48,
    height: 48,
    justifyContent: "center",
    alignItems: "center",
  },
  teamLogo: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },

  scroll: {
    flex: 1,
  },

  mainGrid: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: "column",
    gap: 16,
  },

  leftColumn: {
    flex: 2,
    flexDirection: "column",
    gap: 16,
  },

  rightColumn: {
    flex: 1,
  },

  // Division card
  divisionCardWrapper: {
    borderRadius: 16,
    overflow: "hidden",
  },
  divisionCard: {
    flexDirection: "row",
    backgroundColor: CARD_BG,
  },
  divisionBadgeWrap: {
    width: "35%",
    minHeight: 140,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  divisionBadge: {
    width: 120,
    height: 120,
  },
  divisionInfo: {
    flex: 1,
    padding: 16,
    borderLeftWidth: 1,
    borderLeftColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
  },
  subLabel: {
    color: TEXT_MUTED,
    fontSize: 13,
    marginBottom: 4,
  },
  divisionName: {
    color: "#ffffff",
    fontSize: 24,
    fontWeight: "700",
  },
  pointsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 16,
  },
  pointsValue: {
    color: PRIMARY,
    fontSize: 32,
    fontWeight: "700",
  },

  // Stats row
  statsRow: {
    flexDirection: "row",
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: CARD_BG,
    borderRadius: 16,
    padding: 16,
  },
  statLabel: {
    color: TEXT_MUTED,
    fontSize: 14,
    marginBottom: 6,
  },
  statValue: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "700",
  },

  // Rules card
  rulesCard: {
    backgroundColor: CARD_BG,
    borderRadius: 16,
    padding: 16,
  },
  rulesHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  rulesTitle: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "700",
  },
  rulesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "space-between",
    marginTop: 4,
  },
  ruleBox: {
    flexBasis: "30%",
    backgroundColor: BG_DARK,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: "center",
  },
  ruleValue: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "700",
  },
  ruleCaption: {
    color: TEXT_MUTED,
    fontSize: 12,
    textAlign: "center",
    marginTop: 2,
  },
  rulesNote: {
    color: TEXT_MUTED,
    fontSize: 13,
    marginTop: 10,
  },

  // Progress card
  progressCard: {
    backgroundColor: CARD_BG,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
  },
  progressTitle: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 16,
  },
  progressContainerOuter: {
    flex: 1,
    width: "100%",
    alignItems: "center",
  },
  progressBarWrap: {
    width: 120,
    height: BAR_HEIGHT,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  progressBg: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
    overflow: "hidden",
    flexDirection: "column",
  },
  zone: {
    flex: 1,
  },
  indicatorWrapper: {
    position: "absolute",
    left: 0,
    right: 0,
    alignItems: "center",
  },
  indicatorBubble: {
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: BG_DARK,
    borderWidth: 1,
    borderColor: PRIMARY,
    marginBottom: 4,
  },
  indicatorText: {
    color: PRIMARY,
    fontSize: 12,
    fontWeight: "700",
  },
  indicatorCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: PRIMARY,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: BG_DARK,
  },

  // Zone labels overlay
  zoneLabelOverlay: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    paddingVertical: 12,
    justifyContent: "space-between",
  },
  zoneLabelRow: {
    height: "33.33%",
    justifyContent: "center",
  },
  zoneLabelBox: {
    alignItems: "center",
  },
  zoneLabelText: {
    color: "#000000",
    fontSize: 12,
    fontWeight: "600",
  },
  zoneLabelSub: {
    color: "#1f2933",
    fontSize: 11,
  },
});
