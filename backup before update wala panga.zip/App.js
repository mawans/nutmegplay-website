import React, { useEffect, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

// supabase
import { supabase } from "./screens/api/supabase";

// stripe
import { StripeProvider } from "@stripe/stripe-react-native";

// Screens
import Login from "./screens/auth/login";
import Signup from "./screens/auth/signup";
import ForgotPassword from "./screens/auth/forgetpwd";
import Home from "./screens/home";
import Playercard from "./screens/playercard";
import Play from "./screens/play";
import Profile from "./screens/profile";
import MyClub from "./screens/fieldlayout";
import FindMatchScreen from "./screens/find_a_match";
import MatchDetailsScreen from "./screens/match_details";
import JoinMatch from "./screens/join_match";
import CreateAnnouncement from "./screens/CreateAnnouncement";
import Invitations from "./screens/invitations";
import TeamDivisionStatusScreen from "./screens/TeamDivisionStatusScreen";
import PayandJoin from "./screens/PayandJoin";
import ChallengeClubScreen from "./screens/ChallengeClubScreen";
import EditProfile from "./screens/auth/editProfile";
import Club from "./screens/Club";
import CreateTeamScreen from "./screens/CreateTeam";
import Jointeam from "./screens/join_team";
import InvitationList from "./screens/invitationList";
import AnnouncementList from "./screens/AnnouncementList";
import Challenges from "./screens/Challenges";
import RecentMatchesScreen from "./screens/RecentMatchesScreen";
import VideoPlayerModal from "./screens/VideoPlayerModal";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: "#00C26D",
        tabBarInactiveTintColor: "#ccc",
        tabBarStyle: {
          // backgroundColor: "#090708ff",
          backgroundColor: "#0B0809",
          borderTopWidth: 0.2,
          elevation: 0,
          paddingTop: 3,
          paddingBottom: 20,
          height: 60,
        },
      }}
    >
      <Tab.Screen
        name="HomeStack"
        component={HomeStack}
        options={{
          tabBarLabel: "Home",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Stats"
        component={Playercard}
        options={{
          tabBarLabel: "Stats",
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="bar-chart" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="PlayStack"
        component={PlayStack}
        options={{
          tabBarLabel: "Choose Play",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="football" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="TeamStack"
        component={TeamStack}
        options={{
          tabBarLabel: "Team",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="people" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileStack}
        options={{
          tabBarLabel: "Profile",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

function PlayStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Play" component={Play} />
      <Stack.Screen name="FindMatch" component={FindMatchScreen} />
      <Stack.Screen name="MatchDetails" component={MatchDetailsScreen} />
      <Stack.Screen name="Invitations" component={Invitations} />
      <Stack.Screen name="PayandJoin" component={PayandJoin} />
      <Stack.Screen name="InvitationList" component={InvitationList} />
      <Stack.Screen name="AnnouncementList" component={AnnouncementList} />
      <Stack.Screen name="Challenges" component={Challenges} />
      <Stack.Screen
        name="TeamDivisionStatusScreen"
        component={TeamDivisionStatusScreen}
      />

      <Stack.Screen
        name="ChallengeClubScreen"
        component={ChallengeClubScreen}
      />
    </Stack.Navigator>
  );
}

function TeamStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Club" component={Club} />
      <Stack.Screen name="Jointeam" component={Jointeam} />
      <Stack.Screen
        name="CreateAnnouncement"
        component={CreateAnnouncement}
        options={{
          presentation: "modal",
        }}
      />
      <Stack.Screen
        name="CreateTeam"
        component={CreateTeamScreen}
        options={{ presentation: "modal" }}
      />
      <Stack.Screen
        name="MyClub"
        component={MyClub}
        options={{
          animation: "fade",
        }}
      />
      <Stack.Screen name="JoinMatch" component={JoinMatch} />
      <Stack.Screen name="InvitationList" component={InvitationList} />
    </Stack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Home" component={Home} />
      <Stack.Screen name="CreateAnnouncement" component={CreateAnnouncement} />
      <Stack.Screen name="Invitations" component={Invitations} />
      <Stack.Screen
        name="TeamDivisionStatusScreen"
        component={TeamDivisionStatusScreen}
      />
      <Stack.Screen name="PayandJoin" component={PayandJoin} />
    </Stack.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="Signup" component={Signup} />
      <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
    </Stack.Navigator>
  );
}

function ProfileStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen
        name="VideoPlayerModal"
        component={VideoPlayerModal}
        options={{ presentation: "modal" }}
      />
      <Stack.Screen
        name="RecentMatchesScreen"
        component={RecentMatchesScreen}
      />
      <Stack.Screen
        name="Editprofile"
        component={EditProfile}
        options={{
          presentation: "modal",
        }}
      />
    </Stack.Navigator>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSession = async () => {
      const { data } = await supabase.auth.getSession();
      setSession(data.session);
      setLoading(false);
    };
    loadSession();

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, newSession) => {
        setSession(newSession);
      },
    );

    return () => listener.subscription.unsubscribe();
  }, []);

  if (loading) return null;

  return (
    <StripeProvider publishableKey="pk_test_51ScRl0Pp55L1txNyAgIDy4jx0sMJe6USPe2AB9duQpFzAotVh9N1JIeTowuUBZ5LTkrfDkIITjtnxa1up89UKFfK00IGJk8EZW">
      <NavigationContainer>
        <StatusBar style="light" />
        {session ? <MainTabs /> : <AuthStack />}
      </NavigationContainer>
    </StripeProvider>
  );
}
