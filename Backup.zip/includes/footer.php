<?php
// Footer include for all pages
?>
</div>
</body>
</html>