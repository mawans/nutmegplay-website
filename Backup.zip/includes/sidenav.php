<?php
// Sidenav include for all pages
?>
<!-- Mobile Overlay -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-40 hidden" onclick="closeMobileMenu()"></div>

<!-- Sidebar -->
<aside id="sidebar"
    class="flex flex-col w-64 h-screen bg-white dark:bg-[#122117] border-r border-slate-200 dark:border-[#264531] fixed left-0 top-0 z-50 transform -translate-x-full md:translate-x-0 transition-all duration-300 ease-in-out"
    data-collapsed="false">
    <div class="p-4 flex items-center justify-between h-16 border-b border-slate-200 dark:border-[#264531]">
        <div class="flex items-center gap-3 sidebar-expanded-content">
            <div class="size-8 text-primary shrink-0">
                <span class="material-symbols-outlined text-[32px]">sports_soccer</span>
            </div>
            <h2 class="text-slate-900 dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">Nutmeg</h2>
        </div>
        <div class="sidebar-collapsed-content" style="display: none;">
            <div class="size-8 text-primary shrink-0">
                <span class="material-symbols-outlined text-[32px]">sports_soccer</span>
            </div>
        </div>
        <button class="md:hidden text-slate-500 hover:text-slate-900 dark:text-text-muted dark:hover:text-white"
            onclick="closeMobileMenu()">
            <span class="material-symbols-outlined">close</span>
        </button>
    </div>
    <nav class="flex-1 px-2 space-y-1 overflow-y-auto sidebar-scroll py-4">
        <?php 
        $current = $currentPage ?? '';
        $navItems = [
            ['url' => '/dashboard', 'icon' => 'dashboard', 'label' => 'Dashboard', 'key' => 'dashboard'],
            ['url' => '/matchmaking', 'icon' => 'handshake', 'label' => 'Matchmaking', 'key' => 'matchmaking'],
            ['url' => '/fixtures', 'icon' => 'event', 'label' => 'Fixtures', 'key' => 'fixtures'],
            ['url' => '/challenges', 'icon' => 'emoji_events', 'label' => 'Challenges', 'key' => 'challenges'],
            ['url' => '/players', 'icon' => 'groups', 'label' => 'Players', 'key' => 'players'],
            ['url' => '/teams', 'icon' => 'shield', 'label' => 'Teams', 'key' => 'teams'],
            ['url' => '/instructor', 'icon' => 'school', 'label' => 'Instructor', 'key' => 'instructor'],
            ['url' => '/match-history', 'icon' => 'history', 'label' => 'Match History', 'key' => 'match-history'],
            ['url' => '/video-upload', 'icon' => 'video_library', 'label' => 'Video Upload', 'key' => 'video-upload'],
        ];
        
        foreach ($navItems as $item):
            $isActive = $current === $item['key'];
            $activeClass = $isActive ? 'bg-primary/10 text-primary' : 'text-slate-600 dark:text-text-muted hover:bg-slate-100 dark:hover:bg-[#1f3629] hover:text-primary dark:hover:text-white';
        ?>
        <a class="nav-link flex items-center gap-4 px-3 py-3 rounded-xl <?= $activeClass ?> transition-all group"
            href="<?= $item['url'] ?>" title="<?= $item['label'] ?>" data-page="<?= $item['key'] ?>">
            <span
                class="material-symbols-outlined shrink-0 <?= $isActive ? '' : 'group-hover:text-primary transition-colors' ?>"><?= $item['icon'] ?></span>
            <span
                class="sidebar-expanded-content <?= $isActive ? 'font-bold' : 'font-medium' ?> text-sm whitespace-nowrap"><?= $item['label'] ?></span>
        </a>
        <?php endforeach; ?>
    </nav>
    <div class="p-3 mt-auto border-t border-slate-200 dark:border-[#264531]">

        <div
            class="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-[#1f3629] cursor-pointer transition-colors">
            <div class="bg-center bg-no-repeat bg-cover rounded-full size-10 border-2 border-primary shrink-0"
                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDlbf6OhStLTPGmxE9bbt7qO38VyCr2NtvwD5GQVcwsgN7e2GrIs-zjkps9zLXaZJ-UhUxEwBVjM65HPaGi_fIZ-8P1wOIrucepRotR8Ju03S10mjFAUwe22CGPEsblRwHLNsitaYW0sPJtIDWP1WZYk1OeFRRnCcV_dQVferO7X-_6mNWx6Gb0ZBlV2W8048y7JrB4OiGw3Its4SAqG2vD5Gr7AkGtbpSP9F5zDmnGc3SJ8NdybY8refJbq-sMlzzOcFXk5TaBVhk");'>
            </div>
            <div class="sidebar-expanded-content flex-1 min-w-0">
                <p class="text-sm font-bold text-slate-900 dark:text-white truncate">Alex_Striker</p>
                <p class="text-xs text-slate-500 dark:text-text-muted truncate">Online</p>
            </div>
            <span class="sidebar-expanded-content material-symbols-outlined text-slate-400">settings</span>
        </div>
        <button
            class="sidebar-expanded-content w-full mt-3 flex items-center justify-center gap-2 text-xs font-medium text-slate-500 dark:text-text-muted hover:text-accent-danger transition-colors">
            <span class="material-symbols-outlined text-sm">logout</span>
            Sign Out
        </button>
    </div>
</aside>