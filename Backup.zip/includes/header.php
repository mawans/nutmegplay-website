<?php
// Header include for all pages
?>
<?php
$pageTitle = $pageTitle ?? 'Nutmeg Dashboard';
$extraHead = $extraHead ?? '';
?>
<!DOCTYPE html>
<html class="dark" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&family=Noto+Sans:wght@400;500;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#1db954",
                        "primary-dark": "#169e46",
                        "accent-danger": "#E74C3C",
                        "background-light": "#f6f8f7",
                        "background-dark": "#122017",
                        "card-dark": "#1b2e21",
                        "card-hover": "#263f2e",
                        "surface-dark": "#1b2e23",
                        "surface-light": "#264531",
                        "panel-dark": "#1a2e22",
                        "text-muted": "#B3B3B3",
                        "muted": "#B3B3B3",
                        "danger": "#E74C3C",
                        "warning": "#F39C12",
                        "team-red": "#E74C3C",
                        "team-blue": "#3498DB",
                    },
                    fontFamily: {
                        "display": ["Lexend", "Space Grotesk", "sans-serif"],
                        "body": ["Noto Sans", "sans-serif"],
                    },
                    borderRadius: {"DEFAULT": "0.5rem", "lg": "1rem", "xl": "1.5rem", "full": "9999px"},
                },
            },
        }
    </script>
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
    <script src="/htmx.js"></script>

    <style>
        /* Custom scrollbar for sidebar */
        .sidebar-scroll::-webkit-scrollbar {
            width: 4px;
        }
        .sidebar-scroll::-webkit-scrollbar-track {
            background: transparent;
        }
        .sidebar-scroll::-webkit-scrollbar-thumb {
            background: #264531;
            border-radius: 2px;
        }
        
        /* Pulse animation for status indicator */
        .pulse-dot {
            animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Mobile responsive improvements */
        @media (max-width: 640px) {
            .stat-value { font-size: 1.75rem !important; }
        }
        
        /* Safe area for mobile devices with notches */
        @supports (padding: max(0px)) {
            body {
                padding-left: max(0px, env(safe-area-inset-left));
                padding-right: max(0px, env(safe-area-inset-right));
            }
        }

        /* Loading bar for hx-boost page transitions */
        .htmx-request #topnav::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            height: 2px;
            background: #1db954;
            animation: htmx-progress 1.5s ease-in-out infinite;
        }
        @keyframes htmx-progress {
            0% { width: 0; }
            50% { width: 70%; }
            100% { width: 100%; }
        }
    </style>
    <?= $extraHead ?>
</head>
<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white font-display min-h-screen overflow-x-hidden transition-colors duration-200" hx-boost="true">
<div class="flex w-full min-h-screen">
<div class="flex flex-col w-full min-h-screen">