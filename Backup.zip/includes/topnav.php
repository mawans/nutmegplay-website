<?php
// Top navigation bar for dashboard pages
$pageHeading = $pageHeading ?? $pageTitle ?? 'Dashboard';
$pageDescription = $pageDescription ?? '';
?>
<!-- Top Navigation Bar -->
<header id="topnav" class="sticky top-0 z-40 h-16 ml-0 md:ml-64 border-b border-slate-200 dark:border-[#264531] flex items-center justify-between px-4 md:px-6 shrink-0 bg-white dark:bg-background-dark backdrop-blur-sm transition-all duration-300 relative">
    <div class="flex items-center gap-4">
        <button class="text-slate-700 dark:text-white hover:text-primary transition-colors" id="mobile-menu-toggle" onclick="toggleMobileMenu()">
            <span class="material-symbols-outlined">menu</span>
        </button>
        <div>
            <h2 class="text-lg md:text-xl font-bold tracking-tight"><?= htmlspecialchars($pageHeading) ?></h2>
            <?php if ($pageDescription): ?>
            <p class="text-xs md:text-sm text-slate-500 dark:text-text-muted hidden md:block"><?= htmlspecialchars($pageDescription) ?></p>
            <?php endif; ?>
        </div>
    </div>
    <div class="flex items-center gap-3">
        <!-- Notifications -->
        <button class="relative p-2 text-slate-600 dark:text-text-muted hover:text-slate-900 dark:hover:text-white transition-colors">
            <span class="material-symbols-outlined">notifications</span>
            <span class="absolute top-1.5 right-1.5 size-2 bg-accent-danger rounded-full border-2 border-white dark:border-background-dark"></span>
        </button>
        <!-- User Menu (Optional - can expand later) -->
        <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-[#1a2c22] border border-slate-200 dark:border-[#264531]">
            <div class="size-2 rounded-full bg-primary pulse-dot"></div>
            <span class="text-xs font-medium text-primary">Active</span>
        </div>
    </div>
</header>
