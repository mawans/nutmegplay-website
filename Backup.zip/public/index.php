<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';

$router = require __DIR__ . '/../app/routes.php';

$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($requestUri, PHP_URL_PATH) ?? '/';

$router->dispatch($path);

