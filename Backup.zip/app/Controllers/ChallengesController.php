<?php
namespace App\Controllers;

use App\Core\Controller;

class ChallengesController extends Controller
{
    public function index(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/challenges.php');
    }
}
