<?php
namespace App\Controllers;

use App\Core\Controller;

class PlayersController extends Controller
{
    public function index(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/players.php');
    }
}
