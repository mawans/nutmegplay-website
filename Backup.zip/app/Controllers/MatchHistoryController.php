<?php
namespace App\Controllers;

use App\Core\Controller;

class MatchHistoryController extends Controller
{
    public function index(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/match-history.php');
    }
}
