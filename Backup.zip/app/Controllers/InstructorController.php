<?php
namespace App\Controllers;

use App\Core\Controller;

class InstructorController extends Controller
{
    public function index(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/instructor.php');
    }
}
