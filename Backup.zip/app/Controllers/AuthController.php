<?php
namespace App\Controllers;

use App\Core\Controller;

class AuthController extends Controller
{
    public function login(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/auth/login.php');
    }

    public function loginAlt(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/auth/login-alt.php');
    }
}
