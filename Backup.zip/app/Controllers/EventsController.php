<?php
namespace App\Controllers;

use App\Core\Controller;

class EventsController extends Controller
{
    public function matchmaking(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/matchmaking.php');
    }
}
