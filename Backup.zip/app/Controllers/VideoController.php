<?php
namespace App\Controllers;

use App\Core\Controller;

class VideoController extends Controller
{
    public function upload(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/video-upload.php');
    }
}
