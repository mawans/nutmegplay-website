<?php
namespace App\Controllers;

use App\Core\Controller;

class HomeController extends Controller
{
    public function dashboard(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/home.php');
    }
}
