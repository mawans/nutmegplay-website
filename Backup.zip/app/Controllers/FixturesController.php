<?php
namespace App\Controllers;

use App\Core\Controller;

class FixturesController extends Controller
{
    public function upcoming(): void
    {
        $this->renderRaw(BASE_PATH . '/app/views/dashboards/fixtures.php');
    }
}
