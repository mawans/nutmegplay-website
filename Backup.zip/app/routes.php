<?php
use App\Core\Router;
use App\Controllers\{
    HomeController,
    EventsController,
    FixturesController,
    ChallengesController,
    InstructorController,
    MatchHistoryController,
    PlayersController,
    TeamController,
    VideoController,
    AuthController
};

$router = new Router();

// Auth routes
$router->get('/login', [AuthController::class, 'login']);
$router->get('/login-alt', [AuthController::class, 'loginAlt']);

// Dashboard routes
$router->get('/', [HomeController::class, 'dashboard']);
$router->get('/dashboard', [HomeController::class, 'dashboard']);
$router->get('/matchmaking', [EventsController::class, 'matchmaking']);
$router->get('/fixtures', [FixturesController::class, 'upcoming']);
$router->get('/challenges', [ChallengesController::class, 'index']);
$router->get('/instructor', [InstructorController::class, 'index']);
$router->get('/match-history', [MatchHistoryController::class, 'index']);
$router->get('/players', [PlayersController::class, 'index']);
$router->get('/teams', [TeamController::class, 'index']);
$router->get('/video/upload', [VideoController::class, 'upload']);
$router->get('/video-upload', [VideoController::class, 'upload']);

return $router;
