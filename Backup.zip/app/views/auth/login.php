<?php 
$pageTitle = 'Login';
require_once BASE_PATH . '/includes/header.php';
?>

<div class="min-h-screen flex items-center justify-center bg-background-light dark:bg-background-dark p-4">
    <div class="w-full max-w-md">
        <div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg p-8">
            <div class="text-center mb-8">
                <div class="size-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span class="material-symbols-outlined text-primary text-4xl">sports_soccer</span>
                </div>
                <h1 class="text-2xl font-bold mb-2">Welcome to PitchPerfect</h1>
                <p class="text-slate-500 dark:text-text-muted">Sign in to your account</p>
            </div>
            
            <form class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Email</label>
                    <input type="email" class="w-full px-4 py-2 rounded border border-slate-200 dark:border-[#264531] bg-white dark:bg-background-dark focus:border-primary focus:ring-1 focus:ring-primary outline-none" placeholder="you@example.com">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Password</label>
                    <input type="password" class="w-full px-4 py-2 rounded border border-slate-200 dark:border-[#264531] bg-white dark:bg-background-dark focus:border-primary focus:ring-1 focus:ring-primary outline-none" placeholder="••••••••">
                </div>
                
                <button type="submit" class="w-full px-4 py-3 bg-primary hover:bg-green-600 text-white font-medium rounded transition-colors">
                    Sign In
                </button>
                
                <p class="text-center text-sm text-slate-500 dark:text-text-muted">
                    Don't have an account? <a href="/register" class="text-primary hover:underline">Sign up</a>
                </p>
            </form>
        </div>
    </div>
</div>

<?php require_once BASE_PATH . '/includes/footer.php'; ?>
