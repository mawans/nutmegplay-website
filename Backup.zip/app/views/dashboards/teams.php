<?php
$pageTitle = 'Teams';
$pageHeading = 'Teams Dashboard';
$pageDescription = 'Manage your teams and squad lineups';
$currentPage = 'teams';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<!-- Search and Actions -->
<div class="flex flex-col sm:flex-row gap-3 mb-6">
<!-- Search Bar -->
<div class="relative w-full sm:w-64 group">
<div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-[#96c5a6] group-focus-within:text-primary transition-colors">
<span class="material-symbols-outlined">search</span>
</div>
<input class="block w-full p-2.5 pl-10 text-sm text-white bg-card-dark border border-white/10 rounded-lg placeholder-[#96c5a6] focus:ring-2 focus:ring-primary focus:border-primary transition-all" placeholder="Search teams or players..." type="text"/>
</div>
<!-- Create Button -->
<button class="flex flex-shrink-0 cursor-pointer items-center justify-center rounded-lg h-[42px] px-4 bg-primary hover:bg-primary/90 hover:shadow-lg transition-all duration-300 hover:scale-105 text-[#122117] gap-2 text-sm font-bold tracking-wide">
<span class="material-symbols-outlined text-[20px]">add</span>
<span>Create Team</span>
</button>
</div>

<!-- Stats Cards -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
<!-- Total Wins -->
<div class="bg-card-dark border border-white/10 rounded-xl p-6 flex flex-col gap-2 relative overflow-hidden group hover:border-primary/30 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 cursor-pointer">
<div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-25 group-hover:scale-110 transition-all duration-300">
<span class="material-symbols-outlined text-6xl text-white">emoji_events</span>
</div>
<p class="text-muted text-sm font-medium">Total Wins</p>
<div class="flex items-end gap-3">
<p class="text-white text-3xl font-bold">12</p>
<div class="flex items-center text-primary bg-primary/10 px-1.5 py-0.5 rounded text-xs font-bold mb-1">
<span class="material-symbols-outlined text-[14px]">trending_up</span>
<span>+2%</span>
</div>
</div>
<p class="text-xs text-muted mt-1">Last match: Won 3-1</p>
</div>
<!-- Win Rate -->
<div class="bg-card-dark border border-white/10 rounded-xl p-6 flex flex-col gap-2 relative overflow-hidden group">
<div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
<span class="material-symbols-outlined text-6xl text-white">pie_chart</span>
</div>
<p class="text-muted text-sm font-medium">Win Rate</p>
<div class="flex items-end gap-3">
<p class="text-white text-3xl font-bold">85%</p>
<div class="flex items-center text-primary bg-primary/10 px-1.5 py-0.5 rounded text-xs font-bold mb-1">
<span class="material-symbols-outlined text-[14px]">trending_up</span>
<span>+5%</span>
</div>
</div>
<div class="w-full bg-white/10 rounded-full h-1.5 mt-2">
<div class="bg-primary h-1.5 rounded-full" style="width: 85%"></div>
</div>
</div>
<!-- Active Players -->
<div class="bg-card-dark border border-white/10 rounded-xl p-6 flex flex-col gap-2 relative overflow-hidden group">
<div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
<span class="material-symbols-outlined text-6xl text-white">groups</span>
</div>
<p class="text-muted text-sm font-medium">Active Players</p>
<div class="flex items-end gap-3">
<p class="text-white text-3xl font-bold">24</p>
<div class="flex items-center text-muted bg-white/10 px-1.5 py-0.5 rounded text-xs font-bold mb-1">
<span>0%</span>
</div>
</div>
<div class="flex -space-x-2 mt-2">
<img alt="Player avatar" class="w-8 h-8 rounded-full border-2 border-card-dark" data-alt="Avatar of active player" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAl5kvWEPDCtB1JRCg5O8BVEqpkajgjwmmYEagU3Niedu1hK7UvLeLsJpPSLDmcrtC8mDzkTU6vL8abxnv1Mnz8YJgSFEBaA-zQgp6j0_4jRHV09hupUuAhiFsFSjTQy6KwM3NVT2RVq-xgd6vaK_KWZ99gbz7qsB5c6csDYlRStJzFN12KdOoWTo-SmkJy6SUQ3kIyYL6zBbE6Nit66Z-zkexuNY_8yCcSKE__NlENy8VnrjpdHZXGwLxSngootn8pX1Ps7A_FYQs"/>
<img alt="Player avatar" class="w-8 h-8 rounded-full border-2 border-card-dark" data-alt="Avatar of active player" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBLOl7MztqFc18XnKwPbTJtv1WFUnU-4l9k0jjRfTf3LkD01PnBfCASPKHqUi2Q0GAm2VQk1q19_3g7asy2zWuOlgQfYq6lnh5ufdCoz0aI1ct5zveKg8gHE1_njack18mowuH2GxhbFYQAa2KgLiWJ8GebldaJR3J6krxyJpfP5kL1yzoQ30TYXUxjii6vCjgzeIvpRMG2ajbCAtTxV1O7N_sQo4l621BdcaDFYVrSs_2XdWj_tWh3tYTUeB-75bZnSG96wMQn65A"/>
<img alt="Player avatar" class="w-8 h-8 rounded-full border-2 border-card-dark" data-alt="Avatar of active player" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB-oEHvf15HNJLiD2keE5iVW8MHAXm1LN9YVft6slok9QR4arTdOj-k5lsvOpso-2ntaY2tETxh8qNFX2JzguYt4RAFbM7E9389S-WhHDTcZ08nIQnRhLI7mIC7FdKdqZ_5Ja19B1LimIpmO00LTna5Il_rA4_pxgpvOURYukLScinMiVIoE9r-jDQtPQdq4zwYReK2rNcu3sipHugiKMlLPBy93b9m4TU7lAw3MZy3O7nplbwve38nv3h9tV8vCcYyzmw1YB0JZSc"/>
<div class="w-8 h-8 rounded-full border-2 border-card-dark bg-primary text-background-dark flex items-center justify-center text-xs font-bold">+21</div>
</div>
</div>
</div>
<!-- Main Content Split -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
<!-- Team List (Left - 2 Cols) -->
<div class="lg:col-span-2 flex flex-col gap-4">
<div class="flex items-center justify-between">
<h3 class="text-white text-lg font-bold">Your Teams</h3>
<button class="text-sm text-primary font-medium hover:underline">View All</button>
</div>
<div class="bg-card-dark border border-white/10 rounded-xl overflow-hidden">
<div class="overflow-x-auto">
<table class="w-full text-left border-collapse">
<thead>
<tr class="border-b border-white/5 bg-white/5">
<th class="p-4 text-xs font-semibold text-muted uppercase tracking-wider">Team Name</th>
<th class="p-4 text-xs font-semibold text-muted uppercase tracking-wider">Division</th>
<th class="p-4 text-xs font-semibold text-muted uppercase tracking-wider text-center">Record (W-L)</th>
<th class="p-4 text-xs font-semibold text-muted uppercase tracking-wider text-center">Form</th>
<th class="p-4 text-xs font-semibold text-muted uppercase tracking-wider text-right">Action</th>
</tr>
</thead>
<tbody class="divide-y divide-white/5">
<!-- Row 1 -->
<tr class="hover:bg-white/5 hover:shadow-lg transition-all duration-200 group cursor-pointer">
<td class="p-4">
<div class="flex items-center gap-3">
<div class="size-10 rounded bg-indigo-900 flex items-center justify-center text-white font-bold text-lg border border-white/10 group-hover:border-primary/50 group-hover:scale-110 transition-all" data-alt="Team logo for Neon Strikers">NS</div>
<div>
<p class="text-white font-medium text-sm">Neon Strikers</p>
<p class="text-xs text-muted">Captain: You</p>
</div>
</div>
</td>
<td class="p-4">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-500/20 text-purple-300">
                                                    Elite Div
                                                </span>
</td>
<td class="p-4 text-center">
<span class="text-white font-medium">12 - 2</span>
</td>
<td class="p-4">
<div class="flex justify-center gap-1">
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-danger" title="Loss"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
</div>
</td>
<td class="p-4 text-right">
<button class="p-2 hover:bg-white/10 rounded-lg text-muted hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">more_vert</span>
</button>
</td>
</tr>
<!-- Row 2 -->
<tr class="hover:bg-white/5 hover:shadow-lg transition-all duration-200 group cursor-pointer">
<td class="p-4">
<div class="flex items-center gap-3">
<div class="size-10 rounded bg-gray-800 flex items-center justify-center text-white font-bold text-lg border border-white/10 group-hover:border-primary/50 group-hover:scale-110 transition-all" data-alt="Team logo for Shadow Runners">SR</div>
<div>
<p class="text-white font-medium text-sm">Shadow Runners</p>
<p class="text-xs text-muted">Captain: J. Wick</p>
</div>
</div>
</td>
<td class="p-4">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-500/20 text-blue-300">
                                                    Pro Div
                                                </span>
</td>
<td class="p-4 text-center">
<span class="text-white font-medium">8 - 5</span>
</td>
<td class="p-4">
<div class="flex justify-center gap-1">
<span class="w-2 h-2 rounded-full bg-danger" title="Loss"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-danger" title="Loss"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-gray-500" title="Draw"></span>
</div>
</td>
<td class="p-4 text-right">
<button class="p-2 hover:bg-white/10 rounded-lg text-muted hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">more_vert</span>
</button>
</td>
</tr>
<!-- Row 3 -->
<tr class="hover:bg-white/5 transition-colors group">
<td class="p-4">
<div class="flex items-center gap-3">
<div class="size-10 rounded bg-emerald-900 flex items-center justify-center text-white font-bold text-lg border border-white/10" data-alt="Team logo for Grassroots FC">GF</div>
<div>
<p class="text-white font-medium text-sm">Grassroots FC</p>
<p class="text-xs text-muted">Captain: M. Salah</p>
</div>
</div>
</td>
<td class="p-4">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-500/20 text-green-300">
                                                    Amateur
                                                </span>
</td>
<td class="p-4 text-center">
<span class="text-white font-medium">4 - 0</span>
</td>
<td class="p-4">
<div class="flex justify-center gap-1">
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
<span class="w-2 h-2 rounded-full bg-primary" title="Win"></span>
</div>
</td>
<td class="p-4 text-right">
<button class="p-2 hover:bg-white/10 rounded-lg text-muted hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">more_vert</span>
</button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<!-- Right Column: Recent Activity & Invites -->
<div class="flex flex-col gap-6">
<!-- Recent Activity -->
<div class="flex flex-col gap-4">
<h3 class="text-white text-lg font-bold">Recent Activity</h3>
<div class="bg-card-dark border border-white/10 rounded-xl p-4 flex flex-col gap-4">
<div class="flex gap-3 items-start">
<div class="size-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 text-primary">
<span class="material-symbols-outlined text-[18px]">sports_score</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white"><span class="font-bold">Neon Strikers</span> defeated <span class="text-muted">Cyber Wolves</span></p>
<span class="text-xs text-muted mt-0.5">2 hours ago</span>
</div>
</div>
<div class="w-full h-px bg-white/5"></div>
<div class="flex gap-3 items-start">
<div class="size-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 text-blue-400">
<span class="material-symbols-outlined text-[18px]">person_add</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white"><span class="font-bold">Alex Morgan</span> joined the roster</p>
<span class="text-xs text-muted mt-0.5">5 hours ago</span>
</div>
</div>
<div class="w-full h-px bg-white/5"></div>
<div class="flex gap-3 items-start">
<div class="size-8 rounded-full bg-orange-500/20 flex items-center justify-center flex-shrink-0 text-orange-400">
<span class="material-symbols-outlined text-[18px]">edit_calendar</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white">Match vs <span class="font-bold">Titans</span> rescheduled</p>
<span class="text-xs text-muted mt-0.5">1 day ago</span>
</div>
</div>
<button class="w-full mt-2 py-2 text-xs font-medium text-muted hover:text-white transition-colors border border-dashed border-white/20 rounded-lg hover:bg-white/5">View Full History</button>
</div>
</div>
<!-- Quick Invite / Promo -->
<div class="bg-gradient-to-br from-[#1db954] to-[#14803a] rounded-xl p-6 relative overflow-hidden">
<div class="absolute -right-4 -bottom-4 opacity-30">
<span class="material-symbols-outlined text-9xl text-white">forward_to_inbox</span>
</div>
<h4 class="text-white font-bold text-lg relative z-10">Invite Players</h4>
<p class="text-white/90 text-sm mt-1 relative z-10 mb-4 max-w-[80%]">Grow your squad by inviting free agents to join your team.</p>
<button class="relative z-10 bg-white text-primary font-bold text-sm px-4 py-2 rounded-lg shadow-sm hover:bg-gray-100 transition-colors">
                                Send Invites
                            </button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
