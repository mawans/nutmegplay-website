<?php
$pageTitle = 'Dashboard';
$pageHeading = 'Dashboard Overview';
$pageDescription = '';
$currentPage = 'dashboard';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<!-- Daily Statistics -->
<section>
<div class="flex items-center justify-between mb-4">
<h3 class="text-sm font-bold text-muted uppercase tracking-wider">Daily Statistics</h3>
<span class="text-xs text-muted">Last updated: Just now</span>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
<!-- Stat Card 1 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] p-5 md:p-6 rounded-lg flex flex-col gap-1 transition-all duration-300 hover:shadow-lg hover:border-primary/30 hover:-translate-y-0.5 cursor-pointer group">
<div class="flex items-center gap-2 text-muted mb-1 group-hover:text-primary transition-colors">
<span class="material-symbols-outlined text-primary group-hover:scale-110 transition-transform" style="font-size: 20px;">sports_soccer</span>
<span class="text-sm font-medium">Total Goals</span>
</div>
<p class="text-3xl md:text-4xl font-bold tracking-tight">1,240</p>
<div class="flex items-center gap-1 text-xs text-primary mt-1">
<span class="material-symbols-outlined" style="font-size: 14px;">trending_up</span>
<span>+12% from yesterday</span>
</div>
</div>
<!-- Stat Card 2 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] p-5 md:p-6 rounded-lg flex flex-col gap-1 transition-all duration-300 hover:shadow-lg hover:border-primary/30 hover:-translate-y-0.5 cursor-pointer group">
<div class="flex items-center gap-2 text-muted mb-1 group-hover:text-primary transition-colors">
<span class="material-symbols-outlined text-primary group-hover:scale-110 transition-transform" style="font-size: 20px;">groups</span>
<span class="text-sm font-medium">Active Players</span>
</div>
<p class="text-3xl md:text-4xl font-bold tracking-tight">86</p>
<div class="flex items-center gap-1 text-xs text-muted mt-1">
<span>Current session count</span>
</div>
</div>
<!-- Stat Card 3 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] p-5 md:p-6 rounded-lg flex flex-col gap-1 transition-all duration-300 hover:shadow-lg hover:border-primary/30 hover:-translate-y-0.5 cursor-pointer group">
<div class="flex items-center gap-2 text-muted mb-1 group-hover:text-primary transition-colors">
<span class="material-symbols-outlined text-primary group-hover:scale-110 transition-transform" style="font-size: 20px;">stadium</span>
<span class="text-sm font-medium">Active Pitches</span>
</div>
<p class="text-3xl md:text-4xl font-bold tracking-tight">12</p>
<div class="flex items-center gap-1 text-xs text-muted mt-1">
<span>14 Pitches total</span>
</div>
</div>
<!-- Stat Card 4 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] p-5 md:p-6 rounded-lg flex flex-col gap-1 transition-all duration-300 hover:shadow-lg hover:border-primary/30 hover:-translate-y-0.5 cursor-pointer group">
<div class="flex items-center gap-2 text-muted mb-1 group-hover:text-primary transition-colors">
<span class="material-symbols-outlined text-primary group-hover:scale-110 transition-transform" style="font-size: 20px;">cloud_sync</span>
<span class="text-sm font-medium">Avg Latency</span>
</div>
<p class="text-3xl md:text-4xl font-bold tracking-tight">24<span class="text-base font-normal text-muted ml-1">ms</span></p>
<div class="flex items-center gap-1 text-xs text-primary mt-1">
<span class="material-symbols-outlined" style="font-size: 14px;">check_circle</span>
<span>Optimal performance</span>
</div>
</div>
</div>
</section>
<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
<!-- Live Pitch Activity (Left 2/3) -->
<section class="xl:col-span-2 flex flex-col gap-4">
<div class="flex items-center justify-between">
<h3 class="text-sm font-bold text-muted uppercase tracking-wider">Live Pitch Activity</h3>
<button class="text-primary text-sm font-medium hover:underline">View All Feeds</button>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<!-- Pitch Card 1 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg overflow-hidden flex flex-col">
<div class="relative h-48 bg-black group">
<div class="absolute inset-0 bg-cover bg-center opacity-80 group-hover:opacity-60 transition-opacity" data-alt="Futsal court interior view with green turf" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDJ4XlFVN6IB0irblJ5zxYrRuJueDApy6o5pHZdKTafzD_UuYmP56u2AjSUtgiKHYb4ybbww1xANxqyMGjgicqpjO3sfqsJSCreZZwORsAwHe3EQAolet0Kgk8G15f3ELzYmfb7hD_kvz7Cm0W6t91PRXEnVZ1GQx2G1hE3_3X_Iy6ECGo-3M75TWcZ_qUz2UyI0T1qaTdvPTn2GgUj9NdJoqEXTHD3mAQdznHls3o34GOQ3CFvd-BcLqeqPVDX1Uax8aFU5qHc75o");'></div>
<div class="absolute top-3 left-3 flex items-center gap-2 px-2 py-1 bg-black/60 backdrop-blur-sm rounded text-white text-xs font-mono border border-white/10">
<div class="size-2 rounded-full bg-red-500 animate-pulse"></div>
                                        CAM-001 [REC]
                                    </div>
<div class="absolute bottom-3 left-3 right-3 flex justify-between items-end">
<div>
<p class="text-xs font-bold text-white mb-0.5 shadow-sm">Pitch A - 5v5</p>
<p class="text-xs text-white/80 font-mono">ID: #MATCH-8291</p>
</div>
</div>
</div>
<div class="p-4 flex items-center justify-between bg-white dark:bg-card-dark">
<div class="flex items-center gap-4 flex-1">
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">RED TEAM</p>
<p class="text-3xl font-bold font-mono leading-none">5</p>
</div>
<div class="text-xl font-bold text-muted/50">:</div>
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">BLUE TEAM</p>
<p class="text-3xl font-bold font-mono leading-none">3</p>
</div>
</div>
<div class="flex flex-col items-end gap-2">
<div class="px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold font-mono">
                                            12:40
                                        </div>
<button class="text-xs text-muted hover:text-white flex items-center gap-1 transition-colors">
<span class="material-symbols-outlined" style="font-size: 16px;">restart_alt</span>
                                            Reset
                                        </button>
</div>
</div>
</div>
<!-- Pitch Card 2 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg overflow-hidden flex flex-col">
<div class="relative h-48 bg-black group">
<div class="absolute inset-0 bg-cover bg-center opacity-80 group-hover:opacity-60 transition-opacity" data-alt="Indoor soccer arena with artificial lighting" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBPjymX49R4jRiOeGp_jUaF9HjBzNWNwUy_xArCoqaUEK7KRCULJT4YTao8XckyxvXbwd6bX6WcSwWlgXTcBEV0BfXTVm-xOUO05469IF5nJceAckdE84uFMoURklqRnnu4i8q9sYuEqA3oj6Uaz6SApzeT2aTQDZhjJh-moAXHr4QNuWrgWVEgSgQpL-LWGP_vRcjzrnUREY3-o4Z83Xccdc6GNYrfZDkxXLyenkjcv_ob2w8KZ1uhGKHQMzqmGvKTI6PWEF_h3jU");'></div>
<div class="absolute top-3 left-3 flex items-center gap-2 px-2 py-1 bg-black/60 backdrop-blur-sm rounded text-white text-xs font-mono border border-white/10">
<div class="size-2 rounded-full bg-red-500 animate-pulse"></div>
                                        CAM-003 [REC]
                                    </div>
<div class="absolute bottom-3 left-3 right-3 flex justify-between items-end">
<div>
<p class="text-xs font-bold text-white mb-0.5 shadow-sm">Pitch B - 7v7</p>
<p class="text-xs text-white/80 font-mono">ID: #MATCH-8294</p>
</div>
</div>
</div>
<div class="p-4 flex items-center justify-between bg-white dark:bg-card-dark">
<div class="flex items-center gap-4 flex-1">
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">HOME</p>
<p class="text-3xl font-bold font-mono leading-none">1</p>
</div>
<div class="text-xl font-bold text-muted/50">:</div>
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">AWAY</p>
<p class="text-3xl font-bold font-mono leading-none">1</p>
</div>
</div>
<div class="flex flex-col items-end gap-2">
<div class="px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold font-mono">
                                            04:12
                                        </div>
<button class="text-xs text-muted hover:text-white flex items-center gap-1 transition-colors">
<span class="material-symbols-outlined" style="font-size: 16px;">restart_alt</span>
                                            Reset
                                        </button>
</div>
</div>
</div>
<!-- Pitch Card 3 -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg overflow-hidden flex flex-col">
<div class="relative h-48 bg-black group">
<div class="absolute inset-0 bg-cover bg-center opacity-80 group-hover:opacity-60 transition-opacity" data-alt="Close up of a soccer goal net" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDcY5By96VAXlPFZX6GS_jwv3Mnt04ToWQNf1WIUz8LXVEGHjSVibB5i6qgArBLYipw_s5JLpoJ4--viKmeaqz1LONOTQLGm_dK3dJ3UJLfwnzf6wLlHbJq8TCIlLiIN1LG44NgLHN_7UrRvWh1BcWjRLJJVYnrOWCdlUx76VyMtlpnWybOQvdP_QZGRrZSO8HfElCNetzKjfDn9TCkSUtykhWC6Yyyqjv6XKZssFBY_s7wpt3bzxT3AE5TGg88ICS5YWcAJDmay08");'></div>
<div class="absolute top-3 left-3 flex items-center gap-2 px-2 py-1 bg-black/60 backdrop-blur-sm rounded text-white text-xs font-mono border border-white/10">
<div class="size-2 rounded-full bg-red-500 animate-pulse"></div>
                                        CAM-012 [REC]
                                    </div>
<div class="absolute bottom-3 left-3 right-3 flex justify-between items-end">
<div>
<p class="text-xs font-bold text-white mb-0.5 shadow-sm">Pitch C - Training</p>
<p class="text-xs text-white/80 font-mono">ID: #MATCH-8301</p>
</div>
</div>
</div>
<div class="p-4 flex items-center justify-between bg-white dark:bg-card-dark">
<div class="flex items-center gap-4 flex-1">
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">TEAM A</p>
<p class="text-3xl font-bold font-mono leading-none">2</p>
</div>
<div class="text-xl font-bold text-muted/50">:</div>
<div class="text-center">
<p class="text-xs font-bold text-muted mb-1">TEAM B</p>
<p class="text-3xl font-bold font-mono leading-none">0</p>
</div>
</div>
<div class="flex flex-col items-end gap-2">
<div class="px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold font-mono">
                                            08:55
                                        </div>
<button class="text-xs text-muted hover:text-white flex items-center gap-1 transition-colors">
<span class="material-symbols-outlined" style="font-size: 16px;">restart_alt</span>
                                            Reset
                                        </button>
</div>
</div>
</div>
<!-- Pitch Card 4 (Waiting) -->
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg overflow-hidden flex flex-col items-center justify-center min-h-[280px]">
<div class="size-16 rounded-full bg-slate-100 dark:bg-[#264531] flex items-center justify-center text-muted mb-3">
<span class="material-symbols-outlined" style="font-size: 32px;">sports</span>
</div>
<h4 class="text-lg font-bold">Pitch D - Idle</h4>
<p class="text-sm text-muted">Waiting for match start...</p>
<button class="mt-4 px-4 py-2 bg-primary hover:bg-green-600 text-white text-sm font-bold rounded transition-colors">
                                    Assign Match
                                </button>
</div>
</div>
</section>
<!-- System Health (Right Sidebar) -->
<section class="flex flex-col gap-4">
<div class="flex items-center justify-between">
<h3 class="text-sm font-bold text-muted uppercase tracking-wider">System Health</h3>
<button class="text-muted hover:text-white">
<span class="material-symbols-outlined">refresh</span>
</button>
</div>
<div class="bg-white dark:bg-card-dark border border-slate-200 dark:border-[#264531] rounded-lg overflow-hidden flex-1 flex flex-col">
<div class="p-4 border-b border-slate-200 dark:border-[#264531] bg-slate-50 dark:bg-[#1f3429]">
<div class="flex justify-between items-center mb-2">
<span class="text-sm font-bold">Network Status</span>
<span class="text-xs font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">Online</span>
</div>
<div class="w-full bg-slate-200 dark:bg-black rounded-full h-1.5 mb-1 overflow-hidden">
<div class="bg-primary h-1.5 rounded-full" style="width: 98%"></div>
</div>
<div class="flex justify-between text-xs text-muted font-mono">
<span>Uptime: 99.9%</span>
<span>Ping: 14ms</span>
</div>
</div>
<div class="overflow-y-auto flex-1 p-2">
<table class="w-full text-left border-collapse">
<thead>
<tr>
<th class="p-2 text-xs font-bold text-muted uppercase tracking-wider">Device</th>
<th class="p-2 text-xs font-bold text-muted uppercase tracking-wider text-right">Status</th>
</tr>
</thead>
<tbody class="text-sm divide-y divide-slate-100 dark:divide-[#264531]">
<!-- Item 1 -->
<tr>
<td class="p-3">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-muted" style="font-size: 18px;">videocam</span>
<div class="flex flex-col">
<span class="font-medium leading-none">Camera 01</span>
<span class="text-xs text-muted font-mono mt-0.5">IP: 192.168.1.101</span>
</div>
</div>
</td>
<td class="p-3 text-right">
<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold">
<span class="size-1.5 rounded-full bg-primary"></span>
                                                    Online
                                                </span>
</td>
</tr>
<!-- Item 2 -->
<tr>
<td class="p-3">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-muted" style="font-size: 18px;">videocam</span>
<div class="flex flex-col">
<span class="font-medium leading-none">Camera 02</span>
<span class="text-xs text-muted font-mono mt-0.5">IP: 192.168.1.102</span>
</div>
</div>
</td>
<td class="p-3 text-right">
<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-danger/10 text-danger text-xs font-bold">
<span class="size-1.5 rounded-full bg-danger"></span>
                                                    Offline
                                                </span>
</td>
</tr>
<!-- Item 3 -->
<tr>
<td class="p-3">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-muted" style="font-size: 18px;">dns</span>
<div class="flex flex-col">
<span class="font-medium leading-none">Button Box A</span>
<span class="text-xs text-muted font-mono mt-0.5">Pitch 1 Control</span>
</div>
</div>
</td>
<td class="p-3 text-right">
<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold">
<span class="size-1.5 rounded-full bg-primary"></span>
                                                    Available
                                                </span>
</td>
</tr>
<!-- Item 4 -->
<tr>
<td class="p-3">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-muted" style="font-size: 18px;">dns</span>
<div class="flex flex-col">
<span class="font-medium leading-none">Button Box B</span>
<span class="text-xs text-muted font-mono mt-0.5">Pitch 2 Control</span>
</div>
</div>
</td>
<td class="p-3 text-right">
<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-300 text-xs font-bold">
<span class="size-1.5 rounded-full bg-slate-500 dark:bg-slate-300"></span>
                                                    Linked
                                                </span>
</td>
</tr>
<!-- Item 5 -->
<tr>
<td class="p-3">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-muted" style="font-size: 18px;">router</span>
<div class="flex flex-col">
<span class="font-medium leading-none">Main Gateway</span>
<span class="text-xs text-muted font-mono mt-0.5">GW-X900</span>
</div>
</div>
</td>
<td class="p-3 text-right">
<span class="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-primary/10 text-primary text-xs font-bold">
<span class="size-1.5 rounded-full bg-primary"></span>
                                                    Online
                                                </span>
</td>
</tr>
</tbody>
</table>
</div>
<div class="p-3 border-t border-slate-200 dark:border-[#264531] bg-slate-50 dark:bg-[#1f3429]">
<button class="w-full py-2 text-xs font-bold text-center text-primary border border-primary/30 rounded hover:bg-primary/10 transition-colors">
                                    Run System Diagnostics
                                </button>
</div>
</div>
</section>
</div>
</div>
<footer class="mt-8 text-center pb-4">
<p class="text-xs text-muted">NutmegPlay Dashboard v2.4.1 © 2024</p>
</footer>
</div>
</div>
</div>
</div>

</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
