<?php
$pageTitle = 'Upcoming Fixtures';
$pageHeading = 'Upcoming Fixtures';
$pageDescription = 'Manage matches, camera links, and team rosters';
$currentPage = 'fixtures';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<div class="flex items-center justify-between mb-6">
<div class="flex gap-2">
<button class="px-4 py-2 bg-primary text-black font-semibold rounded-lg text-sm hover:bg-primary/90 hover:shadow-lg transition-all duration-300 hover:scale-105">All Pitches</button>
<button class="px-4 py-2 bg-surface-dark border border-white/10 text-white font-medium rounded-lg text-sm hover:bg-white/5 hover:border-white/20 transition-all">Pitch 1</button>
<button class="px-4 py-2 bg-surface-dark border border-white/10 text-white font-medium rounded-lg text-sm hover:bg-white/5 hover:border-white/20 transition-all">Pitch 2</button>
</div>
<div class="flex items-center gap-2 text-sm text-muted">
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm text-primary">videocam</span> Media Ready</span>
<span class="w-px h-3 bg-white/20 mx-2"></span>
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm text-muted">videocam_off</span> Missing Clip</span>
</div>
</div>
<div class="grid grid-cols-1 xl:grid-cols-2 2xl:grid-cols-3 gap-6 pb-12">
<article class="bg-surface-dark border border-white/5 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-primary/30 transition-all duration-300">
<div class="p-5 border-b border-white/5 bg-gradient-to-r from-surface-dark to-white/5 relative">
<div class="flex justify-between items-start mb-3">
<div class="flex flex-col">
<span class="text-xs font-bold uppercase tracking-wider text-muted mb-1">Pitch 1</span>
<h3 class="text-xl font-bold text-white">Match #8842</h3>
</div>
<button class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary text-primary hover:text-black rounded-lg transition-colors text-xs font-bold border border-primary/20 hover:border-transparent group/btn">
<span class="material-symbols-outlined text-sm">qr_code_scanner</span>
                            Link Camera
                        </button>
</div>
<div class="flex justify-center -mb-8 relative z-10">
<div class="flex items-center gap-3 bg-black/80 backdrop-blur border border-white/10 px-4 py-1.5 rounded-full shadow-lg">
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-primary">82</span>
</div>
<span class="text-xs text-white/20 font-light">VS</span>
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-muted">79</span>
</div>
</div>
</div>
</div>
<div class="flex flex-1 pt-8 pb-4 px-2">
<div class="flex-1 px-2 border-r border-white/5">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-red/20">
<div class="size-2 rounded-full bg-team-red"></div>
<span class="text-xs font-bold uppercase text-team-red tracking-wider">Red Team</span>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pr-1">
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBR5DSrjAQxP-V0Kk_0DsT5g8F7uAaU0M598akSTJGNN97tnjX76PR7sCToUFyFqXNuIzGUm9eUCfDLvQXVTwea88UJDTZe8-yFGPiOT-nXE8rYHQjnTledj6g9aBMeQERfy7Om6Ny8Kg2pIuizSrnHq13ifd9H3oBhAatzonz0uN5DujD8nYb_BTMtFBLMYFGiZnaT0B8-5Z7YuM8Gh_3AFzPujTMZ9K0KT5FI5QKF0mMpR7ZqMGbf2401f8ksSWFFJJeSBegZ5g0');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">J. Smith</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAaElQT3ZqPjr9oBSiHnk7O46ae9wKeAmRPh1e2qSF4QAUgOa27YBQfpHmc5FUovb9figumsz9PrBXM0QH_h8R_z8JlBTo3QU9IsSZZUdeOPq7U_x5MBA4PUIMOEftqqE2w_0up05P6RAvipm794-NszeFO5yyX_qdJbmSvCeXx-tuINID62ukzD2pHvzLGJiExkDQmUoSj5ZC6nI6UIgBbFp1OtG5KPaWt_Ah44eUHin8Klp-_2XIBUEZTpEdRPhYWjsVq-Pnq_yw');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">M. Johnson</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player opacity-60">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDGEFcnMAiV55oRCoHrfySHygra4zaFV-ZXNfUvPPyiGIn4mm1YIA_OjUeEo1Qjv-HgkxZ5YrR3ZXMSaYodRDdEYS1IOVnAf0BLc8qvGd4eNmXylebztptS6Ea_xtSgPNxutrwB4lqy4cINyb6mgMRagvQKUMe0xzFOe-v9RLcpwDA1CxqTh84WlpHiKq2rQRgL6f_prEbpoE4qgwRdaR2_l4j0CekkidSyrG23TLKQ76qWqKnkDsyRujJVib13xi3OUfnRI_HlWlw');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">D. Brown</span>
</div>
<span class="material-symbols-outlined text-muted text-[18px]" title="Missing Media">videocam_off</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBKpHtZWwaYwBSr7gU-Hd0EByDF1xHpXdC-CVSewPfMWpPM-b8_fyi7QFE468OMz3R4adgTBk6IW8TtvCBW_99fTAR9xa-JdkuR5akxHxf5y6kFw4iMLep9Qfl1zlVVXO-BEj-xAQLlLjOdzPq4-Jl17nwEIh5KmbY7IJRrhnyZOJqc61BpZ8DlWgVpxCOk1NAjXYuF1NROJHFZRNj_7G-2Gv5AH4UipReW8NTK2zHetR0kiQp2OZS120l2JFFX2N64sdw7nJfXoEc');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">L. Wilson</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full border border-dashed border-white/20 bg-white/5 flex items-center justify-center">
<span class="material-symbols-outlined text-white/20 text-xs">person</span>
</div>
<span class="text-sm text-white/30 font-medium italic">Empty</span>
</div>
</li>
</ul>
</div>
<div class="flex-1 px-2">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-blue/20 justify-end">
<span class="text-xs font-bold uppercase text-team-blue tracking-wider">Blue Team</span>
<div class="size-2 rounded-full bg-team-blue"></div>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pl-1" dir="rtl">
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">K. Davis</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuD97oPFIDIq7ynLwndGl-kjWln8MR46wtcTOhctzLs8-BwN5whx8q8uo_SzpuiIfzwd-Pm7q7UJ-8_gO-nAr2-aFJ3v2cZAHKcGh1xUrL4pwL3qOj8eReUmMKXAywpLFXKm0C2VZrf_VCT6EOV7LpLBi6zlVKjPbuoDJywqkIO-nkT-gsGbxa9_jEyrVoKI3bfzT56FgeK2_QZTuLX2-lMpR9gkcVNzE1EwNPSv2X1H2fBStmOaSTZVOVpMpABJTzlgWdalfc3a9Hw');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">P. Garcia</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuA7LND8_Cc2r2KM2hnbszNpaZYDmVOV7uGaN3i6baLSoeM7rkwFkCOCsg_1GlocNId1VQSbK0O_7oRXZbHHhG1BLW4aYselEyrLQqGDShSh7lrD6-d221vOT4BX2UETCuJHsiUarhYEKwGve2yrgkXG83EHzTyuWH2UpRFFHeOjSYlhqNOTJaFRHpix989Qdbss-IB1uzqjBLi9TTl0VnLHtMBjkpu8j6f5x4NFxDJHlqESOjYS8IccFj2ZBUUlMCKWHZhEz7C3-Ek');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player opacity-60" dir="ltr">
<span class="material-symbols-outlined text-muted text-[18px]" title="Missing Media">videocam_off</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">R. Martinez</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuD0nIqIloYdK_sC5689WfqBGkg0YiMaOFoYANPANzkaixF-vDZzsCD4q54Q9DKLoJ1pgBm4IzVmLVsFJqf0fqFtMTLXvKpuAJ4hhpSRv5fNmgCivnTYP1GEhSaOvD-NlD0SF7E7xWhmzJIXbPB_v2S4VOgHdf6G1SJFHFIQhlQJDCBxo3adnsscTznglIQHxGZWOk4Lw1j7uzAEzMbd1lgOnyyuLb3_T3r6Gk7IDnRhoALEFjdj9yUc0x6QjN_a82wmqXQoTudPmPU');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">T. Anderson</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCJ1OTHpO7bujRYW5hQid-ZqPadxogC9swSMlXyt2AD6oA2d4F4DpytNEBg0Vhcn91gqKKXBbpMxwj0xUAlE2ibA682eKi_RmxgFq8veTRrohWZlvyqluQy7n0iz3HPmuX3cfKsdwxtORjX82vYxXplZ-Jj67cpa1NVcLDh-0mZ2UwXA0ZQvnwpFAiny4EhlQrDKtTI5wGCDYMFvcVlsMltVUOjEP0my0ldUkIaqose6mopxhlpGbQ436dAWmAM-kUYCZ87prSMcuc');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">J. Doe</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuAJPkw7NfFMaEW43V4rzvakmK1OonxYFA2iORqIcyyG0rLgcMUB5Xsoy9HDrDp0IwxOQvy-mUanjhnBqcAKvGKeexXoNo_Oy5xiT5WDef8UUX6KAofMV-g7VsIWRU_ztRh0vqB-KL_Wedr4gp3Gkpl8xAdY2B9oQeHAy7VBSMSjF8pWBIzJNNiSi3jH2oWiNNetMHlj9whUWImFbfvNeUwJ0KTg-lTNq0hPyU2V-qIADhNuj0No5WtOdjaLxRif5iiOfJ_SUxFRWqE');"></div>
</div>
</li>
</ul>
</div>
</div>
</article>
<article class="bg-surface-dark border border-white/5 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-primary/30 transition-all duration-300">
<div class="p-5 border-b border-white/5 bg-gradient-to-r from-surface-dark to-white/5 relative">
<div class="flex justify-between items-start mb-3">
<div class="flex flex-col">
<span class="text-xs font-bold uppercase tracking-wider text-muted mb-1">Pitch 2</span>
<h3 class="text-xl font-bold text-white">Match #8843</h3>
</div>
<button class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary text-primary hover:text-black rounded-lg transition-colors text-xs font-bold border border-primary/20 hover:border-transparent group/btn">
<span class="material-symbols-outlined text-sm">qr_code_scanner</span>
                            Link Camera
                        </button>
</div>
<div class="flex justify-center -mb-8 relative z-10">
<div class="flex items-center gap-3 bg-black/80 backdrop-blur border border-white/10 px-4 py-1.5 rounded-full shadow-lg">
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-muted">75</span>
</div>
<span class="text-xs text-white/20 font-light">VS</span>
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-primary">78</span>
</div>
</div>
</div>
</div>
<div class="flex flex-1 pt-8 pb-4 px-2">
<div class="flex-1 px-2 border-r border-white/5">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-red/20">
<div class="size-2 rounded-full bg-team-red"></div>
<span class="text-xs font-bold uppercase text-team-red tracking-wider">Red Team</span>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pr-1">
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCv3PQ6cYDTLIRSa9jhfNof_3CBKu6hQCEuppm4z6M-KjhfdBV-zSxglvhlC67t3MBhi2X16-7TXhZDj4clUM-PijN0LNMoDL6YAu8B21Us64jwqo8Vh60-RxR25kI8jd4voJti5ZpKqxSeLUplyW0tfzgIVGLvUPIl2GF9Ydsxn2L0os-7eCpGhAKsSEeeuX91F6to9wYb1JbMnFeBO6xlIBjhaXyonpqpLI55AkdpwoDnROg8SdEX2xM_rMQ1C-4SG4OQoMtE9-8');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">Sarah L.</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player opacity-60">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuA-4Ab2CE5zmOUlGvmbD2QP9imt5AmjeyPXJvwmJGs8w0ObHxt8q5bRVnMYxqXxC8JGO8Yma1bwOM5EzmUK4Hul7KxcfjD66LanxJqWAwftsoBloayS3pbkVHxWvwOUdVJ5NoG24hED7FAl3Q63Y2jW4Wp2w5W9HsGxGZ5TeLu-W3KYmaurf77iTGiopi6wXC-7W7CtDv1jLYCyATmAb9o9uS6UYyWltaHmVLr8x2LiOw0QwLGYNSiGERUnvhmU-ZuofzGh73ACkYU');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">B. King</span>
</div>
<span class="material-symbols-outlined text-muted text-[18px]" title="Missing Media">videocam_off</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBz0g127pWpANjRVdk60BHO2XF_vGtBxlAW5eVTJqDsfEg0sN-MOU_i9CHcAQBGEEErQbpQTpypOrX4sM05zOHlMRsVvIaXeE4AWKuOAbsn3SeHNRQYHpH62pPll0yeKNZV6pfldvWU0MJr4TsoaUASTSE9Y-i2qOnZ_kGHxdrxoZ1OHOSRdQFJwc7s3YvxMnENIQQWwtppnIN-2k2Uydxf9iO_NpKogWwuCQ36NmzbBhwkS1dPMMX0iv_FvXvr4f-ZNF5wu9mEaNo');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">K. Patel</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
</ul>
</div>
<div class="flex-1 px-2">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-blue/20 justify-end">
<span class="text-xs font-bold uppercase text-team-blue tracking-wider">Blue Team</span>
<div class="size-2 rounded-full bg-team-blue"></div>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pl-1" dir="rtl">
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">O. Brown</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuB4BfXgeEvN1QkjHxfbpxF_vI6NXATmyBEuh96tmi6_9Q2Gtzu9vBbirxMrOC_FI9dCb3LCRhTESAIVTXCX57aPQ4mqvoRoHuBK8zVzgdllgi5AiRHtLZd6KAT1ER5grfKZKApcZOmGtCsF5I4auSl8Wkv4AXY0VrSAHt4KZvr-47lERKbJeXaZTDFCQViK5DTH-IF7xY9fKtCCu0h3hTUC3n3puU9JflVfEs4xPO2BfXjEnJcSXuTAU2bj4YpWjrSXyvUyNzBO-90');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">N. Wright</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBYHis8CB4RHgjn7YXo_xL-ERglOKljF5C4jwpHuDlutLuUwWVsF4H6qrkQpuMXQ2M-X2Ok3-t-797YXnCzV52pRYZwE9rua21IBzQXNjTYAGSYR-MUDHd-DFFgUV7uCItl9cvoYOvFOaqEAuB0AkWaHdpJHbVhy1COpIOR4ASNbbdUxGrfE1WQVdetvp_theZB5DBiJp9bPUZv4fuXGnVg7HfxqHqHrnXc-UnczEt7dyLDpZgZzJP338qMoIo1zmebAEECQxXa6WM');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">G. George</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBvxIyUkCSyfsRX5-QKZc80FEiNtHHZQ2fks6p5LdHav9YaKE110nD1MmAq8dysRCkx2NdcZ90yQqPyC7BXAvGFXsytt6P8tps9zEhtIEFY9mCykQFnm7ax1ScrCEpwFWNwJmXAYPXfy12O9BlAijv5-qAaR_h1aVU-ErsZyChh_NqucoKkGRtAa4uR50SDBfiSjXGkEpolcmEapLdLfDPWNeFNlwlx8oZA3PQjzHxzXpiMNyjk-rMwtsXcsnJSz5LH1gqQoHtkqiE');"></div>
</div>
</li>
</ul>
</div>
</div>
</article>
<article class="bg-surface-dark border border-white/5 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-primary/30 transition-all duration-300">
<div class="p-5 border-b border-white/5 bg-gradient-to-r from-surface-dark to-white/5 relative">
<div class="flex justify-between items-start mb-3">
<div class="flex flex-col">
<span class="text-xs font-bold uppercase tracking-wider text-muted mb-1">Pitch 3</span>
<h3 class="text-xl font-bold text-white">Match #8844</h3>
</div>
<button class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary text-primary hover:text-black rounded-lg transition-colors text-xs font-bold border border-primary/20 hover:border-transparent group/btn">
<span class="material-symbols-outlined text-sm">qr_code_scanner</span>
                            Link Camera
                        </button>
</div>
<div class="flex justify-center -mb-8 relative z-10">
<div class="flex items-center gap-3 bg-black/80 backdrop-blur border border-white/10 px-4 py-1.5 rounded-full shadow-lg">
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-primary">85</span>
</div>
<span class="text-xs text-white/20 font-light">VS</span>
<div class="text-center">
<span class="block text-xs text-muted uppercase">Avg</span>
<span class="block text-lg font-bold text-muted">81</span>
</div>
</div>
</div>
</div>
<div class="flex flex-1 pt-8 pb-4 px-2">
<div class="flex-1 px-2 border-r border-white/5">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-red/20">
<div class="size-2 rounded-full bg-team-red"></div>
<span class="text-xs font-bold uppercase text-team-red tracking-wider">Red Team</span>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pr-1">
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuB0nzBf4g6gf4Ma6HYxnojCsdZibGLACdLqUffOEpIKhE-YsANqfv3i9nJYnNwzxZvZYJOR0FLVBg2GaGUltIF24zMghCkBVIQ78gA3pajlB2dsfxK4kKdN69rUwPqcfFAbCQUmoc7hK5Me8GA6PJdrlrMEy45ra8522LnbMtpoatsFfxg4Tj1wh6cnCYJCkLotxmTUb0e6jzshnPLKY7LYO2KY9spuqJjFLhHJ0_BoFMnyJgVT452zSGemzHLYU4LnNicUF2muBkk');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">W. Scott</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCDG-riZTWYvzSzj2pv0s00Fpl0jihRjKHwBV1UaW7psyZyF0qhhid6085Z_3EfgvwMdSgIrjO2tHcggOjzkfYtQXDhV0IcoPG7p940R2xF1XX00h2C3AELwYcLORaBJZZvnm86oj7m9EoHN6yO7yd02LPNMEwdKcANftAnozeEEbmE4XsMwcUXl6WYrO0_nm03RDBYwNVhRAkg_NMXzshsNcvnr054dZO7uOJqffnSAK5BmYRwuQjcgl2RgvbHyQ4iBiC7S82bOCc');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">E. Clark</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
<li class="flex items-center justify-between group/player">
<div class="flex items-center gap-3">
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBS04ZAeiWCREVmpczalag9e3CzYOlL5TLYNPvbgyfmeDaotZVrtWGBGUjg-n_3nF1JhDPJSXzdMd-ORQ8qKyYl4iG4incrk3tFQFtWTkm2ukDbgE586mAb1GyB5lZvG5dWJQFElpltVT71ZRKNQaYMZSvO9doF70QolwjkNKjfYwGLrOe6Lxb6h-VwcJSDggHgBGAN2Zy2rPtukalFYoFD5wR0rGvIPYzQ8L9sWQpBsYDjAk1UfhUm-bICn5JulH6ZCaEMAFbkkNo');"></div>
<span class="text-sm text-white font-medium truncate max-w-[80px]">F. Hall</span>
</div>
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
</li>
</ul>
</div>
<div class="flex-1 px-2">
<div class="flex items-center gap-2 mb-3 pb-2 border-b border-team-blue/20 justify-end">
<span class="text-xs font-bold uppercase text-team-blue tracking-wider">Blue Team</span>
<div class="size-2 rounded-full bg-team-blue"></div>
</div>
<ul class="flex flex-col gap-3 roster-scroll max-h-[280px] overflow-y-auto pl-1" dir="rtl">
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">Z. Hill</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDhOXhmgHHL8PFMGWfVpDH6y0t4jDHXr209IGiLh2R_SejCqCqbkdgJI-bwLj0bivB1ptUs-mLpXdmm7xTukCBcb2Fhtb8M7xzBtB0KA-JO7fIUmKfAzgtrQoaGMZRbOwRNRpXf10mQp0zkl_UZ4DRkWxUg7qxjh1YH26pI_kuQ283Gl7l1Fk-j1Xs1gk2U_xyUleQf4eKaKQbZYt0Ui5TpKEIGETaJbL8ZFYm-he5Z6OjAJ4lIBZeRQisyhKk8bXPw3_Eo9Lp1S9I');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player opacity-60" dir="ltr">
<span class="material-symbols-outlined text-muted text-[18px]" title="Missing Media">videocam_off</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">Y. Green</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCsOrF60iv-ADZKTvof9e04HHs5TVeE0PZUjHfVcA3o0mc6VmBmQl9vfp2KOvk-3CVZkO8n68TlTkLPNoUkHMUEc5R52Ls06q7PlCamUb_jYstnyN8O2fnMbbUt1yAk72SxYTBtQDpUgcxFH4Xmp8fUFiimxamo22kurFYehGqAHznsNKoiSqTYAlxQtdtkEf7JilaJ29oohm7VntsYnB1ipZla46G-hrPwHtX1tm4QOQCkVFRowDkEcd24RCiMvvx1f0ennSMOyHw');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player" dir="ltr">
<span class="material-symbols-outlined text-primary text-[18px]" title="Media Ready">videocam</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">X. Adams</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10 group-hover/player:ring-primary/50 transition-all" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDV64VVEORaJxWiSH19L75WPS1CqAIDuvn67rN6Lns-nbsaruc-15o57poWhJGPJEvFh5FICV6FhdqPvPUBjU7480ympzBUkFqH0vqhu6ncf30jVdvq8ZkMN8t0ffEflb1iIGGZXzusjR3BnGUISSdzPbuIGrVyWSnSDznq2TCJtDDHt5Q9ii8INl850SElK2O_zHW8_LJicnWyBZT77pAXazSW9TBMtd9z9Xid6iEovl287zq4Qm_wBVeyB8efJQBs_XuIGqoYwUw');"></div>
</div>
</li>
<li class="flex items-center justify-between group/player opacity-60" dir="ltr">
<span class="material-symbols-outlined text-muted text-[18px]" title="Missing Media">videocam_off</span>
<div class="flex items-center justify-end gap-3 text-right">
<span class="text-sm text-white font-medium truncate max-w-[80px]">W. Baker</span>
<div class="size-8 rounded-full bg-cover bg-center ring-1 ring-white/10" data-alt="Player Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuBQe2S3amYQWdTL4UR1ZfzRdFkanbIV7zswAAGgSt2VtZOJsTOUc4-PKeUer4zrAfbTdj5ybO8KjtpGD6NqZVomJmJtoIdQ-oGGAu-ZLKASZWBR6HNmMwNeSlo45s7qz6PP-RMEJ9cU5xwwrvU0uKoYOEvjCbTT2i7i8RwsOa-HNV_IpaY6TdKB5slvAiYLDp-vdipAMJT8nVsWJD_CmkoMtzCfJPCT4V4TBeB5M_sc2IWnwVt9q4WbSE4ip717ZgSa6yALNntHRv8');"></div>
</div>
</li>
</ul>
</div>
</div>
</article>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
