<?php
$pageTitle = 'Matchmaking Lobby';
$pageHeading = 'Matchmaking Lobby';
$pageDescription = 'Find your next opponent and dominate the pitch';
$currentPage = 'matchmaking';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<div class="grid grid-cols-1 xl:grid-cols-12 gap-6 lg:gap-8 items-start">
<div class="xl:col-span-8 flex flex-col gap-6">
<div class="bg-white dark:bg-card-dark rounded-xl p-5 shadow-sm border-l-4 border-primary flex flex-col sm:flex-row items-center justify-between gap-4 relative overflow-hidden group">
<div class="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
<div class="flex items-center gap-4 z-10">
<div class="relative">
<span class="material-symbols-outlined text-primary text-3xl animate-spin">sync</span>
<span class="absolute top-0 right-0 size-3 bg-primary rounded-full animate-ping"></span>
</div>
<div>
<h3 class="text-lg font-bold leading-tight">Searching for Opponent...</h3>
<p class="text-slate-500 dark:text-text-muted text-sm">Estimated wait: <span class="font-mono text-primary font-medium">00:45</span></p>
</div>
</div>
<div class="flex items-center gap-6 z-10 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 border-slate-100 dark:border-slate-800 pt-3 sm:pt-0 mt-2 sm:mt-0">
<div class="flex flex-col items-end">
<span class="text-xs uppercase font-semibold text-slate-500 dark:text-text-muted tracking-wider">Squad Avg OVR</span>
<span class="text-2xl font-bold font-display text-primary">75.2</span>
</div>
<button class="px-4 py-2 rounded-lg bg-slate-100 dark:bg-[#264531] hover:bg-slate-200 dark:hover:bg-[#2f553c] text-slate-700 dark:text-white text-sm font-medium transition-colors flex items-center gap-2">
<span class="material-symbols-outlined text-lg">close</span>
                                Cancel
                            </button>
</div>
</div>
<div class="bg-white dark:bg-card-dark rounded-xl overflow-hidden shadow-lg border border-slate-200 dark:border-[#264531]">
<div class="bg-[#122117] px-6 py-4 border-b border-[#264531] flex justify-between items-center">
<h2 class="text-white text-lg font-bold flex items-center gap-2">
<span class="material-symbols-outlined text-primary">handshake</span>
                                Match Proposal Found
                            </h2>
<span class="text-xs font-bold bg-primary/20 text-primary px-3 py-1 rounded-full uppercase tracking-widest">Ranked</span>
</div>
<div class="p-6 md:p-8 relative">
<div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center pointer-events-none">
<div class="size-14 bg-[#122017] border-4 border-primary rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(29,185,84,0.4)]">
<span class="text-xl font-black italic text-white font-display">VS</span>
</div>
</div>
<div class="flex flex-col md:flex-row gap-8 md:gap-4 relative z-0">
<div class="flex-1 flex flex-col items-center text-center p-4 md:p-6 rounded-xl bg-slate-50 dark:bg-[#16261d] border border-slate-200 dark:border-transparent transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:border-primary/30 cursor-pointer">
<div class="w-full h-32 mb-4 rounded-lg bg-center bg-cover relative overflow-hidden group/banner" data-alt="Team banner showing a green stadium atmosphere" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuB3omPHbpjo2Qr7ZUIP83LZEkjv8vWotfcnWCj6mdfZkN6oUQELehqQ3ymHt4TzEtgm6i-JuG_gOFldjCv0tiD3uer_Cf4s0UqrbBwoeaBlH3Uo6NwQLxLZgBsRFeWXygXok-xw-QBWwzjSphkyWg3atS1mScyMmaTcxZlKh1qviRbhcgOZf2MFKCF4IFgwmJH44HpiAm8zEMb7RN-PFP9iw6ltDAq0ZQS6g3gKTha4WClB77Elnw_KJwzryUDBWNj0dndkxd8iEyM");'>
<div class="absolute inset-0 bg-black/40 flex items-center justify-center">
<div class="size-20 rounded-full bg-white p-1 shadow-lg">
<img alt="FC Dreamers Logo" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDsJUo7H9Z1Io3PTQTtYD-jXrNH1T50cp0NFXjhMBObLxyBR7t4Ak0MaCYL2XAxK087r6SYBefovLNwFBcONMvOVAdJ2lIdIBIS_fRHD0DZVfg904wuhRWp_4OieKVhfg4KD4plsK-9SWk0SPwT1LopPmuZwflufBOfPJCQExtHO7w2u4zJgMy9bzROYo2v6UiKQ5VWjfucSTtjnztsh2H2uznuNVDPliip5VW3SoLvg97f1rcq-Flw_dVEqiedoXp1NOcbVIWITXs"/>
</div>
</div>
</div>
<h3 class="text-xl font-bold text-slate-900 dark:text-white">FC Dreamers</h3>
<p class="text-sm text-slate-500 dark:text-text-muted font-medium mb-4">(You)</p>
<div class="w-full grid grid-cols-2 gap-2 mt-auto">
<div class="bg-white dark:bg-[#1f3629] p-2 rounded-lg">
<p class="text-xs text-slate-500 dark:text-text-muted uppercase">OVR</p>
<p class="text-lg font-bold text-primary">75</p>
</div>
<div class="bg-white dark:bg-[#1f3629] p-2 rounded-lg">
<p class="text-xs text-slate-500 dark:text-text-muted uppercase">Rank</p>
<p class="text-lg font-bold text-white">Gold II</p>
</div>
</div>
</div>
<div class="flex-1 flex flex-col items-center text-center p-4 md:p-6 rounded-xl bg-slate-50 dark:bg-[#16261d] border border-slate-200 dark:border-transparent transition-all duration-300 hover:scale-[1.03] hover:shadow-xl hover:border-primary/30 cursor-pointer">
<div class="w-full h-32 mb-4 rounded-lg bg-center bg-cover relative overflow-hidden group/banner" data-alt="Opponent team banner showing red flares in stadium" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBmaTyAyjfIMqvyiDfan-zeYpwAvf-XiYz7SkPFNXoLBF4Pr86mgyasd7PQ8Vyq-zyMMRElVBvwuHuTpQdxO6VmPheC1ux1Q7OTfBenRdtfW2Z_0wvPf5HQiovDoI7MU7crbU1yJMUZmKibWHTM3TGTcja18unuPTqkihqJfK3No2QWsnLTLgHb5oQWY1MN4PxMBtK71lIIRGHZbkphuQVdFXrgq_LV_UAHp9twMsL-H6K22hZ2TXorzhc1rxsI4X2HFtcRsGxxAiM");'>
<div class="absolute inset-0 bg-black/40 flex items-center justify-center">
<div class="size-20 rounded-full bg-white p-1 shadow-lg">
<img alt="Red Devils Logo" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDI_kOztz9yfY35Soa7wNMrIA8L-B-v-79-tAy6IwJX3KEFun8VSjKf4rmBqW9XrqfQh3Z2RZgUWlasTcx46rAPWNNDMDXLTDwGmXKZUDutqK9ueaDrcppdZZAwhUVLSnz6YHgOOCharkEcGLev3KT-yWx4dE4xkHaSDvQZfOKYJ7KvTnL1NFFsFasfUuAE1bQc-Wy3h15t8D3y8TsOwb44oNNkqLGgn-tooHumfHsnJ4J5f3Aj6BhE5lg-5Jhov0e1eUZ2KmoXHYk"/>
</div>
</div>
</div>
<h3 class="text-xl font-bold text-slate-900 dark:text-white">Red Devils</h3>
<p class="text-sm text-slate-500 dark:text-text-muted font-medium mb-4">Opponent</p>
<div class="w-full grid grid-cols-2 gap-2 mt-auto">
<div class="bg-white dark:bg-[#1f3629] p-2 rounded-lg">
<p class="text-xs text-slate-500 dark:text-text-muted uppercase">OVR</p>
<p class="text-lg font-bold text-accent-danger">78</p>
</div>
<div class="bg-white dark:bg-[#1f3629] p-2 rounded-lg flex flex-col items-center justify-center">
<p class="text-xs text-slate-500 dark:text-text-muted uppercase mb-1">Last 3</p>
<div class="flex gap-1">
<span class="size-5 rounded bg-primary text-[10px] font-bold text-white flex items-center justify-center">W</span>
<span class="size-5 rounded bg-primary text-[10px] font-bold text-white flex items-center justify-center">W</span>
<span class="size-5 rounded bg-accent-danger text-[10px] font-bold text-white flex items-center justify-center">L</span>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="p-6 pt-2 pb-8 flex flex-col items-center gap-4 border-t border-slate-100 dark:border-[#264531] bg-slate-50 dark:bg-[#16261d]/50">
<div class="text-center mb-2">
<p class="text-slate-500 dark:text-text-muted text-sm font-medium mb-1">Auto-reject in</p>
<div class="font-mono text-2xl font-bold text-slate-900 dark:text-white flex items-center justify-center gap-2">
<span class="material-symbols-outlined">timer</span>
                                    02:59
                                </div>
</div>
<div class="flex w-full max-w-md gap-4">
<button class="flex-1 py-4 px-6 rounded-xl bg-white dark:bg-transparent border-2 border-accent-danger text-accent-danger font-bold hover:bg-accent-danger hover:text-white transition-all duration-200">
                                    Decline
                                </button>
<button class="flex-[2] py-4 px-6 rounded-xl bg-primary text-white font-bold shadow-[0_4px_14px_rgba(29,185,84,0.4)] hover:shadow-[0_6px_20px_rgba(29,185,84,0.6)] hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-2">
                                    Confirm Match
                                    <span class="material-symbols-outlined">check_circle</span>
</button>
</div>
</div>
</div>
</div>
<div class="xl:col-span-4 flex flex-col gap-6">
<div class="bg-white dark:bg-card-dark rounded-xl p-6 shadow-sm border border-slate-200 dark:border-[#264531] h-auto">
<div class="flex items-center justify-between mb-6">
<h3 class="text-lg font-bold text-slate-900 dark:text-white">Announcements</h3>
<a class="text-xs font-bold text-primary hover:underline uppercase tracking-wide" href="#">View All</a>
</div>
<div class="flex flex-col gap-4">
<div class="p-4 rounded-lg bg-slate-50 dark:bg-[#16261d] border border-slate-100 dark:border-[#264531] hover:border-primary/50 transition-colors group cursor-pointer">
<div class="flex items-start gap-3">
<div class="size-10 rounded-full bg-purple-600 flex items-center justify-center shrink-0">
<span class="material-symbols-outlined text-white text-sm">rocket_launch</span>
</div>
<div class="flex-1">
<div class="flex justify-between items-start">
<h4 class="text-sm font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">Team Galaxy</h4>
<span class="text-[10px] text-slate-400 font-medium">2m ago</span>
</div>
<p class="text-xs text-slate-500 dark:text-text-muted mt-1 leading-relaxed">
                                            Looking for a GK (OVR 80+) for tonight's Elite Cup. Mic required.
                                        </p>
<div class="flex items-center gap-2 mt-3">
<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-400">GK Needed</span>
<button class="ml-auto text-xs font-bold text-primary hover:text-white transition-colors">Apply</button>
</div>
</div>
</div>
</div>
<div class="p-4 rounded-lg bg-slate-50 dark:bg-[#16261d] border border-slate-100 dark:border-[#264531] hover:border-primary/50 transition-colors group cursor-pointer">
<div class="flex items-start gap-3">
<div class="size-10 rounded-full bg-orange-600 flex items-center justify-center shrink-0">
<span class="material-symbols-outlined text-white text-sm">emoji_events</span>
</div>
<div class="flex-1">
<div class="flex justify-between items-start">
<h4 class="text-sm font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">Street Kings</h4>
<span class="text-[10px] text-slate-400 font-medium">15m ago</span>
</div>
<p class="text-xs text-slate-500 dark:text-text-muted mt-1 leading-relaxed">
                                            Needs a Striker for the weekend tournament. Must be active daily.
                                        </p>
<div class="flex items-center gap-2 mt-3">
<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-500/20 text-orange-400">ST Needed</span>
<button class="ml-auto text-xs font-bold text-primary hover:text-white transition-colors">Apply</button>
</div>
</div>
</div>
</div>
<div class="p-4 rounded-lg bg-slate-50 dark:bg-[#16261d] border border-slate-100 dark:border-[#264531] hover:border-primary/50 transition-colors group cursor-pointer">
<div class="flex items-start gap-3">
<div class="size-10 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
<span class="material-symbols-outlined text-white text-sm">bolt</span>
</div>
<div class="flex-1">
<div class="flex justify-between items-start">
<h4 class="text-sm font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">Blue Thunder</h4>
<span class="text-[10px] text-slate-400 font-medium">1h ago</span>
</div>
<p class="text-xs text-slate-500 dark:text-text-muted mt-1 leading-relaxed">
                                            Midfielder wanted. We play possession style. Join for tryouts.
                                        </p>
<div class="flex items-center gap-2 mt-3">
<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-400">CM Needed</span>
<button class="ml-auto text-xs font-bold text-primary hover:text-white transition-colors">Apply</button>
</div>
</div>
</div>
</div>
</div>
<button class="w-full mt-4 py-3 rounded-lg border border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-text-muted text-sm font-medium hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2">
<span class="material-symbols-outlined text-lg">add_circle</span>
                            Post Recruitment Ad
                        </button>
</div>
<div class="bg-white dark:bg-card-dark rounded-xl p-6 shadow-sm border border-slate-200 dark:border-[#264531]">
<h3 class="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-text-muted mb-4">Season Top Scorers</h3>
<div class="space-y-3">
<div class="flex items-center gap-3">
<span class="text-sm font-bold text-primary w-4">1</span>
<div class="size-8 rounded-full bg-gray-200 bg-cover" data-alt="Avatar of user AlexP" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuD-geqxaFtLd3q9WGaeEfDDIRadVUFDY9dTvyXNpugp2d7TZ5WuEGPNtj11Fg7pd9rifn_i9Wwo-L_3HyNNbIbErux_YDt_CA3QJI_1-LQjcsTBYCyjmBQRCHVV9iafiVB_xxmuvvEFqTcjOWzc7WEvjqQ8DdCj8fAXQfyqW_Y-uxMTxdZmVUo35H91lneKeQWmDyYMbCr722CBSewpl7PFG5oi0KweFslbzNZS_jzsWhd3gCtNxnJ2Jei9UAy_72q6PDfrOJ_chxs");'></div>
<span class="text-sm font-medium text-slate-700 dark:text-white flex-1">AlexP_99</span>
<span class="text-sm font-bold text-slate-900 dark:text-white">42 G</span>
</div>
<div class="flex items-center gap-3">
<span class="text-sm font-bold text-slate-400 w-4">2</span>
<div class="size-8 rounded-full bg-gray-200 bg-cover" data-alt="Avatar of user StrikerZ" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAO5ix11S1rPsLN-twcvxoKWsu1zenZJHOT5jbhut2klB-QnBa72OAVg1ZIY_HXWzRku6fkJCIL67KiUY-Rs6tKX4H2GFWA1PhM3-JSYcWSNAPeP1xJsWo87BglzH-9Z6AHIhR51lZU6cGate4uZf-2nkB43nNFUTLcnu6B_s2xf5GbUroUSDfwiDgmb0HJeHg-Ff5ZOtUlIoKXVKpBJLatwkxS5qBqPgBn72VsvJ6WQo826fszyXfjbq57eU_lvqdTmWp5wWqQji8");'></div>
<span class="text-sm font-medium text-slate-700 dark:text-white flex-1">StrikerZ</span>
<span class="text-sm font-bold text-slate-900 dark:text-white">38 G</span>
</div>
<div class="flex items-center gap-3">
<span class="text-sm font-bold text-slate-400 w-4">3</span>
<div class="size-8 rounded-full bg-gray-200 bg-cover" data-alt="Avatar of user GoalMachine" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAfzWZAcFGppfqInAmYouutNWP6375DaoFvWtoOQ7TkHxuThJBmpGSWDQBEtAv8N_EWr2SLSWmOfMw5gP1ApJZQtEgTyFXG1GbXfOHJ467vO6XGYbiDIQQ5xusiy3nPIYaKusU89x1Ohkz_lwE3XRSeD7aofptlKXKIt_UerXv4FKcljGrIcjS0rdyPM0IrdWyDotOhA7_bMS274sue9NmammoFsG_PA29mGwb7VH4C79DFfWq5es5h3BerW7LIBn6R7aNMc3Qjh2c");'></div>
<span class="text-sm font-medium text-slate-700 dark:text-white flex-1">GoalMachine</span>
<span class="text-sm font-bold text-slate-900 dark:text-white">35 G</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
