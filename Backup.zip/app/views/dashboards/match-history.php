<?php
$pageTitle = 'Match History';
$pageHeading = 'Match History';
$pageDescription = 'Review your past matches and statistics';
$currentPage = 'match-history';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

            <div class="p-4 md:p-6 lg:p-8 w-full flex-1">
                <div class="w-full">
                    <div
                        class="relative w-full h-80 md:h-[400px] group overflow-hidden hover:h-[420px] transition-all duration-500 cursor-pointer">
                        <div class="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-700"
                            data-alt="Blurred stadium lights at night background"
                            style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCmiebXGZwGRb95q4F0Hy-CXHmuOuQFxL9_vQCx76tGWeuamD2JlWulE_5TluPF7LOWDtY0JCfJ07vu1Aa4y-X9YmuSeiQrXTJOlyTE6ccNiDYTG0f74dO1jhfXDZRFkrzLG8Q58ZtdsxGFHuIf3dvx51Ad6_aWxsOuaGZO_mKvmse7MryIGYqBGSJ8mnoWOVfry3_s0xbUtaXsmQTjxSkPNSFveXJYnFJnqpVx9eGIh2lpQVyU9eYIs6O0qs7WH40WXCKkpXrX-P0");'>
                        </div>
                        <div
                            class="absolute inset-0 bg-gradient-to-t from-background-dark via-background-dark/80 to-transparent">
                        </div>
                        <div class="absolute inset-0 bg-black/40"></div>
                        <div class="relative h-full flex flex-col justify-end p-8 md:p-12">
                            <div
                                class="absolute top-8 left-8 md:left-12 flex items-center gap-2 text-muted text-sm font-medium">
                                <span>Matches</span>
                                <span class="material-symbols-outlined text-xs">chevron_right</span>
                                <span class="text-white">Match #8392</span>
                            </div>
                            <div class="flex flex-col md:flex-row md:items-end justify-between gap-8">
                                <div class="flex flex-col gap-3">
                                    <div class="flex items-center gap-3 mb-1">
                                        <span
                                            class="bg-primary text-black text-xs font-bold px-2 py-1 rounded uppercase">Match
                                            #8392</span>
                                        <span class="text-muted text-sm flex items-center gap-1">
                                            <span class="material-symbols-outlined text-sm">calendar_today</span> Oct
                                            24, 2023
                                        </span>
                                        <span class="text-muted text-sm flex items-center gap-1">
                                            <span class="material-symbols-outlined text-sm">schedule</span> 90 min
                                        </span>
                                    </div>
                                    <h1
                                        class="text-6xl md:text-8xl font-black text-white tracking-tighter leading-none flex items-center gap-4">
                                        <span class="text-white">5</span>
                                        <span class="text-white/20 text-4xl md:text-6xl">-</span>
                                        <span class="text-danger">3</span>
                                    </h1>
                                    <p class="text-xl md:text-2xl font-medium text-white/90">Victory against <span
                                            class="text-danger font-bold">Red Team</span></p>
                                </div>
                                <div
                                    class="bg-surface-dark/80 backdrop-blur-md border border-white/10 p-5 rounded-xl min-w-[260px] shadow-xl animate-fade-in-up">
                                    <div class="text-muted text-xs uppercase tracking-wider font-bold mb-2">Global
                                        Ranking Impact</div>
                                    <div class="flex items-center gap-3">
                                        <span class="text-3xl font-bold text-white">#1,240</span>
                                        <div
                                            class="flex items-center text-primary bg-primary/10 px-2 py-1 rounded-full">
                                            <span
                                                class="material-symbols-outlined text-sm font-bold mr-1">arrow_upward</span>
                                            <span class="text-sm font-bold">+12</span>
                                        </div>
                                    </div>
                                    <div class="w-full bg-white/10 h-1.5 mt-3 rounded-full overflow-hidden">
                                        <div class="bg-primary h-full w-[75%] rounded-full"></div>
                                    </div>
                                    <div class="text-[10px] text-muted mt-1 text-right">Top 15%</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="px-8 md:px-12 -mt-10 relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div class="lg:col-span-1 space-y-4">
                            <div
                                class="bg-surface-dark border border-border-dark p-6 rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 hover:border-primary/30 transition-all duration-300 cursor-pointer">
                                <h3 class="text-white font-bold flex items-center gap-2 mb-4">
                                    <span class="material-symbols-outlined text-primary">analytics</span> Match Stats
                                </h3>
                                <div class="space-y-3">
                                    <div class="flex justify-between items-center p-3 bg-background-dark rounded-lg">
                                        <span class="text-muted text-sm">XP Earned</span>
                                        <span class="text-primary font-bold">+150 XP</span>
                                    </div>
                                    <div class="flex justify-between items-center p-3 bg-background-dark rounded-lg">
                                        <span class="text-muted text-sm">Possession</span>
                                        <span class="text-white font-bold">58%</span>
                                    </div>
                                    <div class="flex justify-between items-center p-3 bg-background-dark rounded-lg">
                                        <span class="text-muted text-sm">Shots on Target</span>
                                        <span class="text-white font-bold">12</span>
                                    </div>
                                </div>
                                <div class="mt-4 pt-4 border-t border-border-dark">
                                    <div class="text-xs text-muted uppercase tracking-wider mb-2">Attribute Boosts</div>
                                    <div class="flex flex-wrap gap-2">
                                        <span
                                            class="text-xs font-bold text-white bg-primary/20 border border-primary/30 px-2 py-1 rounded">+2
                                            Shooting</span>
                                        <span
                                            class="text-xs font-bold text-white bg-primary/20 border border-primary/30 px-2 py-1 rounded">+1
                                            Agility</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="lg:col-span-2">
                            <div class="bg-surface-dark border border-border-dark p-6 rounded-xl shadow-lg h-full">
                                <h3 class="text-white font-bold flex items-center gap-2 mb-4">
                                    <span class="material-symbols-outlined text-primary">sports_soccer</span> Scorers
                                </h3>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div
                                        class="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-default">
                                        <div class="relative">
                                            <div class="size-10 rounded-full bg-cover bg-center border border-white/10"
                                                data-alt="Portrait of player Alex"
                                                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCPYZ5ZL1pJd3_ndaAwLlOe7yjLJdOAL71SliZVCkK_Yeyv4V4W583Q20aTBsUl9Fy0Zi7QSW9puLAUTC5KWhEyRRTSlRBBtG7y8FvVIpIDJx48VCz59k2SSI7ln8LwZqvoAdyR_4mHBSm9ZZUjGtK-p4RDMWU-Tg6-ambxzXjbRNIe7gZP_03mgMRh3YLNBPcIrVd4kYZGMaEYmzaixDNttNgNwzGoX7DSy4sxkn3F528apzCwvPeothmMZrWHq3IHdz3d0RcOWgc");'>
                                            </div>
                                            <div
                                                class="absolute -bottom-1 -right-1 bg-primary text-black text-[10px] font-bold px-1 rounded-sm">
                                                12'</div>
                                        </div>
                                        <div>
                                            <div class="text-white font-bold text-sm">Alex M.</div>
                                            <div class="text-muted text-xs">Striker</div>
                                        </div>
                                    </div>
                                    <div
                                        class="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-default">
                                        <div class="relative">
                                            <div class="size-10 rounded-full bg-cover bg-center border border-white/10"
                                                data-alt="Portrait of player Sam"
                                                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDpBTZxiS3hv0P2IlsEwNGjAvxlEP3ng1SBN16RutFc5pm3_ZeS2ETOnjuNLWLNPAPcOjqtf2m3f0F1XBvKQuJey3jC1VlHjBAEnPQ3eML0oNsdJAIbha1z1c3225mZAFSx8bBW-eEQ5Xeymsz1QhHzXC9xRVpgfRa5YDX-ZCNbpSu-K82s5Dprb4ghMbEbQLUUIkqzmk1D4fKrVCu4zFOGqEjUJZvXk6qNDG2xoB_V_TWN2nf2DwaqK1NKH3RM9-DdOddW3fDU4B0");'>
                                            </div>
                                            <div
                                                class="absolute -bottom-1 -right-1 bg-primary text-black text-[10px] font-bold px-1 rounded-sm">
                                                45'</div>
                                        </div>
                                        <div>
                                            <div class="text-white font-bold text-sm">Sam K.</div>
                                            <div class="text-muted text-xs">Midfielder</div>
                                        </div>
                                    </div>
                                    <div
                                        class="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-default">
                                        <div class="relative">
                                            <div class="size-10 rounded-full bg-cover bg-center border border-white/10"
                                                data-alt="Portrait of player Jamie"
                                                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBs247xA0_vAUOT9PO6GRk0RmS9127mb3fXyVmwrM3aXtoGwMiyXpHnbzMJMSNMhdchJqNwmSwmit8bJ48_pm3wHnPG__fH5-us88SjrshHalU0ZyFMBM3uM1hTjHCEWU_jCVl4yQaqWwRlJikm_Yh_XD0U3EbkLXKYmeJ1sXggFNIuSxjKwrWFLVkRRr4Zrx44zuoEcGz4YuHeBfnR4AY-52OvMOhe2K5L-_MKppaSoFs2fIZACtUtMFHT4WvYMtYy4Qr4JZaegRs");'>
                                            </div>
                                            <div
                                                class="absolute -bottom-1 -right-1 bg-primary text-black text-[10px] font-bold px-1 rounded-sm">
                                                62'</div>
                                        </div>
                                        <div>
                                            <div class="text-white font-bold text-sm">Jamie L.</div>
                                            <div class="text-muted text-xs">Forward</div>
                                        </div>
                                    </div>
                                    <div
                                        class="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-default">
                                        <div class="relative">
                                            <div class="size-10 rounded-full bg-cover bg-center border border-white/10"
                                                data-alt="Portrait of player Marcus"
                                                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBy7dbyGoZ4293eV531tezfo76zLuI8hd0Si1CJchiRkq17WllLzbwM9e5gMpAspp5gCglWlFcb51uyZRbPWDKdacd1qaARcpJs0T6IbaYEZYRTGqukBK2UN_YAME86CzK4B6aWwsY4uqeMJrGTpbs53N-NL491uPhfXB0M5hhbWwb6WGU9jfA5OZFAkcWGZ8WwXw3owhxOPhqPXkidPcUGyQppiQz3JNu24DUS_-IlM0S38nHhS27930JxZqGr0ecoArUreWn0T5w");'>
                                            </div>
                                            <div
                                                class="absolute -bottom-1 -right-1 bg-primary text-black text-[10px] font-bold px-1 rounded-sm">
                                                75'</div>
                                        </div>
                                        <div>
                                            <div class="text-white font-bold text-sm">Marcus R.</div>
                                            <div class="text-muted text-xs">Striker</div>
                                        </div>
                                    </div>
                                    <div
                                        class="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-default">
                                        <div class="relative">
                                            <div class="size-10 rounded-full bg-cover bg-center border border-white/10"
                                                data-alt="Portrait of player David"
                                                style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCC5hUTr6eyFEzcf4aUi-6UaF8QcFcFMlFvEeRtuFDjXgVrtVBNiWprY6VPdj-sCRwjc3PMWXMhpM7cSWO0bTcCaqq6djWBALOAZ1rsrSZoAM2IqCQ3q6mPX9OgIbqDC7KoVj03keKjVY9k5SfBc9T-SK-EC-oqr6iSa4uu97-hgxF_LhliJbq2WvjiUUDtLsSPZRSl2o-IhWS8JDPe4TZg6kVrQgRp-tGsDmLzz5YtkwysA_DKFeoD1fFXeB4ScUpjuYjhdLlDEDY");'>
                                            </div>
                                            <div
                                                class="absolute -bottom-1 -right-1 bg-primary text-black text-[10px] font-bold px-1 rounded-sm">
                                                88'</div>
                                        </div>
                                        <div>
                                            <div class="text-white font-bold text-sm">David B.</div>
                                            <div class="text-muted text-xs">Winger</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="px-8 md:px-12 mt-8">
                        <div class="flex justify-between items-end mb-4">
                            <h2
                                class="text-white text-[22px] font-bold leading-tight tracking-[-0.015em] flex items-center gap-2">
                                <span class="material-symbols-outlined text-primary">play_circle</span> Video Highlights
                            </h2>
                            <button class="text-primary text-sm font-bold hover:text-white transition-colors">Play
                                All</button>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div
                                class="group relative rounded-xl overflow-hidden aspect-video bg-surface-dark cursor-pointer">
                                <div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                                    data-alt="Screenshot of a soccer goal celebration"
                                    style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCQOwZVACZpYQxnWBp_cSTY2CqLWtO1lw16weztcAIQbE1juNXkYoCCF4hcXiEgpmRJYsRKGaXZa19UlZ5dve9UHM6ytryiMuoY6aw9c7hWHnbazBKCrEgK6BFEFVpGhNxTGpjCjYqWq3yln10IwSyWevsDqWW5ySbaz5cLPgpojSl9hAV2CXVYSSWPT8Qv49Dh30MA0AWIO9JzT7pFHP3KwNbWXq_hsBtF7gTC0ZBIEnuHCCWJrBENYIwGonKNIVksSTKdreX__no");'>
                                </div>
                                <div class="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors">
                                </div>
                                <div
                                    class="absolute top-3 right-3 bg-black/70 backdrop-blur text-white text-xs font-bold px-2 py-1 rounded">
                                    0:04</div>
                                <div
                                    class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div
                                        class="bg-primary text-black rounded-full p-3 shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                                        <span class="material-symbols-outlined text-3xl">play_arrow</span>
                                    </div>
                                </div>
                                <div
                                    class="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                                    <p class="text-white font-bold text-sm">Goal: Alex M. (12')</p>
                                </div>
                            </div>
                            <div
                                class="group relative rounded-xl overflow-hidden aspect-video bg-surface-dark cursor-pointer">
                                <div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                                    data-alt="Screenshot of a player dribbling the ball"
                                    style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCKvC45NTyVgpWjtJlftSrNIYXThsDa-bIOc4RRVk3tDfD16Gea1kWyiHDcWdZI1RWozSVSp39MtHcRN-zY_x7gefSSA5Dp7uqevhdhKgqEVMYMr5OB87OokVf2LY6liolhNlgFtnB40ntlkANlfPJxbsIXc0aplDseRtTPoBm-1Pivmx0nUQGGQ4tkAt7gsx8y-9fXMv5erzh3YueelpckKRh2FG_8grHeVM7xZBOkkiXbhFD_5f5I8JWIcdpTv4P3OcLZUrCt1XM");'>
                                </div>
                                <div class="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors">
                                </div>
                                <div
                                    class="absolute top-3 right-3 bg-black/70 backdrop-blur text-white text-xs font-bold px-2 py-1 rounded">
                                    0:06</div>
                                <div
                                    class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div
                                        class="bg-primary text-black rounded-full p-3 shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                                        <span class="material-symbols-outlined text-3xl">play_arrow</span>
                                    </div>
                                </div>
                                <div
                                    class="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                                    <p class="text-white font-bold text-sm">Great Assist: Sam K.</p>
                                </div>
                            </div>
                            <div
                                class="group relative rounded-xl overflow-hidden aspect-video bg-surface-dark cursor-pointer">
                                <div class="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                                    data-alt="Screenshot of a goalkeeper making a save"
                                    style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCjD9UOUDaK_HQHG0KNpCqsWR1krf-8BGeq6xs8vslTXbYWp9J_E-T0s5wI6lmHsv5Io1hUQhx9rM6uSFqfMPvftF8pFJMmmzWyrWWl1OHZSbF-zWYqO2Lxu-iuD5LcCwwpQbAxnQYX9rJItK5Yko1cYKaYAXHRjS8rFXBMWZwHki3_lVe_ODAIvkE9OVB-1tur59Kvvw3cLrQMLnbjNXZUTP90Bqvx8nCgbHheFSlyglRF_TZC5t-lDvGuh3cRogpYfZNLo7Cjka8");'>
                                </div>
                                <div class="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors">
                                </div>
                                <div
                                    class="absolute top-3 right-3 bg-black/70 backdrop-blur text-white text-xs font-bold px-2 py-1 rounded">
                                    0:05</div>
                                <div
                                    class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div
                                        class="bg-primary text-black rounded-full p-3 shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                                        <span class="material-symbols-outlined text-3xl">play_arrow</span>
                                    </div>
                                </div>
                                <div
                                    class="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                                    <p class="text-white font-bold text-sm">Goal: David B. (88')</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="px-8 md:px-12 mt-8 mb-8">
                        <div class="flex justify-between items-end mb-4">
                            <h2
                                class="text-white text-[22px] font-bold leading-tight tracking-[-0.015em] flex items-center gap-2">
                                <span class="material-symbols-outlined text-primary">history</span> Match History
                            </h2>
                            <button class="text-primary text-sm font-bold hover:text-white transition-colors">View
                                All</button>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                            <div
                                class="cursor-pointer rounded-lg bg-surface-dark border border-primary/30 p-4 transition-all hover:bg-surface-dark-hover relative overflow-hidden group">
                                <div class="absolute left-0 top-0 bottom-0 w-1 bg-primary"></div>
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs font-medium text-primary">Oct 24 • #8392</span>
                                    <span
                                        class="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded uppercase tracking-wider">Victory</span>
                                </div>
                                <div class="flex justify-between items-end">
                                    <div>
                                        <div class="text-2xl font-bold text-white tracking-tight">5 - 3</div>
                                        <div class="text-xs text-muted mt-1">vs Red Team</div>
                                    </div>
                                    <span
                                        class="material-symbols-outlined text-primary group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </div>
                            </div>
                            <div
                                class="cursor-pointer rounded-lg border border-border-dark bg-surface-dark/50 hover:border-border-dark p-4 transition-all hover:bg-surface-dark-hover group">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs font-medium text-muted">Oct 20 • #8391</span>
                                    <span
                                        class="text-xs font-bold text-danger bg-danger/10 px-2 py-0.5 rounded uppercase tracking-wider">Defeat</span>
                                </div>
                                <div class="flex justify-between items-end">
                                    <div>
                                        <div
                                            class="text-xl font-bold text-muted group-hover:text-white transition-colors">
                                            1 - 2</div>
                                        <div class="text-xs text-muted mt-1">vs Blue Team</div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="cursor-pointer rounded-lg border border-border-dark bg-surface-dark/50 hover:border-border-dark p-4 transition-all hover:bg-surface-dark-hover group">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs font-medium text-muted">Oct 15 • #8385</span>
                                    <span
                                        class="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded uppercase tracking-wider">Victory</span>
                                </div>
                                <div class="flex justify-between items-end">
                                    <div>
                                        <div
                                            class="text-xl font-bold text-muted group-hover:text-white transition-colors">
                                            3 - 0</div>
                                        <div class="text-xs text-muted mt-1">vs Red Team</div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="cursor-pointer rounded-lg border border-border-dark bg-surface-dark/50 hover:border-border-dark p-4 transition-all hover:bg-surface-dark-hover group">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs font-medium text-muted">Oct 10 • #8380</span>
                                    <span
                                        class="text-xs font-bold text-gray-400 bg-gray-400/10 px-2 py-0.5 rounded uppercase tracking-wider">Draw</span>
                                </div>
                                <div class="flex justify-between items-end">
                                    <div>
                                        <div
                                            class="text-xl font-bold text-muted group-hover:text-white transition-colors">
                                            2 - 2</div>
                                        <div class="text-xs text-muted mt-1">vs Blue Team</div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="cursor-pointer rounded-lg border border-border-dark bg-surface-dark/50 hover:border-border-dark p-4 transition-all hover:bg-surface-dark-hover group">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-xs font-medium text-muted">Oct 05 • #8374</span>
                                    <span
                                        class="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded uppercase tracking-wider">Victory</span>
                                </div>
                                <div class="flex justify-between items-end">
                                    <div>
                                        <div
                                            class="text-xl font-bold text-muted group-hover:text-white transition-colors">
                                            4 - 1</div>
                                        <div class="text-xs text-muted mt-1">vs Red Team</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="h-20"></div>
                </div>
            </div>
        </div>

<?php require_once BASE_PATH . "/includes/footer.php"; ?>