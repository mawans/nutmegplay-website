<?php
$pageTitle = 'Instructor Dashboard';
$pageHeading = 'Instructor Dashboard';
$pageDescription = 'Manage training sessions and player analytics';
$currentPage = 'instructor';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<!-- Status Badge -->
<div class="flex gap-2 mb-6">
<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 hover:shadow-lg transition-all duration-200 cursor-pointer">
<span class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span> System Online
</span>
</div>

<!-- Main Grid -->
<div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
<div class="lg:col-span-8 flex flex-col gap-6">
<section class="bg-white dark:bg-surface-dark rounded-xl p-5 shadow-sm border border-slate-200 dark:border-[#264531]">
<div class="flex items-center justify-between mb-5">
<h3 class="text-xl font-bold flex items-center gap-2">
<span class="material-symbols-outlined text-primary">map</span>
                                    Pitch Map
                                </h3>
<div class="flex gap-3 text-xs font-medium">
<span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-primary"></span>Available</span>
<span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-warning"></span>Linked</span>
<span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-slate-500"></span>Offline</span>
</div>
</div>
<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
<div class="group relative aspect-[4/3] rounded-lg border-2 border-primary bg-[#122017] overflow-hidden cursor-pointer hover:shadow-[0_0_25px_rgba(29,185,84,0.4)] hover:scale-105 transition-all duration-300">
<div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1529900748604-07564a03e7a6?q=80&amp;w=500&amp;auto=format&amp;fit=crop')] bg-cover opacity-40 mix-blend-overlay" data-alt="Overhead view of a green soccer pitch"></div>
<div class="relative h-full flex flex-col justify-between p-4">
<div class="flex justify-between items-start">
<span class="bg-primary/20 text-primary border border-primary/30 px-2 py-1 rounded text-xs font-bold uppercase tracking-wider">Available</span>
<span class="material-symbols-outlined text-primary">wifi</span>
</div>
<div>
<h4 class="text-2xl font-bold text-white">Pitch 1</h4>
<p class="text-sm text-slate-300">Main Arena</p>
</div>
</div>
</div>
<div class="group relative aspect-[4/3] rounded-lg border-2 border-warning bg-[#122017] overflow-hidden cursor-pointer ring-4 ring-warning/20">
<div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1529900748604-07564a03e7a6?q=80&amp;w=500&amp;auto=format&amp;fit=crop')] bg-cover opacity-60 mix-blend-overlay" data-alt="Overhead view of a green soccer pitch"></div>
<div class="relative h-full flex flex-col justify-between p-4">
<div class="flex justify-between items-start">
<span class="bg-warning text-black px-2 py-1 rounded text-xs font-bold uppercase tracking-wider animate-pulse">Live Match</span>
<span class="material-symbols-outlined text-warning">videocam</span>
</div>
<div>
<h4 class="text-2xl font-bold text-white">Pitch 2</h4>
<div class="flex items-center gap-2 mt-1">
<span class="text-sm text-slate-300">5-a-side</span>
<span class="text-xs bg-black/50 px-1.5 py-0.5 rounded text-white font-mono">12:45</span>
</div>
</div>
</div>
</div>
<div class="group relative aspect-[4/3] rounded-lg border-2 border-slate-600 bg-slate-800 overflow-hidden cursor-not-allowed grayscale">
<div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1529900748604-07564a03e7a6?q=80&amp;w=500&amp;auto=format&amp;fit=crop')] bg-cover opacity-20" data-alt="Overhead view of a green soccer pitch"></div>
<div class="relative h-full flex flex-col justify-between p-4">
<div class="flex justify-between items-start">
<span class="bg-slate-600 text-slate-300 px-2 py-1 rounded text-xs font-bold uppercase tracking-wider">Offline</span>
<span class="material-symbols-outlined text-slate-500">wifi_off</span>
</div>
<div>
<h4 class="text-2xl font-bold text-slate-400">Pitch 3</h4>
<p class="text-sm text-slate-500">Maintenance</p>
</div>
</div>
</div>
</div>
</section>
<section class="bg-white dark:bg-surface-dark rounded-xl p-5 shadow-sm border border-slate-200 dark:border-[#264531] flex-1">
<div class="flex items-center justify-between mb-6 border-b border-slate-200 dark:border-white/10 pb-4">
<div>
<h3 class="text-xl font-bold flex items-center gap-2">
<span class="material-symbols-outlined text-primary">sports_score</span>
                                        Goal Log: Pitch 2
                                    </h3>
<p class="text-sm text-slate-500 dark:text-muted mt-1">Manual score entry override</p>
</div>
<div class="flex items-center gap-4 bg-background-light dark:bg-black/20 px-4 py-2 rounded-lg">
<span class="text-3xl font-bold font-mono text-danger">3</span>
<span class="text-sm uppercase tracking-wider font-bold text-muted">-</span>
<span class="text-3xl font-bold font-mono text-blue-500">2</span>
</div>
</div>
<div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
<div class="flex flex-col gap-3">
<button class="h-24 w-full bg-danger/10 hover:bg-danger text-danger hover:text-white border-2 border-danger rounded-xl flex items-center justify-center gap-3 transition-all active:scale-95 group">
<span class="material-symbols-outlined text-4xl group-hover:scale-110 transition-transform">add_circle</span>
<span class="text-2xl font-bold">RED GOAL</span>
</button>
<div class="flex gap-2">
<button class="flex-1 py-2 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-medium text-muted transition-colors">Undo Last</button>
<button class="flex-1 py-2 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-medium text-muted transition-colors">Assign Player</button>
</div>
</div>
<div class="flex flex-col gap-3">
<button class="h-24 w-full bg-blue-500/10 hover:bg-blue-600 text-blue-500 hover:text-white border-2 border-blue-500 rounded-xl flex items-center justify-center gap-3 transition-all active:scale-95 group">
<span class="material-symbols-outlined text-4xl group-hover:scale-110 transition-transform">add_circle</span>
<span class="text-2xl font-bold">BLUE GOAL</span>
</button>
<div class="flex gap-2">
<button class="flex-1 py-2 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-medium text-muted transition-colors">Undo Last</button>
<button class="flex-1 py-2 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-medium text-muted transition-colors">Assign Player</button>
</div>
</div>
</div>
<div class="mt-6 pt-6 border-t border-slate-200 dark:border-white/10">
<button class="w-full py-4 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 hover:border-warning hover:text-warning transition-all flex items-center justify-center gap-2">
<span class="material-symbols-outlined">help_center</span>
<span class="font-bold">Flag Uncertain / Dispute</span>
</button>
</div>
</section>
</div>
<div class="lg:col-span-4 flex flex-col gap-6">
<section class="bg-white dark:bg-surface-dark rounded-xl p-5 shadow-sm border border-slate-200 dark:border-[#264531]">
<h3 class="text-xl font-bold flex items-center gap-2 mb-4">
<span class="material-symbols-outlined text-primary">qr_code_scanner</span>
                                Camera Linker
                            </h3>
<div class="bg-black/40 rounded-lg p-6 flex flex-col items-center justify-center mb-5 border-2 border-dashed border-slate-600 relative overflow-hidden group">
<div class="absolute inset-0 bg-gradient-to-b from-transparent via-primary/10 to-transparent translate-y-[-100%] group-hover:translate-y-[100%] transition-transform duration-1000 ease-in-out"></div>
<span class="material-symbols-outlined text-6xl text-white/80 mb-2">qr_code_2</span>
<p class="text-sm font-medium text-primary">Scan QR Code</p>
<p class="text-xs text-muted mt-1">Point scanner at camera display</p>
</div>
<div class="flex items-center gap-2 mb-3">
<div class="h-px bg-slate-200 dark:bg-white/10 flex-1"></div>
<span class="text-xs text-muted uppercase font-bold">Or enter code manually</span>
<div class="h-px bg-slate-200 dark:bg-white/10 flex-1"></div>
</div>
<div class="flex gap-2">
<input class="w-full bg-slate-100 dark:bg-background-dark border-transparent focus:border-primary focus:ring-0 rounded-lg text-center font-mono text-xl tracking-[0.5em] h-12 text-slate-900 dark:text-white placeholder:tracking-normal placeholder:text-sm placeholder:font-sans" maxlength="4" placeholder="PIN" type="text"/>
<button class="bg-primary hover:bg-primary-dark text-white px-4 rounded-lg font-bold transition-colors">
                                    Link
                                </button>
</div>
</section>
<section class="bg-white dark:bg-surface-dark rounded-xl p-5 shadow-sm border border-slate-200 dark:border-[#264531] flex-1">
<div class="flex items-center justify-between mb-4">
<h3 class="text-xl font-bold flex items-center gap-2">
<span class="material-symbols-outlined text-primary">monitor_heart</span>
                                    Diagnostics
                                </h3>
<button class="text-xs text-primary font-bold hover:underline">Run All Tests</button>
</div>
<div class="space-y-4">
<div class="bg-slate-50 dark:bg-background-dark/50 rounded-lg p-3 border border-slate-100 dark:border-white/5">
<div class="flex justify-between items-start mb-2">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-sm text-muted">videocam</span>
<span class="font-medium text-sm">Cam-02 (Left)</span>
</div>
<span class="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded font-bold">ONLINE</span>
</div>
<div class="relative aspect-video bg-black rounded overflow-hidden mb-2 group">
<img class="w-full h-full object-cover opacity-60" data-alt="Dark, grainy preview of a football goal post" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCnWUXczo47fQEjdd-1LgE8Z08T2RUHcItaO1jQzlusMBbu4cJQWYA4bjkm21q8Sb3nD_UJBg8RpZz_DUGvE_pyRtvyGcrPxd27lF6tjze6ZuXs2-Kp4C5xk__akJpD6XXchTX3R8b7aMVLMsogs2sccPReE3YUdvuUg-qR7VVeXy4RKUyFg8COyJtKpU6bLAmAaHDs8BUQoiBJHiw5KWKJ53QzB3UJY2HseerbelrBRJcT7dU8FrME-KU3e_f9_ROH4Jd3EB3pFS0"/>
<button class="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
<span class="flex items-center gap-1 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-white border border-white/30">
<span class="material-symbols-outlined text-sm">play_arrow</span> Test Stream
                                            </span>
</button>
</div>
<div class="flex items-center gap-2 text-xs">
<span class="text-muted w-12">Battery</span>
<div class="h-1.5 flex-1 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
<div class="h-full bg-primary w-[85%]"></div>
</div>
<span class="text-primary font-mono">85%</span>
</div>
</div>
<div class="bg-slate-50 dark:bg-background-dark/50 rounded-lg p-3 border border-slate-100 dark:border-white/5">
<div class="flex justify-between items-start mb-2">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-sm text-muted">videocam</span>
<span class="font-medium text-sm">Cam-02 (Right)</span>
</div>
<span class="text-[10px] bg-warning/20 text-warning px-1.5 py-0.5 rounded font-bold">WEAK SIGNAL</span>
</div>
<div class="flex items-center gap-2 text-xs mt-3">
<span class="text-muted w-12">Battery</span>
<div class="h-1.5 flex-1 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
<div class="h-full bg-warning w-[32%]"></div>
</div>
<span class="text-warning font-mono">32%</span>
</div>
</div>
<div class="bg-slate-50 dark:bg-background-dark/50 rounded-lg p-3 border border-slate-100 dark:border-white/5 opacity-60">
<div class="flex justify-between items-start">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-sm text-muted">sensors</span>
<span class="font-medium text-sm">Goal Sensor</span>
</div>
<span class="text-[10px] bg-slate-500/20 text-slate-500 px-1.5 py-0.5 rounded font-bold">OFFLINE</span>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
