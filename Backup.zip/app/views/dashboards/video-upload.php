<?php
$pageTitle = 'Video Upload';
$pageHeading = 'Video Upload';
$pageDescription = 'Upload and manage your match highlights';
$currentPage = 'video-upload';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<div class="w-full overflow-x-auto pb-2">
<div class="flex gap-3 min-w-max">
<div class="flex h-9 items-center justify-center gap-x-2 rounded-lg bg-panel-dark border border-[#264531] px-4 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 cursor-pointer">
<span class="material-symbols-outlined text-primary text-[20px]">wifi</span>
<p class="text-white text-sm font-medium">Cam A1: Online</p>
</div>
<div class="flex h-9 items-center justify-center gap-x-2 rounded-lg bg-panel-dark border border-[#264531] px-4 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 cursor-pointer">
<span class="material-symbols-outlined text-primary text-[20px]">wifi</span>
<p class="text-white text-sm font-medium">Cam A2: Online</p>
</div>
<div class="flex h-9 items-center justify-center gap-x-2 rounded-lg bg-panel-dark border border-orange-500/30 px-4 shadow-sm hover:shadow-md hover:border-orange-500/50 transition-all duration-200 cursor-pointer">
<span class="material-symbols-outlined text-orange-400 text-[20px]">signal_wifi_statusbar_not_connected</span>
<p class="text-white text-sm font-medium">Cam B1: Weak Signal</p>
</div>
<div class="flex h-9 items-center justify-center gap-x-2 rounded-lg bg-panel-dark border border-danger/30 px-4 shadow-sm hover:shadow-md hover:border-danger/50 transition-all duration-200 cursor-pointer">
<span class="material-symbols-outlined text-danger text-[20px]">wifi_off</span>
<p class="text-white text-sm font-medium">Cam B2: Offline</p>
</div>
<div class="h-9 w-[1px] bg-[#264531] mx-2"></div>
<div class="flex h-9 items-center justify-center gap-x-2 rounded-lg bg-panel-dark border border-[#264531] px-4 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 cursor-pointer">
<p class="text-muted text-xs font-medium uppercase tracking-wider">Network Load: <span class="text-white">45MB/s</span></p>
</div>
</div>
</div>
<div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
<div class="lg:col-span-4 flex flex-col gap-6">
<div class="bg-panel-dark rounded-xl p-6 border border-[#264531] shadow-lg">
<div class="flex justify-between items-center mb-4">
<h3 class="text-white text-lg font-bold">New Ingest</h3>
<span class="material-symbols-outlined text-muted">upload_file</span>
</div>
<div class="flex flex-col items-center gap-4 rounded-lg border-2 border-dashed border-[#366346] bg-[#1a2e22]/50 px-6 py-10 transition-all duration-300 hover:border-primary/70 hover:bg-[#1a2e22]/70 group cursor-pointer">
<div class="bg-[#264531] p-3 rounded-full group-hover:scale-125 group-hover:bg-primary/20 transition-all duration-300">
<span class="material-symbols-outlined text-white text-3xl">cloud_upload</span>
</div>
<div class="flex flex-col items-center gap-1 text-center">
<p class="text-white text-base font-bold">Upload Raw Footage</p>
<p class="text-muted text-xs max-w-[200px]">Drag and drop MP4, MOV files or browse local drive</p>
</div>
<button class="mt-2 bg-primary hover:bg-[#1ed760] hover:shadow-xl hover:scale-105 text-background-dark text-sm font-bold py-2 px-6 rounded-lg transition-all duration-300">
                                    Browse Files
                                </button>
</div>
</div>
<div class="bg-panel-dark rounded-xl p-6 border border-[#264531] shadow-lg">
<div class="flex justify-between items-center mb-4">
<h3 class="text-white text-lg font-bold">Trimmer Tool</h3>
<span class="text-primary text-xs font-bold border border-primary px-2 py-1 rounded">4s CLIP</span>
</div>
<div class="relative w-full aspect-video bg-black rounded-lg overflow-hidden mb-4 group">
<div class="absolute inset-0 bg-cover bg-center opacity-60" data-alt="Soccer match video frame showing players on a green field" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCianZOTuMB7Z1zNrPyJM-ZWEA6oBKNUzvGd7u7Q89b3P5rOmuaaRlhAYDL8030u6J0xFQuKuPAnXfus2BvV8Y1vwe47SKwMgHSYxWCCUQXZPVcYM3upa2fo6EV_H8H6stLhqa1tlGjZkK3UdQwuBN9O5CgaKdOOFGtGfsgv6ggfXHLrArOPAaBK4FNXJgydOcyYZmQiFyzEsU3COQWMZ9qD04p84rknh3oFGJw2v75LwayXwz_I5RJmk96lrIGOF3acJi9iKsyT1o");'></div>
<div class="absolute inset-0 flex items-center justify-center">
<button class="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 hover:scale-110 transition-all duration-300">
<span class="material-symbols-outlined text-white text-4xl">play_arrow</span>
</button>
</div>
<div class="absolute bottom-2 right-2 bg-black/70 px-2 py-0.5 rounded text-xs font-mono text-white">
                                    00:14:23:05
                                </div>
</div>
<div class="flex flex-col gap-2">
<div class="flex justify-between text-xs text-muted font-mono">
<span>00:14:20</span>
<span>00:14:30</span>
</div>
<div class="relative h-12 bg-[#0d1610] rounded border border-[#264531] overflow-hidden flex items-center px-1">
<div class="absolute inset-0 flex items-center justify-center opacity-30 gap-[2px]">
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-5 bg-muted rounded-full"></div>
<div class="w-1 h-8 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
<div class="w-1 h-6 bg-muted rounded-full"></div>
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-2 bg-muted rounded-full"></div>
<div class="w-1 h-6 bg-muted rounded-full"></div>
<div class="w-1 h-8 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-5 bg-muted rounded-full"></div>
<div class="w-1 h-7 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
<div class="w-1 h-2 bg-muted rounded-full"></div>
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-5 bg-muted rounded-full"></div>
<div class="w-1 h-8 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
<div class="w-1 h-6 bg-muted rounded-full"></div>
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-2 bg-muted rounded-full"></div>
<div class="w-1 h-6 bg-muted rounded-full"></div>
<div class="w-1 h-8 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
<div class="w-1 h-3 bg-muted rounded-full"></div>
<div class="w-1 h-5 bg-muted rounded-full"></div>
<div class="w-1 h-7 bg-muted rounded-full"></div>
<div class="w-1 h-4 bg-muted rounded-full"></div>
</div>
<div class="absolute left-[30%] w-[25%] top-0 bottom-0 bg-primary/20 border-x-2 border-primary cursor-col-resize group z-10">
<div class="absolute top-1/2 -translate-y-1/2 -left-1.5 w-3 h-6 bg-primary rounded-full shadow-md"></div>
<div class="absolute top-1/2 -translate-y-1/2 -right-1.5 w-3 h-6 bg-primary rounded-full shadow-md"></div>
</div>
</div>
<div class="flex justify-between items-center mt-2">
<button class="text-xs text-muted hover:text-white underline">Reset</button>
<button class="bg-[#264531] hover:bg-primary hover:text-background-dark text-white text-xs font-bold py-1.5 px-4 rounded transition-colors">
                                        Confirm Clip
                                    </button>
</div>
</div>
</div>
</div>
<div class="lg:col-span-5 flex flex-col gap-6">
<div class="bg-panel-dark rounded-xl p-6 border border-[#264531] shadow-lg">
<h3 class="text-white text-lg font-bold mb-4">Match Context</h3>
<div class="flex flex-col gap-4">
<div class="flex flex-col gap-1.5">
<label class="text-xs font-bold text-muted uppercase tracking-wider">Select Match ID</label>
<div class="relative">
<select class="w-full bg-[#122017] border border-[#366346] text-white text-sm rounded-lg focus:ring-primary focus:border-primary block p-2.5 appearance-none">
<option>Match #8821: Tigers vs. Lions</option>
<option>Match #8822: Eagles vs. Hawks</option>
<option>Match #8823: United vs. City</option>
</select>
<div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-muted">
<span class="material-symbols-outlined">expand_more</span>
</div>
</div>
</div>
<div class="grid grid-cols-2 gap-4">
<div class="flex flex-col gap-1.5">
<label class="text-xs font-bold text-muted uppercase tracking-wider">Primary Camera</label>
<input class="bg-[#122017] border border-[#366346] text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5 placeholder-muted/80" placeholder="ID" type="text" value="CAM-A1-MAIN"/>
</div>
<div class="flex flex-col gap-1.5">
<label class="text-xs font-bold text-muted uppercase tracking-wider">Secondary Camera</label>
<input class="bg-[#122017] border border-[#366346] text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5 placeholder-muted/80" placeholder="Optional ID" type="text"/>
</div>
</div>
</div>
</div>
<div class="flex-1 bg-panel-dark rounded-xl border border-[#264531] shadow-lg flex flex-col overflow-hidden min-h-[400px]">
<div class="p-4 border-b border-[#264531] flex justify-between items-center bg-[#1a2e22]">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-primary animate-pulse">auto_awesome</span>
<h3 class="text-white text-lg font-bold">AI Highlight Feed</h3>
</div>
<span class="bg-[#264531] text-xs font-bold px-2 py-1 rounded text-white">12 Pending</span>
</div>
<div class="overflow-y-auto p-4 flex flex-col gap-3 custom-scrollbar">
<div class="flex items-center gap-4 p-3 rounded-lg bg-[#122017] border border-[#366346] hover:border-primary/50 transition-colors group">
<div class="relative w-24 h-16 bg-black rounded overflow-hidden flex-shrink-0">
<div class="absolute inset-0 bg-cover bg-center" data-alt="Blurry soccer goal post" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCR44nMG1HGIixNaYqdpkctXu2zwJ48cjnlrI98D6YErplee856ziPcq34g_3wrxr1ql12YoGtDc1qx0NpeKHRsPk_9qYex6VoOhDqLInfYcQN6IcaIraERp8zhqcXVs9v8ILo_DPSgUmfP2kCf23fH0fLPXQxs-BQhpTvCMg-ancqUkeiw51muvpix0ngN_3sRKQmPQjqf8r58lS61mlsDK_7CKq0yscGYo-LfH6ZSlUwqqGVCoFlfTHH6lKU3LWUH7bXnF79MCUA");'></div>
</div>
<div class="flex-1 min-w-0">
<div class="flex items-center gap-2 mb-1">
<span class="bg-primary/20 text-primary text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">Goal</span>
<span class="text-muted text-xs">14:22</span>
</div>
<p class="text-sm font-medium text-white truncate">Player #10 Long Shot</p>
<p class="text-xs text-muted truncate">Confidence: 98%</p>
</div>
<div class="flex gap-2">
<button class="size-8 rounded-full bg-[#264531] text-muted hover:bg-danger hover:text-white flex items-center justify-center transition-colors">
<span class="material-symbols-outlined text-sm">close</span>
</button>
<button class="size-8 rounded-full bg-primary text-background-dark hover:bg-white hover:scale-105 flex items-center justify-center transition-all shadow-lg shadow-primary/20">
<span class="material-symbols-outlined text-sm font-bold">check</span>
</button>
</div>
</div>
<div class="flex items-center gap-4 p-3 rounded-lg bg-[#122017] border border-[#366346] hover:border-primary/50 transition-colors group">
<div class="relative w-24 h-16 bg-black rounded overflow-hidden flex-shrink-0">
<div class="absolute inset-0 bg-cover bg-center" data-alt="Referee holding a yellow card" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuCiUKCDmex4f2Vbrlms-q-2mse1cOebYvqgjOyoLHQdj432tbQa2HYMSLW_w16BhbmflvINQsxr6MHo-P9nV3hfuWEt1G8I76KbP_pt6FrUHRBfNGuwHajAOROdePEaW-ltq5MLHmeYyKxsPW2USNLnJa7SZSNm-i6BQjPxlImaUU9QWg9e-kXQzPpJsBflTfFwADKcPBb6QUKhP1A5daLY_yAuxuJdO8-q4DzzocRNb_fmy2BAZW43HxLRhG3usmHAQlIzZTOg520");'></div>
</div>
<div class="flex-1 min-w-0">
<div class="flex items-center gap-2 mb-1">
<span class="bg-yellow-500/20 text-yellow-500 text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">Foul</span>
<span class="text-muted text-xs">22:05</span>
</div>
<p class="text-sm font-medium text-white truncate">Possible Yellow Card</p>
<p class="text-xs text-muted truncate">Confidence: 85%</p>
</div>
<div class="flex gap-2">
<button class="size-8 rounded-full bg-[#264531] text-muted hover:bg-danger hover:text-white flex items-center justify-center transition-colors">
<span class="material-symbols-outlined text-sm">close</span>
</button>
<button class="size-8 rounded-full bg-primary text-background-dark hover:bg-white hover:scale-105 flex items-center justify-center transition-all shadow-lg shadow-primary/20">
<span class="material-symbols-outlined text-sm font-bold">check</span>
</button>
</div>
</div>
<div class="flex items-center gap-4 p-3 rounded-lg bg-[#122017] border border-[#366346] hover:border-primary/50 transition-colors group">
<div class="relative w-24 h-16 bg-black rounded overflow-hidden flex-shrink-0">
<div class="absolute inset-0 bg-cover bg-center" data-alt="Goalkeeper diving for a ball" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBh4ozCjh7F98QoXJojv-gAOVNEjyFm48fYA5aQTXlKNHTaU8aKONOjkglKPRq7s0oU3JkhNG-XzVvZ1uroNdlIOgyN_2JwmVrrWr4DH0hi4U6VrR1dtZuC2CA2f1ZQv2-1k41uFtNJamzg37wSnIMiO3sl9OyrpRQA3VcNKWn-GoBBN4K7DJ8IfZdDFv62NJwJyGf6PccxGvBHEOO6NQ-X9lZX8pg83zm5Vz0jm2xxz6yan7vvCP8R2ks2yjJKc_hazGhtVqjOVeA");'></div>
</div>
<div class="flex-1 min-w-0">
<div class="flex items-center gap-2 mb-1">
<span class="bg-blue-500/20 text-blue-400 text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">Save</span>
<span class="text-muted text-xs">31:18</span>
</div>
<p class="text-sm font-medium text-white truncate">Goalkeeper Dive</p>
<p class="text-xs text-muted truncate">Confidence: 72%</p>
</div>
<div class="flex gap-2">
<button class="size-8 rounded-full bg-[#264531] text-muted hover:bg-danger hover:text-white flex items-center justify-center transition-colors">
<span class="material-symbols-outlined text-sm">close</span>
</button>
<button class="size-8 rounded-full bg-primary text-background-dark hover:bg-white hover:scale-105 flex items-center justify-center transition-all shadow-lg shadow-primary/20">
<span class="material-symbols-outlined text-sm font-bold">check</span>
</button>
</div>
</div>
<div class="text-center mt-2">
<button class="text-xs text-muted hover:text-white flex items-center justify-center gap-1 mx-auto">
<span>Load more events</span>
<span class="material-symbols-outlined text-sm">expand_more</span>
</button>
</div>
</div>
</div>
</div>
<div class="lg:col-span-3 flex flex-col gap-6">
<div class="bg-panel-dark rounded-xl p-6 border border-[#264531] shadow-lg">
<h3 class="text-white text-lg font-bold mb-4">Storage Health</h3>
<div class="flex flex-col gap-1 mb-6">
<div class="flex justify-between text-sm mb-1">
<span class="text-white font-medium">78% Used</span>
<span class="text-muted">7.8TB / 10TB</span>
</div>
<div class="w-full bg-[#122017] rounded-full h-2.5 overflow-hidden">
<div class="bg-gradient-to-r from-primary to-emerald-600 h-2.5 rounded-full" style="width: 78%"></div>
</div>
</div>
<div class="flex flex-col gap-4">
<div class="flex justify-between items-center border-b border-[#264531] pb-2">
<span class="text-xs font-bold text-muted uppercase tracking-wider">Auto-Cleanup</span>
<span class="text-[10px] bg-[#264531] px-2 py-0.5 rounded text-muted">Next 24h</span>
</div>
<ul class="flex flex-col gap-3">
<li class="flex items-center justify-between group cursor-pointer">
<div class="flex items-center gap-3">
<div class="size-8 rounded bg-[#122017] border border-[#264531] flex items-center justify-center text-muted">
<span class="material-symbols-outlined text-sm">movie</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white group-hover:text-primary transition-colors">match_day_01_raw.mp4</p>
<p class="text-[10px] text-muted">45.2 GB</p>
</div>
</div>
<div class="flex items-center gap-1 text-orange-400">
<span class="material-symbols-outlined text-xs">timer</span>
<span class="text-xs font-bold">2h 15m</span>
</div>
</li>
<li class="flex items-center justify-between group cursor-pointer">
<div class="flex items-center gap-3">
<div class="size-8 rounded bg-[#122017] border border-[#264531] flex items-center justify-center text-muted">
<span class="material-symbols-outlined text-sm">movie</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white group-hover:text-primary transition-colors">training_sess_b.mov</p>
<p class="text-[10px] text-muted">12.8 GB</p>
</div>
</div>
<div class="flex items-center gap-1 text-orange-400">
<span class="material-symbols-outlined text-xs">timer</span>
<span class="text-xs font-bold">5h 30m</span>
</div>
</li>
<li class="flex items-center justify-between group cursor-pointer">
<div class="flex items-center gap-3">
<div class="size-8 rounded bg-[#122017] border border-[#264531] flex items-center justify-center text-muted">
<span class="material-symbols-outlined text-sm">movie</span>
</div>
<div class="flex flex-col">
<p class="text-sm text-white group-hover:text-primary transition-colors">cam_02_backup.mp4</p>
<p class="text-[10px] text-muted">8.1 GB</p>
</div>
</div>
<div class="flex items-center gap-1 text-muted">
<span class="material-symbols-outlined text-xs">timer</span>
<span class="text-xs font-bold">1d 4h</span>
</div>
</li>
</ul>
<button class="w-full mt-2 border border-[#264531] text-muted text-xs font-medium py-2 rounded hover:bg-[#264531] hover:text-white transition-colors">
                                    Manage Retention Policy
                                </button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
