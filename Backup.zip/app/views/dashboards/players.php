<?php
$pageTitle = 'Players';
$pageHeading = 'Players Dashboard';
$pageDescription = 'Manage your player stats and season progress';
$currentPage = 'players';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<!-- Stats Grid -->
<section class="grid grid-cols-2 gap-4 md:grid-cols-4 mb-6">
<div class="flex flex-col items-start gap-2 rounded-xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm hover:shadow-md transition-shadow dark:border-white/10 dark:bg-surface-dark hover:border-primary/30 dark:hover:border-primary/30">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[20px]">sports_soccer</span>
<span class="text-sm font-medium text-muted">Matches</span>
</div>
<p class="text-2xl md:text-3xl font-bold tracking-tight dark:text-white">24</p>
<div class="flex items-center gap-1 text-xs text-primary mt-1">
<span class="material-symbols-outlined text-[14px]">trending_up</span>
<span>+3 this week</span>
</div>
</div>
<div class="flex flex-col items-start gap-2 rounded-xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm hover:shadow-md transition-shadow dark:border-white/10 dark:bg-surface-dark hover:border-primary/30 dark:hover:border-primary/30">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[20px]">scoreboard</span>
<span class="text-sm font-medium text-muted">Goals</span>
</div>
<p class="text-2xl md:text-3xl font-bold tracking-tight dark:text-white">18</p>
<div class="flex items-center gap-1 text-xs text-primary mt-1">
<span class="material-symbols-outlined text-[14px]">trending_up</span>
<span>+5 this month</span>
</div>
</div>
<div class="flex flex-col items-start gap-2 rounded-xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm hover:shadow-md transition-shadow dark:border-white/10 dark:bg-surface-dark hover:border-primary/30 dark:hover:border-primary/30">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[20px]">handshake</span>
<span class="text-sm font-medium text-muted">Assists</span>
</div>
<p class="text-2xl md:text-3xl font-bold tracking-tight dark:text-white">7</p>
<div class="flex items-center gap-1 text-xs text-muted mt-1">
<span class="material-symbols-outlined text-[14px]">trending_flat</span>
<span>Same as last</span>
</div>
</div>
<div class="flex flex-col items-start gap-2 rounded-xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm hover:shadow-md transition-shadow dark:border-white/10 dark:bg-surface-dark hover:border-primary/30 dark:hover:border-primary/30">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-yellow-500 text-[20px]">star</span>
<span class="text-sm font-medium text-muted">MVP Awards</span>
</div>
<p class="text-2xl md:text-3xl font-bold tracking-tight dark:text-white">3</p>
<div class="flex items-center gap-1 text-xs text-primary mt-1">
<span class="material-symbols-outlined text-[14px]">trending_up</span>
<span>+1 recent</span>
</div>
</div>
</section>
<section class="flex flex-col gap-6 lg:flex-row mb-6">
<div class="flex flex-1 flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm dark:border-white/10 dark:bg-surface-dark">
<div class="mb-6 flex w-full items-center justify-between px-4">
<h3 class="text-xl font-bold dark:text-white">Season Card</h3>
<button class="flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 transition hover:bg-slate-200 dark:bg-white/10 dark:text-white dark:hover:bg-white/20">
<span class="material-symbols-outlined text-[16px]">edit</span> Edit Style
                        </button>
</div>
<div class="relative flex h-[420px] w-[280px] flex-col overflow-hidden rounded-t-[2rem] rounded-b-[2.5rem] bg-gradient-to-br from-[#E3C378] via-[#FDF3C8] to-[#C99C41] p-1 shadow-2xl ring-4 ring-[#C99C41]/30 transition-transform hover:scale-105">
<div class="relative flex h-full w-full flex-col items-center border border-[#967425] bg-gradient-to-b from-black/5 to-black/30 p-4">
<div class="absolute left-5 top-5 flex flex-col items-center">
<span class="text-4xl font-black text-[#3a2c0f]">88</span>
<span class="text-lg font-bold text-[#3a2c0f]">ST</span>
<div class="mt-2 h-[1px] w-8 bg-[#3a2c0f]/30"></div>
<div class="mt-2 flex h-6 w-8 items-center justify-center overflow-hidden rounded bg-white shadow-sm" data-alt="England Flag">
<div class="relative h-full w-full bg-white">
<div class="absolute left-[45%] h-full w-[10%] bg-[#CE1124]"></div>
<div class="absolute top-[45%] h-[10%] w-full bg-[#CE1124]"></div>
</div>
</div>
<div class="mt-2 flex h-8 w-8 items-center justify-center rounded-full bg-white p-1 shadow-sm" data-alt="Club Logo">
<span class="material-symbols-outlined text-black">security</span>
</div>
</div>
<div class="mt-4 h-48 w-48 overflow-hidden">
<img alt="Player Action Shot" class="h-full w-full object-cover object-top drop-shadow-xl" src="https://lh3.googleusercontent.com/aida-public/AB6AXuASDqwkC0CEG1dVZGgjK7e2Z2-xdbY6LZIT0gOkW1tvztRlE_Q6dLEY9tU-4NiYtQjTzSmaeRSeMNuDbvO55VDx-tBxcCqr2poQnLGnlT752rPSwH7XuZU74rYl5eZ3XRowuaGtuEHRHpYfSMXOLEBJaZW3TgZOKSfCh31SYBgEWXM3CP-q2dTibnNtYo5R7js6RwGjonJJfG0s_g-KHTr24gF6jB30IBnbt3lj6GZWhAWYwdedJ32nkoIT-AtPhhlOuPwT2AO3onQ" style="-webkit-mask-image: linear-gradient(to bottom, black 80%, transparent 100%); mask-image: linear-gradient(to bottom, black 80%, transparent 100%);"/>
</div>
<div class="relative z-10 -mt-2 w-full text-center">
<h2 class="font-display text-2xl font-black uppercase tracking-wider text-[#3a2c0f]">Hunter</h2>
</div>
<div class="mt-3 grid w-full grid-cols-2 gap-x-2 gap-y-1 px-2">
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">90</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">PAC</span>
</div>
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">88</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">DRI</span>
</div>
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">86</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">SHO</span>
</div>
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">45</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">DEF</span>
</div>
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">82</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">PAS</span>
</div>
<div class="flex items-center justify-center gap-1">
<span class="font-black text-[#3a2c0f]">78</span>
<span class="text-xs font-bold text-[#3a2c0f] opacity-80">PHY</span>
</div>
</div>
<div class="mt-4 h-1 w-12 rounded-full bg-[#3a2c0f]/20"></div>
</div>
<div class="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/20 to-white/0 opacity-50"></div>
</div>
<div class="mt-6 md:mt-8 flex flex-col sm:flex-row gap-3">
<button class="flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 font-bold text-white shadow-lg shadow-primary/20 transition hover:bg-green-600 hover:shadow-xl hover:shadow-primary/30 active:scale-95">
<span class="material-symbols-outlined">share</span>
Share Card
</button>
<button class="flex items-center justify-center gap-2 rounded-lg border-2 border-slate-300 bg-transparent px-6 py-3 font-bold text-slate-700 transition hover:bg-slate-50 hover:border-slate-400 dark:border-white/20 dark:text-white dark:hover:bg-white/5 dark:hover:border-white/30 active:scale-95">
<span class="material-symbols-outlined">download</span>
Download
</button>
</div>
</div>
<div class="flex flex-1 flex-col gap-6">
<div class="flex flex-1 flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-white/10 dark:bg-surface-dark">
<div class="mb-6 flex items-center justify-between">
<h3 class="text-lg md:text-xl font-bold dark:text-white">Attribute Analysis</h3>
<span class="text-xs font-medium text-muted bg-slate-100 dark:bg-white/10 px-2 py-1 rounded">Overall: 82</span>
</div>
<div class="flex flex-col gap-5">
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Pace (PAC)</span>
<span class="font-bold dark:text-white">90</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-primary" style="width: 90%"></div>
</div>
</div>
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Shooting (SHO)</span>
<span class="font-bold dark:text-white">86</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-primary" style="width: 86%"></div>
</div>
</div>
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Passing (PAS)</span>
<span class="font-bold dark:text-white">82</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-primary" style="width: 82%"></div>
</div>
</div>
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Dribbling (DRI)</span>
<span class="font-bold dark:text-white">88</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-primary" style="width: 88%"></div>
</div>
</div>
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Defense (DEF)</span>
<span class="font-bold text-yellow-500">45</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-yellow-500" style="width: 45%"></div>
</div>
</div>
<div class="flex flex-col gap-1">
<div class="flex justify-between text-sm">
<span class="font-medium text-muted">Physical (PHY)</span>
<span class="font-bold dark:text-white">78</span>
</div>
<div class="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="h-full rounded-full bg-yellow-500" style="width: 78%"></div>
</div>
</div>
</div>
<div class="mt-8 flex justify-end">
<button class="text-sm font-medium text-primary hover:text-green-400">View detailed breakdown →</button>
</div>
</div>
<div class="grid grid-cols-2 gap-4">
<div class="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-surface-dark">
<p class="text-xs font-medium uppercase text-muted">Weak Foot</p>
<div class="mt-2 flex gap-1">
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-slate-600 text-sm">star</span>
</div>
</div>
<div class="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-surface-dark">
<p class="text-xs font-medium uppercase text-muted">Skill Moves</p>
<div class="mt-2 flex gap-1">
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
<span class="material-symbols-outlined text-yellow-500 text-sm">star</span>
</div>
</div>
</div>
</div>
</section>
<section class="grid grid-cols-1 gap-6 lg:grid-cols-2">
<div class="flex flex-col rounded-2xl border border-slate-200 bg-white p-6 dark:border-white/10 dark:bg-surface-dark">
<div class="mb-6 flex items-center justify-between">
<h3 class="text-xl font-bold dark:text-white">Progression Tracking</h3>
<span class="rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">Season 5</span>
</div>
<div class="flex flex-col gap-6">
<div class="flex flex-col gap-2">
<div class="flex justify-between items-end">
<div>
<span class="text-xs font-bold uppercase text-muted">Current Level</span>
<div class="text-3xl font-black text-slate-900 dark:text-white">24</div>
</div>
<div class="text-right">
<span class="text-sm font-bold text-primary">1,250 XP</span>
<span class="text-xs font-medium text-muted"> / 2,000 XP</span>
</div>
</div>
<div class="relative h-4 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
<div class="absolute top-0 left-0 h-full rounded-full bg-primary transition-all duration-500" style="width: 62.5%">
<div class="absolute inset-0 bg-white/20" style="background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent); background-size: 1rem 1rem;"></div>
</div>
</div>
<p class="text-xs text-muted">750 XP needed for next reward</p>
</div>
<div>
<h4 class="mb-3 text-sm font-bold text-slate-900 dark:text-white">Recent Improvements</h4>
<div class="grid grid-cols-2 gap-3">
<div class="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50 p-3 dark:border-white/5 dark:bg-white/5">
<div class="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 text-primary dark:bg-primary/20">
<span class="material-symbols-outlined">speed</span>
</div>
<div>
<p class="text-sm font-bold dark:text-white">Sprint Speed</p>
<p class="text-xs font-bold text-primary">+2 this month</p>
</div>
</div>
<div class="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50 p-3 dark:border-white/5 dark:bg-white/5">
<div class="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 text-primary dark:bg-primary/20">
<span class="material-symbols-outlined">fitness_center</span>
</div>
<div>
<p class="text-sm font-bold dark:text-white">Strength</p>
<p class="text-xs font-bold text-primary">+1 this month</p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="flex flex-col rounded-2xl border border-slate-200 bg-white p-6 dark:border-white/10 dark:bg-surface-dark">
<div class="mb-6 flex items-center justify-between">
<h3 class="text-xl font-bold dark:text-white">Personalized Media</h3>
<button class="text-sm font-medium text-primary hover:text-green-400">Settings</button>
</div>
<div class="flex flex-1 flex-col gap-4">
<div class="relative flex-1 overflow-hidden rounded-xl bg-slate-900">
<div class="absolute inset-0 opacity-50" style="background: repeating-linear-gradient(90deg, #1DB954 0px, #1DB954 2px, transparent 2px, transparent 6px); mask-image: linear-gradient(to bottom, transparent, black, transparent);"></div>
<div class="relative z-10 flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
<div class="rounded-full bg-white/10 p-4 backdrop-blur-sm">
<span class="material-symbols-outlined text-4xl text-white">campaign</span>
</div>
<h4 class="text-lg font-bold text-white">"Samba De Janeiro"</h4>
<p class="text-xs font-medium text-white/70">Custom Celebration • 4.0s</p>
</div>
<button class="absolute bottom-4 right-4 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-white shadow-lg transition hover:scale-110">
<span class="material-symbols-outlined">play_arrow</span>
</button>
</div>
<div class="grid grid-cols-2 gap-3">
<button class="flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:bg-white/10">
<span class="material-symbols-outlined text-lg">upload_file</span>
                                Upload
                            </button>
<button class="flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:bg-white/10">
<span class="material-symbols-outlined text-lg">library_music</span>
                                Library
                            </button>
</div>
</div>
</div>
</section>
<section class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-white/10 dark:bg-surface-dark mb-6">
<div class="mb-4 flex items-center justify-between">
<h3 class="text-lg md:text-xl font-bold dark:text-white">Recent Matches</h3>
<a class="text-sm font-medium text-primary hover:text-green-600 transition-colors" href="#">See all →</a>
</div>
<div class="overflow-x-auto -mx-6 px-6">
<table class="w-full text-left">
<thead class="border-b border-slate-200 text-xs uppercase text-muted dark:border-white/10">
<tr>
<th class="py-3 font-medium">Opponent</th>
<th class="py-3 font-medium">Result</th>
<th class="py-3 font-medium">Rating</th>
<th class="py-3 font-medium text-right">Date</th>
</tr>
</thead>
<tbody class="text-sm dark:text-white">
<tr class="border-b border-slate-100 last:border-0 dark:border-white/5">
<td class="py-3">
<div class="flex items-center gap-3">
<div class="h-8 w-8 rounded-full bg-indigo-500 flex items-center justify-center text-xs font-bold text-white">R</div>
<span>Real Madrid FC</span>
</div>
</td>
<td class="py-3"><span class="rounded bg-primary/20 px-2 py-1 font-bold text-primary">W 3-1</span></td>
<td class="py-3"><span class="font-bold text-primary">9.2</span></td>
<td class="py-3 text-right text-muted">Oct 24</td>
</tr>
<tr class="border-b border-slate-100 last:border-0 dark:border-white/5">
<td class="py-3">
<div class="flex items-center gap-3">
<div class="h-8 w-8 rounded-full bg-red-600 flex items-center justify-center text-xs font-bold text-white">L</div>
<span>Liverpool FC</span>
</div>
</td>
<td class="py-3"><span class="rounded bg-slate-200 px-2 py-1 font-bold text-slate-600 dark:bg-white/10 dark:text-white">D 2-2</span></td>
<td class="py-3"><span class="font-bold text-yellow-500">7.5</span></td>
<td class="py-3 text-right text-muted">Oct 18</td>
</tr>
<tr class="border-b border-slate-100 last:border-0 dark:border-white/5">
<td class="py-3">
<div class="flex items-center gap-3">
<div class="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-xs font-bold text-white">C</div>
<span>Chelsea FC</span>
</div>
</td>
<td class="py-3"><span class="rounded bg-danger/20 px-2 py-1 font-bold text-danger">L 0-1</span></td>
<td class="py-3"><span class="font-bold text-danger">5.8</span></td>
<td class="py-3 text-right text-muted">Oct 12</td>
</tr>
</tbody>
</table>
</div>
</section>
<footer class="mt-8 pb-8 text-center text-xs md:text-sm text-muted">
© 2026 NutmegPlay. All rights reserved.
</footer>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
