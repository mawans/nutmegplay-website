<?php
$pageTitle = 'Football Challenges';
$pageHeading = 'Challenges Dashboard';
$pageDescription = 'Complete challenges to earn XP and unlock badges';
$currentPage = 'challenges';

require_once BASE_PATH . '/includes/header.php';
require_once BASE_PATH . '/includes/sidenav.php';
?>

<div class="flex flex-col flex-1 w-full">
<?php require_once BASE_PATH . '/includes/topnav.php'; ?>

<div id="main-content" class="flex flex-col flex-1 overflow-y-auto bg-background-light dark:bg-background-dark ml-0 md:ml-64 transition-all duration-300">

<div class="p-4 md:p-6 lg:p-8 w-full flex-1">
<div class="w-full">
<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
<!-- LEFT COLUMN (Main Feed) -->
<div class="xl:col-span-2 flex flex-col gap-8">
<!-- 1. Challenge of the Week (Hero Card) -->
<section class="relative overflow-hidden rounded-2xl bg-surface-dark shadow-xl group hover:shadow-2xl transition-all duration-500 cursor-pointer">
<div class="absolute inset-0 z-0 opacity-40 mix-blend-overlay group-hover:opacity-50 transition-opacity duration-500">
<img alt="Football player sprinting on a field" class="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCTzUH-Grw59u0hGPbF4miMUljBflf2GZoEn0ipJZENMjh7r2qypPosyma0VDFxLRtT0M2EiQ6NwiowxV5iqTS-Z7D7bT-2oDj_FfbMboP9CiVLExBgMydCat0c0NXiytukb9gF8X6K_HILOqlu12W0Z-yLyOZnHJr70EreBzWkL1-SjAbWa_OPD2LP98rdPQCZlypJESVr26wJ_hHO2zmqpR9Ytl-jqEDJW__WCSwrrvyxW15716kWnIhUy7swtgrtrbMcQg7SJwY"/>
</div>
<div class="relative z-10 flex flex-col justify-between p-8 md:flex-row md:items-end min-h-[320px] bg-gradient-to-r from-background-dark via-background-dark/80 to-transparent">
<div class="flex flex-col items-start gap-4 max-w-lg">
<div class="flex items-center gap-2">
<span class="inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-bold uppercase text-background-dark">
<span class="material-symbols-outlined text-sm">bolt</span>
                                        Active Challenge
                                    </span>
<span class="text-xs font-medium text-muted uppercase tracking-wider">Ends in 2 Days</span>
</div>
<h1 class="text-4xl font-black text-white leading-tight tracking-tight">Sprinter of the Week</h1>
<p class="text-lg text-gray-300">Hit a top speed of <span class="text-primary font-bold">32km/h</span> in a single session to unlock the Speedster Badge.</p>
<div class="mt-4 flex items-center gap-4">
<button class="flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-background-dark hover:bg-green-400 hover:shadow-xl hover:scale-105 transition-all duration-300 shadow-[0_0_20px_rgba(29,185,84,0.3)] hover:shadow-[0_0_30px_rgba(29,185,84,0.5)] group/btn">
                                        Start Challenge
                                        <span class="material-symbols-outlined text-lg group-hover/btn:translate-x-1 transition-transform">arrow_forward</span>
</button>
<div class="flex items-center gap-1 text-primary bg-surface-light/50 px-3 py-1.5 rounded-lg border border-primary/20">
<span class="material-symbols-outlined text-sm">star</span>
<span class="text-sm font-bold">+500 XP</span>
</div>
</div>
</div>
<!-- Visual Decoration -->
<div class="hidden md:block">
<div class="relative h-24 w-24 rounded-full border-4 border-primary/30 flex items-center justify-center bg-background-dark">
<span class="material-symbols-outlined text-4xl text-primary">speed</span>
</div>
</div>
</div>
</section>
<!-- 2. Personal Progress Bar & FIFA Card -->
<section class="grid grid-cols-1 md:grid-cols-2 gap-6">
<!-- Progress Card -->
<div class="rounded-2xl bg-surface-dark p-6 border border-surface-light shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 cursor-pointer group">
<div class="flex justify-between items-start mb-6">
<div>
<h3 class="text-xl font-bold text-white group-hover:text-primary transition-colors">Road to Elite</h3>
<p class="text-sm text-muted">Season 4 Progress</p>
</div>
<div class="bg-primary/10 text-primary p-2 rounded-lg">
<span class="material-symbols-outlined">military_tech</span>
</div>
</div>
<div class="flex flex-col gap-2 mb-6">
<div class="flex justify-between text-sm font-medium">
<span class="text-white">Level 14</span>
<span class="text-primary">850 / 1000 XP</span>
</div>
<div class="h-3 w-full rounded-full bg-surface-light overflow-hidden">
<div class="h-full w-[85%] rounded-full bg-primary shadow-[0_0_10px_rgba(29,185,84,0.5)]"></div>
</div>
<p class="text-xs text-muted mt-1">150 XP needed for next level</p>
</div>
<div class="flex items-center gap-3 bg-surface-light/30 p-3 rounded-xl border border-surface-light">
<span class="material-symbols-outlined text-yellow-500">lock</span>
<p class="text-xs text-gray-300">Unlock "Pro Striker" card at Level 15</p>
</div>
</div>
<!-- Card Teaser -->
<div class="relative rounded-2xl bg-surface-dark p-6 border border-surface-light shadow-lg flex items-center justify-center overflow-hidden group">
<div class="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
<div class="relative z-10 flex flex-col items-center gap-4 text-center">
<!-- The "FIFA Card" Silhouette -->
<div class="relative w-28 h-40 bg-gray-800 rounded-lg border-2 border-gray-600 shadow-2xl flex items-center justify-center transform group-hover:scale-105 transition-transform duration-300">
<div class="absolute inset-0 card-shiny opacity-30 rounded-lg pointer-events-none"></div>
<span class="material-symbols-outlined text-4xl text-gray-500">lock</span>
</div>
<div>
<h4 class="text-white font-bold">Next Reward</h4>
<p class="text-xs text-muted">Gold Rare Player Pack</p>
</div>
</div>
</div>
</section>
<!-- 3. Admin Task Creator -->
<section class="rounded-2xl bg-surface-dark border-t-4 border-primary p-6 shadow-lg">
<div class="flex items-center justify-between mb-6">
<h3 class="text-xl font-bold text-white flex items-center gap-2">
<span class="material-symbols-outlined text-primary">add_task</span>
                                Admin Task Creator
                            </h3>
<button class="text-xs font-bold text-muted hover:text-white uppercase tracking-wider">Collapse</button>
</div>
<form class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div class="col-span-1 md:col-span-2">
<label class="block text-xs font-bold text-muted uppercase tracking-wider mb-2">Challenge Title</label>
<input class="w-full rounded-xl bg-surface-light border-transparent focus:border-primary focus:ring-0 text-white placeholder-gray-500 px-4 py-3" placeholder="e.g. Midfield Maestro" type="text"/>
</div>
<div class="col-span-1">
<label class="block text-xs font-bold text-muted uppercase tracking-wider mb-2">Metric Type</label>
<div class="relative">
<select class="w-full rounded-xl bg-surface-light border-transparent focus:border-primary focus:ring-0 text-white appearance-none px-4 py-3">
<option>Top Speed (km/h)</option>
<option>Distance Covered (km)</option>
<option>Goals Scored</option>
<option>Pass Completion %</option>
</select>
<span class="material-symbols-outlined absolute right-4 top-3 text-muted pointer-events-none">expand_more</span>
</div>
</div>
<div class="col-span-1">
<label class="block text-xs font-bold text-muted uppercase tracking-wider mb-2">Target Value</label>
<input class="w-full rounded-xl bg-surface-light border-transparent focus:border-primary focus:ring-0 text-white placeholder-gray-500 px-4 py-3" placeholder="e.g. 30" type="number"/>
</div>
<div class="col-span-1">
<label class="block text-xs font-bold text-muted uppercase tracking-wider mb-2">XP Reward</label>
<input class="w-full rounded-xl bg-surface-light border-transparent focus:border-primary focus:ring-0 text-white placeholder-gray-500 px-4 py-3" placeholder="e.g. 100" type="number"/>
</div>
<div class="col-span-1 flex items-end">
<button class="w-full rounded-xl bg-white text-background-dark font-bold py-3 hover:bg-gray-200 transition-colors" type="button">
                                    Publish Challenge
                                </button>
</div>
</form>
</section>
</div>
<!-- RIGHT COLUMN (Leaderboard) -->
<div class="flex flex-col gap-6">
<!-- Live Leaderboard Widget -->
<div class="bg-surface-dark rounded-2xl p-6 shadow-xl h-full flex flex-col">
<div class="flex items-center justify-between mb-6">
<h3 class="text-lg font-bold text-white">Live Leaderboard</h3>
<div class="flex gap-1 bg-surface-light p-1 rounded-lg">
<button class="px-3 py-1 rounded bg-primary text-background-dark text-xs font-bold">W</button>
<button class="px-3 py-1 rounded hover:bg-white/5 text-muted text-xs font-bold">M</button>
<button class="px-3 py-1 rounded hover:bg-white/5 text-muted text-xs font-bold">A</button>
</div>
</div>
<!-- Stats Filter Tabs -->
<div class="flex border-b border-surface-light mb-4">
<button class="flex-1 pb-3 text-sm font-medium text-primary border-b-2 border-primary">Speed</button>
<button class="flex-1 pb-3 text-sm font-medium text-muted hover:text-white transition-colors">Goals</button>
<button class="flex-1 pb-3 text-sm font-medium text-muted hover:text-white transition-colors">Passes</button>
</div>
<!-- Leaderboard List -->
<div class="flex flex-col gap-2 overflow-y-auto flex-1 pr-2 custom-scrollbar">
<!-- Rank 1 -->
<div class="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-[#FFD700]/10 to-transparent border border-[#FFD700]/20">
<div class="font-black text-[#FFD700] w-6 text-center">1</div>
<div class="h-10 w-10 rounded-full bg-cover bg-center border-2 border-[#FFD700]" data-alt="Avatar of player ranked 1" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuC5LP-5l1l6zaypVy4gpLaDViFapqE3vlj_CgRAeABLkAQdy0LOZmt-i6PVldLaGJmIo2qgr8X6y2LXGwdaIDIV2NZoZYj_n0nts2ql6QDS6rpBsJYaVij1kX5O4WOJdMYgARJF6Cg_esl-dQsgPJkzPXSNZacc48o27EHjocZ2AgO77JuLEq1sdEXEqlrIelXSETD0LFQ-t0hUKgicZZ71huYJMiMHbLGdiOd-BPrgg0h91jIkjdUDUdXq-lTq5vByLrV88dA2ya0')"></div>
<div class="flex-1">
<p class="text-sm font-bold text-white">Marcus R.</p>
<p class="text-xs text-muted">Man City</p>
</div>
<div class="text-right">
<p class="text-sm font-bold text-[#FFD700]">36.4</p>
<p class="text-[10px] text-muted">km/h</p>
</div>
</div>
<!-- Rank 2 -->
<div class="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-light transition-colors group cursor-pointer">
<div class="font-bold text-gray-400 w-6 text-center">2</div>
<div class="h-10 w-10 rounded-full bg-cover bg-center border border-surface-light group-hover:border-primary" data-alt="Avatar of player ranked 2" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuA3f82wC-Ayc4O_IOH62BkXQk1HPEgOcBi4GgSSjCt8WbqpiEQaj4b3k3fyuKOVxAA7JlYgNJOPpMCP_cmOSJejmT6kpEewnqBFkcxbpX1Bbul7LWLMrK4zf1eEAbCLYcCAXYYWuTocz5cCBg9iTd-s85eaiG8eShU5AZQBktBQWpDkNDni1tXGTJ9N_8929blxlSo6VnntMRN8YEMUfpRxx1gu0vnWfd4NeBRiePTLhS7zQBrDoba1V9LTL9Tuo8pbgw_e5cNJgdg')"></div>
<div class="flex-1">
<p class="text-sm font-bold text-white">Sarah K.</p>
<p class="text-xs text-muted">Chelsea LFC</p>
</div>
<div class="text-right">
<p class="text-sm font-bold text-white">35.8</p>
<p class="text-[10px] text-muted">km/h</p>
</div>
</div>
<!-- Rank 3 -->
<div class="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-light transition-colors group cursor-pointer">
<div class="font-bold text-[#CD7F32] w-6 text-center">3</div>
<div class="h-10 w-10 rounded-full bg-cover bg-center border border-surface-light group-hover:border-primary" data-alt="Avatar of player ranked 3" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuD1k_FuqNDHf4N8VfYezQmMErVPp0QHIwAiTH4V621OkUy3nn-SZrgP6ZQBNEVwjA9Jf-aMZwtt1C8-Ajh2YN8BSB5vW5hHn_qpuZufZobSCc6lbKhe3OBl0rK1hG3AyxijrWB1mET7Ba5M297obRQNrP4ucCZSxILvhuIt7oedkGyo1rCHAP5EboRdADRwXIv7M_kEO-ipOIIiPInM-1j4gfhqyPkLMxafjv8Qo7kM1VVk5T9UxG5tGjLswlh8rfGVDtPh-238o3s')"></div>
<div class="flex-1">
<p class="text-sm font-bold text-white">David B.</p>
<p class="text-xs text-muted">Galaxy</p>
</div>
<div class="text-right">
<p class="text-sm font-bold text-white">35.2</p>
<p class="text-[10px] text-muted">km/h</p>
</div>
</div>
<!-- Rank 4 -->
<div class="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-light transition-colors group cursor-pointer">
<div class="font-bold text-muted w-6 text-center">4</div>
<div class="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center text-white text-xs font-bold border border-surface-light group-hover:border-primary">
                                    JD
                                </div>
<div class="flex-1">
<p class="text-sm font-bold text-white">John Doe</p>
<p class="text-xs text-muted">United</p>
</div>
<div class="text-right">
<p class="text-sm font-bold text-white">34.9</p>
<p class="text-[10px] text-muted">km/h</p>
</div>
</div>
<!-- You (Rank 14) -->
<div class="mt-2 pt-4 border-t border-surface-light">
<div class="flex items-center gap-3 p-3 rounded-xl bg-primary/20 border border-primary/50">
<div class="font-bold text-primary w-6 text-center">14</div>
<div class="h-10 w-10 rounded-full bg-cover bg-center border-2 border-primary" data-alt="Your Avatar" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuA_Lu5D3ABO0-e39eAfbTZgh7KJx9iic5itBk7IgstpqCBEk5bc_f9lq0E64js6SZQkk8UgyQ4tq5gmanEubk0H-GgMvq_vAx7L9prtiJbLNuKbpPUQsH7CqiKWjlGJziFtt6rH7U9Sh15fh_FUbaRGYI7mbegRH7G0t7mF18Rxk7CqjhToNjFETbOQoPNTfv21_B-mD55bqNS9VMgjmYWjK4qw4hwBXZ5O6SfE_O8s_7ko565ML1_37D-9mGiutx2Nj-OKBhQMMzg')"></div>
<div class="flex-1">
<p class="text-sm font-bold text-white">You</p>
<p class="text-xs text-green-300">Personal Best!</p>
</div>
<div class="text-right">
<p class="text-sm font-bold text-primary">32.1</p>
<p class="text-[10px] text-muted">km/h</p>
</div>
</div>
</div>
</div>
</div>
<!-- Mini Widget: Tips -->
<div class="bg-[#264531] rounded-2xl p-6 flex flex-col gap-3">
<div class="flex items-center gap-2 text-primary">
<span class="material-symbols-outlined">lightbulb</span>
<span class="font-bold text-sm uppercase">Pro Tip</span>
</div>
<p class="text-sm text-gray-200">Improve your sprint speed by focusing on your initial acceleration phase. Keep your center of gravity low.</p>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
<?php require_once BASE_PATH . "/includes/footer.php"; ?>
