# Nutmeg Football Platform

A modern PHP-based football analytics and management dashboard built with a custom MVC architecture, Tailwind CSS dark theme, and HTMX for SPA-like navigation.

## Quick Start

```bash
cd public
php -S localhost:8000
```

Visit **http://localhost:8000**

## Project Structure

```
nutmeg/
├── app/
│   ├── bootstrap.php           # PSR-4 autoloader
│   ├── routes.php              # All application routes
│   ├── Core/
│   │   ├── Controller.php      # Base controller (renderRaw)
│   │   ├── HtmxHelper.php     # HTMX request detection utilities
│   │   └── Router.php          # URL routing engine
│   ├── Controllers/
│   │   ├── AuthController.php
│   │   ├── ChallengesController.php
│   │   ├── EventsController.php
│   │   ├── FixturesController.php
│   │   ├── HomeController.php
│   │   ├── InstructorController.php
│   │   ├── MatchHistoryController.php
│   │   ├── PlayersController.php
│   │   ├── TeamController.php
│   │   └── VideoController.php
│   └── views/
│       ├── auth/
│       │   ├── login.php       # Centered card login
│       │   └── login-alt.php   # Split-panel login with branding
│       └── dashboards/
│           ├── home.php        # Main dashboard with live pitches
│           ├── matchmaking.php # PitchPerfect matchmaking lobby
│           ├── fixtures.php    # Upcoming fixtures & team rosters
│           ├── challenges.php  # Challenges & leaderboard
│           ├── players.php     # Player stats & FIFA-style card
│           ├── teams.php       # Team management & activity
│           ├── instructor.php  # Instructor analytics & diagnostics
│           ├── match-history.php # Match history & highlights
│           └── video-upload.php  # Video ingest & AI highlights
├── includes/
│   ├── header.php              # HTML head, Tailwind config, HTMX
│   ├── footer.php              # Closing HTML tags
│   ├── sidenav.php             # Unified sidebar navigation
│   └── topnav.php              # Top bar with page title
└── public/
    ├── index.php               # Front controller (entry point)
    └── htmx.js                 # Mobile menu & sidebar JS
```

## Routes

| Route               | Page                                 |
| ------------------- | ------------------------------------ |
| `/` or `/dashboard` | Dashboard overview with live pitches |
| `/matchmaking`      | PitchPerfect matchmaking lobby       |
| `/fixtures`         | Upcoming fixtures & rosters          |
| `/challenges`       | Football challenges & XP             |
| `/players`          | Player stats dashboard               |
| `/teams`            | Team management                      |
| `/instructor`       | Instructor analytics                 |
| `/match-history`    | Match history & highlights           |
| `/video-upload`     | Video upload & AI highlights         |
| `/login`            | Login (centered card)                |
| `/login-alt`        | Login (split-panel with branding)    |

## Architecture

- **MVC**: Router dispatches to Controllers which render Views
- **Shared Layout**: All dashboard views include `header.php`, `sidenav.php`, `topnav.php`, and `footer.php`
- **Active Nav**: PHP-driven — each view sets `$currentPage` which the sidenav uses to highlight the active link
- **HTMX**: `hx-boost="true"` on `<body>` transparently upgrades all navigation to AJAX with history support
- **Sidebar**: Collapsible with localStorage persistence, responsive mobile menu

## Color Palette

| Token             | Value     | Usage            |
| ----------------- | --------- | ---------------- |
| `primary`         | `#1db954` | Green accent     |
| `background-dark` | `#122017` | Main background  |
| `card-dark`       | `#1b2e21` | Card backgrounds |
| `surface-dark`    | `#1b2e23` | Surface elements |
| Border            | `#264531` | Border color     |
| `text-muted`      | `#B3B3B3` | Secondary text   |
| `danger`          | `#E74C3C` | Error/danger     |

## Tech Stack

- **Backend**: PHP 8+ (custom MVC, PSR-4 autoloading)
- **Frontend**: Tailwind CSS (CDN), Material Symbols icons
- **Interactivity**: HTMX 1.9 (CDN) for SPA navigation
- **Fonts**: Lexend, Space Grotesk, Noto Sans
